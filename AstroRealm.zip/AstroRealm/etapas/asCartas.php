<?php
session_start();

$erro = '';
$carta = null;
$descricao_detalhada = null;

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Conexão
    $conn = new mysqli("localhost", "root", "", "astrodb");
    if ($conn->connect_error) {
        die("Erro de conexão: " . $conn->connect_error);
    }

    // Prepared statement para segurança
    $stmt = $conn->prepare("SELECT nome, tipo, imagem, significado, descricao_detalhada FROM cartas_tarot WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $carta = $result->fetch_assoc();
        $descricao_detalhada = json_decode($carta['descricao_detalhada'], true);
    }

    $stmt->close();
    $conn->close();
} else {
    $erro = "Nenhuma carta selecionada.";
}
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <title>AstroRealm: As Cartas - <?= $carta ? htmlspecialchars($carta['nome']) : 'Tarô' ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?= $carta ? 'Descubra o significado da carta ' . htmlspecialchars($carta['nome']) . ' no tarô, seus simbolismos e interpretações em amor, carreira e espiritualidade.' : 'Explore as cartas do tarô no AstroRealm.' ?>">
    <meta name="keywords" content="tarô, <?= $carta ? htmlspecialchars($carta['nome']) . ', significado do ' . htmlspecialchars($carta['nome']) . ',' : '' ?> Arcanos Maiores, astrologia">
    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/asCartas.css">

    <script src="../js/cssGeral.js" defer></script>
    <link rel="icon" type="image/x-icon" href="../imagens/ico/argentina1.png">
</head>

<body>
    <div id="content">
        <header>
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <button class="hamburger">☰</button>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <!-- Menu Dropdown para Signos do Zodíaco -->
                    <li class="menuItem dropdown">
                        <a href="../horoscopo.php">Horóscopo</a>
                        <span class="dropdown-toggle">▼</span>
                        <ul class="dropdown-content">
                            <li><a href="../horoscoposGerais.php?signo=aries">Áries</a></li>
                            <li><a href="../horoscoposGerais.php?signo=taurus">Touro</a></li>
                            <li><a href="../horoscoposGerais.php?signo=gemini">Gêmeos</a></li>
                            <li><a href="../horoscoposGerais.php?signo=cancer">Câncer</a></li>
                            <li><a href="../horoscoposGerais.php?signo=leo">Leão</a></li>
                            <li><a href="../horoscoposGerais.php?signo=virgo">Virgem</a></li>
                            <li><a href="../horoscoposGerais.php?signo=libra">Libra</a></li>
                            <li><a href="../horoscoposGerais.php?signo=scorpio">Escorpião</a></li>
                            <li><a href="../horoscoposGerais.php?signo=sagittarius">Sagitário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=capricorn">Capricórnio</a></li>
                            <li><a href="../horoscoposGerais.php?signo=aquarius">Aquário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=pisces">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="../signos.php">Os Signos</a></li>
                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../etapas/etapa1.php" class="underline">Tarot</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                    <li class="menuItem"><a href="../admin_gerenciar_usuarios.php">Gerenciar Usuários</a></li>
                </ul>

                <div id="divPerfil">
                    <?php if (isset($_SESSION['usuario_nome'])): ?>
                        <a href="../perfil.php" class="usuario-logado">
                            <div id="divWrapPerfil">
                                <?php $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png'; ?>
                                <img src="../imagens/perfis/<?= htmlspecialchars($foto_perfil) ?>" alt="Foto do Usuário">
                                <div id="divInfoLogado">
                                    <h3>Meu Perfil</h3>
                                    <div><span id="nomePerfil"><?= htmlspecialchars($_SESSION['usuario_nome']) ?></span></div>
                                </div>
                            </div>
                        </a>
                    <?php else: ?>
                        <a href="../login.php">Login</a>
                    <?php endif; ?>
                </div>
            </nav>
        </header>

        <main>

            <div id="cartaDisplay">

                <?php if ($erro): ?>
                    <p class="erro"><?= htmlspecialchars($erro) ?></p>
                <?php elseif ($carta): ?>
                    <div class="carta-info">
                        <h2><?= htmlspecialchars($carta['tipo']) ?></h2>
                        <img src="../imagens/cartas/<?= htmlspecialchars(basename($carta['imagem'])) ?>"
                            alt="Carta <?= htmlspecialchars($carta['nome']) ?> no tarô">
                        <p><?= nl2br(htmlspecialchars($carta['significado'])) ?></p>
                    </div>
                    <div>
                        <div class="navegacao-cartas">
                            <a href="asCartas.php?id=<?= $id == 1 ? 78 : $id - 1 ?>" class="btn-nav btn-prev">Carta Anterior</a>
                            <a href="asCartas.php?id=<?= $id == 78 ? 1 : $id + 1 ?>" class="btn-nav btn-next">Próxima Carta</a>
                        </div>

                        <div class="divDesc">

                            <?php if ($carta && $descricao_detalhada): ?>

                                <div class="divContextos">
                                    <h3><?= htmlspecialchars($descricao_detalhada['titulo']) ?></h3>
                                    <p><?= nl2br(htmlspecialchars($descricao_detalhada['introducao'])) ?></p>

                                    <h4>Simbologia</h4>
                                    <p><?= nl2br(htmlspecialchars($descricao_detalhada['simbologia'])) ?></p>

                                    <h4>Significados Gerais</h4>
                                    <ul>
                                        <li><strong>Posição Direita:</strong> <?= htmlspecialchars($descricao_detalhada['significados']['direita']) ?></li>
                                        <li><strong>Posição Invertida:</strong> <?= htmlspecialchars($descricao_detalhada['significados']['invertida']) ?></li>
                                    </ul>
                                </div>

                                <div class="divContextos">
                                    <h4 style="color: #FFD700; margin-top: 0px;"><?= htmlspecialchars($carta['nome']) ?> na Vida Real</h4>
                                    <p><strong>Amor:</strong> <?= htmlspecialchars($descricao_detalhada['contextos']['amor']) ?></p>
                                    <p><strong>Carreira:</strong> <?= htmlspecialchars($descricao_detalhada['contextos']['carreira']) ?></p>
                                    <p><strong>Saúde:</strong> <?= htmlspecialchars($descricao_detalhada['contextos']['saude']) ?></p>
                                    <p><strong>Espiritualidade:</strong> <?= htmlspecialchars($descricao_detalhada['contextos']['espiritualidade']) ?></p>
                                    <p><strong>Curiosidade:</strong> <?= nl2br(htmlspecialchars($descricao_detalhada['curiosidade'])) ?></p>
                                </div>

                            <?php else: ?>
                                <p>Descrição não disponível para esta carta.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                <?php endif; ?>
            </div>


        </main>
    </div>
</body>

</html>