<?php
session_start();
session_unset();
session_destroy(); // encerra a sessão
header("Location: ../index.php");
exit();
