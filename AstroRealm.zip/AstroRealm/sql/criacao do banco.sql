create database astrodb;

use astrodb;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    tipo_usuario ENUM('comum', 'admin') NOT NULL DEFAULT 'comum',
    senha VARCHAR(255) NOT NULL,
    foto VARCHAR(255) DEFAULT 'terra.png'
);

CREATE TABLE cartas_tarot (
    id INT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    tipo VARCHAR(50),
    imagem VARCHAR(255),
    significado TEXT,
    interpretacao_posicao_1 TEXT,
    interpretacao_posicao_2 TEXT,
    interpretacao_posicao_3 TEXT,
    interpretacao_perdida TEXT,
    descricao_detalhada LONGTEXT
);

CREATE TABLE mapas_astrais (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    dados_mapa JSON NOT NULL,
    data_criacao DATETIME NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE signos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_signos VARCHAR(20) NOT NULL UNIQUE,
    signo VARCHAR(20) NOT NULL UNIQUE,
    icone CHAR(5) NOT NULL UNIQUE,
    chamada TEXT NOT NULL,
    elemento VARCHAR(20) NOT NULL,
    cor VARCHAR(50) NOT NULL,
    planeta_regente VARCHAR(20) NOT NULL,
    compatibilidade VARCHAR(100) NOT NULL,
    periodo VARCHAR(100) NOT NULL,
    introducao TEXT NOT NULL,
    mitologia TEXT NOT NULL,
    caracteristicas_positivas TEXT NOT NULL,
    caracteristicas_negativas TEXT NOT NULL,
    relacionamentos TEXT NOT NULL,
    carreira TEXT NOT NULL,
    compatibilidade_texto TEXT NOT NULL,
    influencia_planetaria TEXT NOT NULL,
    dicas TEXT NOT NULL,
    famosos TEXT NOT NULL
);