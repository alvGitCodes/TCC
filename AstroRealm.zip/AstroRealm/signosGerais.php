<?php
session_start();

// Conexão com o banco de dados
require_once 'php/conexao.php'; // Ajuste o caminho conforme sua estrutura

// Obtém o signo da URL e sanitiza
$signo = isset($_GET['signo']) ? strtolower(trim($_GET['signo'])) : 'aries';

// Consulta o banco de dados
$stmt = $conn->prepare("SELECT * FROM signos WHERE signo = ?");
$stmt->bind_param("s", $signo);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $dadosSigno = $result->fetch_assoc();
} else {
    // Caso o signo não seja encontrado, redireciona ou exibe erro
    $dadosSigno = null;
    echo "<p>Signo não encontrado.</p>";
    exit;
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/layoutSignos.css">
    <link rel="icon" type="image/x-icon" href="imagens/ico/argentina1.png">
    <script src="js/cssGeral.js" defer></script>
    <title>AstroRealm: <?php echo ucfirst($dadosSigno['nome_signos']); ?></title>
</head>

<body>
    <div id="content">
        <header>
            <nav class="menu">
                <div id="logo"><a href="index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <button class="hamburger">☰</button>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="index.php">Home</a></li>
                    <li class="menuItem dropdown">
                        <a href="horoscopo.php">Horóscopo</a>
                        <span class="dropdown-toggle">▼</span>
                        <ul class="dropdown-content">
                            <li><a href="horoscoposGerais.php?signo=aries">Áries</a></li>
                            <li><a href="horoscoposGerais.php?signo=taurus">Touro</a></li>
                            <li><a href="horoscoposGerais.php?signo=gemini">Gêmeos</a></li>
                            <li><a href="horoscoposGerais.php?signo=cancer">Câncer</a></li>
                            <li><a href="horoscoposGerais.php?signo=leo">Leão</a></li>
                            <li><a href="horoscoposGerais.php?signo=virgo">Virgem</a></li>
                            <li><a href="horoscoposGerais.php?signo=libra">Libra</a></li>
                            <li><a href="horoscoposGerais.php?signo=scorpio">Escorpião</a></li>
                            <li><a href="horoscoposGerais.php?signo=sagittarius">Sagitário</a></li>
                            <li><a href="horoscoposGerais.php?signo=capricorn">Capricórnio</a></li>
                            <li><a href="horoscoposGerais.php?signo=aquarius">Aquário</a></li>
                            <li><a href="horoscoposGerais.php?signo=pisces">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="signos.php" class="underline">Os Signos</a></li>
                    <li class="menuItem"><a href="astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="etapas/etapa1.php">Tarot</a></li>
                    <li class="menuItem"><a href="venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="colecao.php">Coleção</a></li>
                    <?php if (isset($_SESSION['tipo_usuario']) && $_SESSION['tipo_usuario'] === 'admin'): ?>
                        <li class="menuItem"><a href="admin_gerenciar_usuarios.php">Gerenciar Usuários</a></li>
                    <?php endif; ?>
                </ul>

                <div id="divPerfil">
                    <?php if (isset($_SESSION['usuario_nome'])): ?>
                        <a href="perfil.php" class="usuario-logado">
                            <div id="divWrapPerfil">
                                <?php
                                $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                                ?>
                                <img src="imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                                <div id="divInfoLogado">
                                    <h3>Meu Perfil</h3>
                                    <div>
                                        <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                    <?php endif; ?>
                </div>
            </nav>
        </header>

        <div id="conteudoSignos">
            <div id="cabecalho">
                <div id="divImageSign">
                    <span class="<?php echo htmlspecialchars($dadosSigno['elemento'] == 'Fogo' ? 'fogo' : ($dadosSigno['elemento'] == 'Terra' ? 'terra' : ($dadosSigno['elemento'] == 'Ar' ? 'ar' : 'agua'))); ?>"><?php echo $dadosSigno['icone']; ?></span>
                </div>

                <div id="tabelaTop">
                    <div id="tituloSign">
                        Signo do Zodíaco: <?php echo ucfirst(htmlspecialchars($dadosSigno['nome_signos'])); ?>
                    </div>

                    <ul id="listCharSigns">
                        <li><strong>Elemento:</strong> <?php echo htmlspecialchars($dadosSigno['elemento']); ?></li>
                        <li><strong>Cor:</strong> <?php echo htmlspecialchars($dadosSigno['cor']); ?></li>
                        <li><strong>Planeta Regente:</strong> <?php echo htmlspecialchars($dadosSigno['planeta_regente']); ?></li>
                        <li><strong>Melhor Compatibilidade:</strong> <?php echo htmlspecialchars($dadosSigno['compatibilidade']); ?></li>
                        <li><strong>Período Correspondente:</strong> <?php echo htmlspecialchars($dadosSigno['periodo']); ?></li>
                    </ul>

                </div>

            </div>

            <div id="buttonsTop" style="display: flex; justify-content: space-between; flex-direction: column;">
                <!-- <a href="mapaGratis.html"><button id="btnPrevisoes" style="background-color: #00A2FF;">Criar Mapa Gratuito</button></a> -->
                <a href="horoscoposGerais.php?signo=<?php echo htmlspecialchars($signo); ?>"><button id="btnPrevisoes">Previsão de Hoje Para <?php echo ucfirst(htmlspecialchars($dadosSigno['nome_signos'])); ?></button></a>
            </div>

            <div id="infoSigno">
                <h2 id="chamadaSigno"><?php echo ucfirst(htmlspecialchars($dadosSigno['nome_signos'])); ?>: <?php echo $dadosSigno['chamada']; ?></h2>

                <p style="margin-bottom: -20px;">
                    <?php echo $dadosSigno['introducao']; ?>
                </p>

                <h3 class="blockTitle">A Mitologia de <?php echo ucfirst(htmlspecialchars($dadosSigno['nome_signos'])); ?></h3>
                <p><?php echo $dadosSigno['mitologia']; ?></p>

                <h3 class="blockTitle">✨ Características Positivas</h3>
                <ul class="listaInfoSign"><?php echo $dadosSigno['caracteristicas_positivas']; ?></ul>

                <h3 class="blockTitle">👿 Características Negativas</h3>
                <ul class="listaInfoSign"><?php echo $dadosSigno['caracteristicas_negativas']; ?></ul>

                <h3 class="blockTitle">🤝 Relacionamentos e Carreira</h3>
                <p><strong>Relacionamentos</strong><br><?php echo $dadosSigno['relacionamentos']; ?></p>
                <p><strong>Carreira</strong><br><?php echo $dadosSigno['carreira']; ?></p>

                <h3 class="blockTitle">♥️ Compatibilidade com Outros Signos</h3>
                <p><?php echo $dadosSigno['compatibilidade_texto']; ?></p>

                <h3 class="blockTitle">🔥 Influência Astrológica de <?php echo htmlspecialchars($dadosSigno['planeta_regente']); ?></h3>
                <p><?php echo $dadosSigno['influencia_planetaria']; ?></p>

                <h3 class="blockTitle">😎 <?php echo ucfirst(htmlspecialchars($dadosSigno['nome_signos'])); ?> Famosos</h3>
                <ul class="listaInfoSign"><?php echo $dadosSigno['famosos']; ?></ul>

                <h3 class="blockTitle">🛠️ Dicas para <?php echo ucfirst(htmlspecialchars($dadosSigno['nome_signos'])); ?></h3>
                <ul class="listaInfoSign"><?php echo $dadosSigno['dicas']; ?></ul>

                <p>
                    <?php echo ucfirst(htmlspecialchars($dadosSigno['nome_signos'])); ?> é o signo do começo, da ação e da coragem. Com sua energia ardente e espírito pioneiro, os <?php echo strtolower(htmlspecialchars($dadosSigno['signo'])); ?> estão sempre prontos para liderar, inspirar e transformar o mundo ao seu redor. Abraçar suas qualidades e trabalhar suas fraquezas os torna verdadeiros protagonistas de suas próprias histórias!
                </p>
                <a href="mapaGratis.html">
                    <div class="btnPrevisoesBot">Criar Mapa Gratuito</div>
                </a>
            </div>
        </div>
    </div>

    <footer>
        <div id="footerContent">
            <div id="footerDivs">
                <div id="logoWrapper">
                    <div id="logoFooter">Astro<span id="spanFooter">Realm</span></div>
                    <p>
                        Descubra seu destino e conecte-se com o universo através da astrologia. <br>Explore os mistérios dos signos e muito mais!
                    </p>
                </div>
                <div class="colunaFooter">
                    <h3>Contato</h3>
                    <ul>
                        <li>Email: contato@astrorealm.com</li>
                        <li>Telefone: (11) 1234-5678</li>
                        <li>
                            <ul id="redesSociaisLinks">
                                <li><a href="https://github.com/alvGitRep"><img src="imagens/icones footer/github_1051275.png" title="GitHub" alt="github">
                                        <div>Github</div>
                                    </a></li>
                                <li><a href=""><img src="imagens/icones footer/linkedin_1051282.png" title="Linkedin" alt="linkedin">LinkedIn</a></li>
                                <li><a href=""><img src="imagens/icones footer/whatsapp_1051272.png" alt="">WhatsApp</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="colunaFooter">
                    <h3>Recursos</h3>
                    <ul class="reucursosLinks">
                        <li><a href="https://freepik.com/">Freepik</a></li>
                        <li><a href="https://rapidapi.com/">Rapid Api</a></li>
                        <li><a href="https://rapidapi.com/gbattaglia/api/astrologer">Astrologer</a></li>
                        <li><a href="https://rapidapi.com/ashutosh.devil7/api/horoscope19">Horoscope</a></li>
                        <li><a href="https://rapidapi.com/gatzuma/api/deep-translate1">Deep Translate</a></li>
                    </ul>
                </div>
            </div>
            <p class="footerCredits">© 2024 AstroRealm. Todos os direitos reservados. Imagens por Freepik.</p>
        </div>
    </footer>

    <!-- Botão de voltar ao topo -->
    <button id="scrollToTopBtn" title="Voltar ao topo"></button>
</body>

</html>