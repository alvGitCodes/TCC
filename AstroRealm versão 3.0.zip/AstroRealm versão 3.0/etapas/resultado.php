resultado.php
<?php
session_start();

// Verifica se todas as etapas foram completadas
if (!isset($_SESSION['etapa2'], $_SESSION['etapa3'], $_SESSION['etapa4'], $_SESSION['perdida'])) {
    header("Location: etapa1.php");
    exit();
}

// Junta todos os IDs para buscar no banco
$ids = array_merge($_SESSION['etapa2'], $_SESSION['etapa3'], $_SESSION['etapa4'], [$_SESSION['perdida']]);
$ids = implode(',', array_map('intval', $ids));

// Conexão
$conn = new mysqli("localhost", "root", "", "astroteste");
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Busca todas as cartas
$sql = "SELECT * FROM cartas_tarot WHERE id IN ($ids)";
$result = $conn->query($sql);

$cartas = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cartas[$row['id']] = $row;
    }
}
$conn->close();

// Função para exibir bloco de cartas
function exibirCartas($titulo, $ids, $cartas) {
    echo "<h2>$titulo</h2>";
    echo "<div class='cartas-container'>";
    foreach ($ids as $id) {
        $carta = $cartas[$id];
        echo "<div class='carta'>";
        echo "<img src='../imagens/cartas/" . basename($carta['imagem']) . "' alt='{$carta['nome']}'>";
        echo "<h3>{$carta['nome']}</h3>";
        echo "<p>{$carta['significado']}</p>";
        echo "</div>";
    }
    echo "</div>";
}

function exibirTrincaInterpretada($titulo, $ids, $cartas) {
    echo "<h2>$titulo</h2>";
    echo "<div class='cartas-container'>";
    foreach ($ids as $index => $id) {
        $carta = $cartas[$id];
        $posicao = $index + 1;
        $campo_interpretacao = "interpretacao_posicao_$posicao";
        echo "<div class='carta'>";
        echo "<img src='../imagens/cartas/" . basename($carta['imagem']) . "' alt='{$carta['nome']}'>";
        echo "<h3>{$carta['nome']}</h3>";
        echo "<p>{$carta[$campo_interpretacao]}</p>";
        echo "</div>";
    }
    echo "</div>";
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Resultado da Tiragem</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/tarot.css">
</head>
<body>
    <div id="content">
        <header>
            <!-- <div id="contato"></div> -->
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <li class="menuItem"><a href="../horoscopo.php">Horóscopo</a></li>

                    <!-- Menu Dropdown para Signos do Zodíaco -->
                    <li class="menuItem dropdown">
                        <a href="../signos.php">Os Signos</a>
                        <ul class="dropdown-content">
                            <li><a href="../signos/aries.php">Áries</a></li>
                            <li><a href="../signos/touro.php">Touro</a></li>
                            <li><a href="../signos/gemeos.php">Gêmeos</a></li>
                            <li><a href="../signos/cancer.php">Câncer</a></li>
                            <li><a href="../signos/leao.php">Leão</a></li>
                            <li><a href="../signos/virgem.php">Virgem</a></li>
                            <li><a href="../signos/libra.php">Libra</a></li>
                            <li><a href="../signos/escorpiao.php">Escorpião</a></li>
                            <li><a href="../signos/sagitario.php">Sagitário</a></li>
                            <li><a href="../signos/capricornio.php">Capricórnio</a></li>
                            <li><a href="../signos/aquario.php">Aquário</a></li>
                            <li><a href="../signos/peixes.php">Peixes</a></li>
                        </ul>
                    </li>

                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                    <li class="menuItem"><a href="etapa1.php" class="underline">Tarot</a></li>
                </ul>

                <div id="divPerfil">
                    <?php if (isset($_SESSION['usuario_nome'])): ?>
                        <a href="perfil.php" class="usuario-logado">
                            <div id="divWrapPerfil">
                                <?php
                                $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                                ?>
                                <img src="imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                                <div id="divInfoLogado">
                                    <h3>Meu Perfil</h3>
                                    <div>
                                        <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                    <?php endif; ?>
                </div>

            </nav>

        </header>

    </div>

<h1>Resultado Final da Tiragem</h1>

<?php
exibirTrincaInterpretada("Etapa 2 - As primeiras 3 cartas", $_SESSION['etapa2'], $cartas);
exibirTrincaInterpretada("Etapa 3 - As cartas do meio", $_SESSION['etapa3'], $cartas);
exibirTrincaInterpretada("Etapa 4 - As cartas finais", $_SESSION['etapa4'], $cartas);
?>

<h2>Carta Perdida - Aquela que você não escolheu</h2>
<div class="cartas-container">
    <?php
    $carta = $cartas[$_SESSION['perdida']];
    ?>
    <div class="carta">
        <img src="../imagens/cartas/<?= basename($carta['imagem']) ?>" alt="<?= $carta['nome'] ?>">
        <h3><?= $carta['nome'] ?></h3>
        <p><?= $carta['significado'] ?></p>
        <p><em>Esta carta representa uma força oculta ou um destino não seguido.</em></p>
    </div>
</div>

</body>
</html>