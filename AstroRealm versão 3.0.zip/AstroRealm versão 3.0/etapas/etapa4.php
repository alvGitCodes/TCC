<?php
session_start();

// Verificações de etapas anteriores
if (!isset($_SESSION['etapa1']) || !isset($_SESSION['etapa2']) || !isset($_SESSION['etapa3'])) {
    header("Location: etapa1.php");
    exit();
}

// Calcular as 4 cartas restantes
$restantes = array_diff($_SESSION['etapa1'], $_SESSION['etapa2'], $_SESSION['etapa3']);

if (count($restantes) !== 4) {
    die("Erro: deveriam restar 4 cartas, mas há " . count($restantes));
}

// Conexão com o banco
$conn = new mysqli("localhost", "root", "", "astroteste");
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Se formulário enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['cartas']) && count($_POST['cartas']) == 3) {
        $_SESSION['etapa4'] = $_POST['cartas'];
        $_SESSION['perdida'] = array_values(array_diff($restantes, $_POST['cartas']))[0];
        header("Location: resultado.php");
        exit();
    } else {
        $erro = "Você deve escolher exatamente 3 cartas.";
    }
}

// Buscar as 4 cartas restantes
$ids = implode(",", array_map('intval', $restantes));
$sql = "SELECT * FROM cartas_tarot WHERE id IN ($ids)";
$result = $conn->query($sql);

$cartas = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cartas[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <title>Etapa 4 - Escolha 3 Cartas Finais</title>
    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/etapas.css">
    <script>
        function limitarSelecao(checkbox) {
            const selecionados = document.querySelectorAll('input[type="checkbox"]:checked');
            if (selecionados.length > 3) {
                checkbox.checked = false;
                alert("Você só pode escolher 3 cartas.");
            }
        }
    </script>
</head>

<body>
    <div id="content">
        <header>
            <!-- <div id="contato"></div> -->
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <li class="menuItem"><a href="../horoscopo.php">Horóscopo</a></li>

                    <!-- Menu Dropdown para Signos do Zodíaco -->
                    <li class="menuItem dropdown">
                        <a href="../signos.php">Os Signos</a>
                        <ul class="dropdown-content">
                            <li><a href="../signos/aries.php">Áries</a></li>
                            <li><a href="../signos/touro.php">Touro</a></li>
                            <li><a href="../signos/gemeos.php">Gêmeos</a></li>
                            <li><a href="../signos/cancer.php">Câncer</a></li>
                            <li><a href="../signos/leao.php">Leão</a></li>
                            <li><a href="../signos/virgem.php">Virgem</a></li>
                            <li><a href="../signos/libra.php">Libra</a></li>
                            <li><a href="../signos/escorpiao.php">Escorpião</a></li>
                            <li><a href="../signos/sagitario.php">Sagitário</a></li>
                            <li><a href="../signos/capricornio.php">Capricórnio</a></li>
                            <li><a href="../signos/aquario.php">Aquário</a></li>
                            <li><a href="../signos/peixes.php">Peixes</a></li>
                        </ul>
                    </li>

                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                    <li class="menuItem"><a href="etapa1.php" class="underline">Tarot</a></li>
                </ul>

                <div id="divPerfil">
                    <?php if (isset($_SESSION['usuario_nome'])): ?>
                        <a href="perfil.php" class="usuario-logado">
                            <div id="divWrapPerfil">
                                <?php
                                $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                                ?>
                                <img src="imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                                <div id="divInfoLogado">
                                    <h3>Meu Perfil</h3>
                                    <div>
                                        <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                    <?php endif; ?>
                </div>

            </nav>

        </header>

    </div>

    <div id="etapasContainer">
        <h1>Escolha as últimas 3 cartas</h1>
        <p>Entre as 4 cartas finais, escolha 3. A que sobrar será a carta "perdida".</p>

        <?php if (!empty($erro)): ?>
            <p style="color:red;"><?= $erro ?></p>
        <?php endif; ?>

        <form method="POST">
            <div class="cartas-container">
                <?php foreach ($cartas as $carta): ?>
                    <div class="carta">
                        <input type="checkbox" name="cartas[]" value="<?= $carta['id'] ?>" id="carta<?= $carta['id'] ?>" onchange="limitarSelecao(this)">
                        <label for="carta<?= $carta['id'] ?>">
                            <img src="../imagens/cartas/<?= basename($carta['imagem']) ?>" alt="<?= $carta['nome'] ?>">
                            <p><?= $carta['nome'] ?></p>
                        </label>
                    </div>
                <?php endforeach; ?>
            </div>

            <button type="submit">Ver Resultado Final</button>
        </form>

    </div>

</body>

</html>