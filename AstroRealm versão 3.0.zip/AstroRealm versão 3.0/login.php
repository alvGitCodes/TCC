<?php
$erroLogin = isset($_GET['erro']) && $_GET['erro'] == 1;
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Entrar ou Registrar</title>
    <link rel="stylesheet" href="css/login2.css" />
    <script src="js/loginRegistro.js" defer></script>
</head>

<body>
    <div id="titulo">
        <a href="index.php">
            <h1>Astro<span>Realm</span></h1>
        </a>
    </div>
    <div id="conteudo">

        <div class="form-container">

            <?php if (isset($_GET['erro']) && $_GET['erro'] === 'email'): ?>
                <div class="mensagem-erro">Este e-mail já está em uso. Tente outro.</div>
            <?php elseif (isset($_GET['registro']) && $_GET['registro'] === 'sucesso'): ?>
                <div class="mensagem-sucesso">Cadastro realizado com sucesso! Faça login abaixo.</div>
            <?php endif; ?>

            <div class="toggle-buttons">
                <button id="btnLogin" class="active">Login</button>
                <button id="btnRegistro">Registrar</button>
            </div>

            <!-- Formulário de Login -->
            <?php if ($erroLogin): ?>
                <div style="color: red; text-align: center; margin-bottom: 10px;">
                    Email ou senha inválidos.
                </div>
            <?php endif; ?>

            <form id="formLogin" class="form active" action="php/loginBackend.php" method="POST">
                <h2>Entrar</h2>
                <input type="email" name="email" placeholder="E-mail" required />
                <input type="password" name="senha" placeholder="Senha" required />
                <button type="submit" class="btnIndex">Login</button>
            </form>

            <!-- Formulário de Registro -->
            <form id="formRegistro" class="form" action="php/registro.php" method="POST">
                <h2>Registrar</h2>
                <input type="text" name="nome" placeholder="Nome completo" required />
                <input type="email" name="email" placeholder="E-mail" required />
                <input type="password" name="senha" placeholder="Senha" required />
                <input type="password" name="confirma_senha" placeholder="Confirmar senha" required />
                <button type="submit" class="btnIndex">Registrar</button>
            </form>
        </div>
    </div>



</body>

</html>