document.addEventListener("DOMContentLoaded", () => {
    buscarDadosApi();
});