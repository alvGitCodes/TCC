function decimalToDMS(decimal) {
    const degrees = Math.floor(decimal);
    const minutesFloat = (decimal - degrees) * 60;
    const minutes = Math.floor(minutesFloat);
    const seconds = Math.round((minutesFloat - minutes) * 60);
    return `${degrees}° ${minutes}′`;
}

function traduzir(nome, tipo) {
    if (tipo === "aspect") return traducoes.aspect[nome] || nome;
    if (tipo === "planet") return traducoes.planets[nome] || nome;
    return nome;
}

function funcHoraData(date, time) {
    const [year, month, day] = date.split("-").map(Number);
    const [hour, minute] = time.split(":").map(Number);
    return { year, month, day, hour, minute };
}

async function coordenadas(city, country) {
    const geoUrl = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)},${encodeURIComponent(country)}&format=json`;
    try {
        const response = await fetch(geoUrl);
        const data = await response.json();
        if (!data.length) throw new Error("Local não encontrado");
        const { lat, lon } = data[0];
        return { latitude: parseFloat(lat), longitude: parseFloat(lon) };
    } catch (error) {
        console.error("Erro ao buscar coordenadas:", error);
        return null;
    }
}