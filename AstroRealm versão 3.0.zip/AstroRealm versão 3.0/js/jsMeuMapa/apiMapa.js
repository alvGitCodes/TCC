async function buscarDadosApi() {
    const nome = sessionStorage.getItem("nome");
    const pais = sessionStorage.getItem("pais");
    const cidade = sessionStorage.getItem("cidade");
    const data = sessionStorage.getItem("data");
    const hora = sessionStorage.getItem("hora");

    const { year, month, day, hour, minute } = funcHoraData(data, hora);
    const coordinates = await coordenadas(cidade, pais);
    if (!coordinates) {
        mapaWrapper.innerHTML = "<p>Erro ao determinar coordenadas.</p>";
        return;
    }

    try {
        const response = await fetch("https://astrologer.p.rapidapi.com/api/v4/birth-chart", {
            method: "POST",
            headers: {
                "x-rapidapi-key": "SUA_CHAVE",
                "x-rapidapi-host": "astrologer.p.rapidapi.com",
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                subject: {
                    name: nome, year, month, day, hour, minute,
                    longitude: coordinates.longitude,
                    latitude: coordinates.latitude,
                    city: cidade, nation: pais, timezone: "UTC",
                    zodiac_type: "Tropic"
                },
                theme: 'dark',
                language: "PT",
                wheel_only: false
            })
        });

        if (!response.ok) throw new Error("Erro na API");

       const result = await response.json();
        console.log("Resposta da API:", result);//log
        renderizarMapaAstral(result);
    } catch (error) {
        console.error("Erro ao buscar dados:", error);
        mapaWrapper.innerHTML = "<p>Erro ao gerar o mapa astral.</p>";
    }
}
const btnSalvar = document.getElementById("salvarMapa");
let dadosBrutosMapa = null; // variável global para armazenar

// Botão de salvar
btnSalvar.addEventListener("click", () => {
    if (dadosBrutosMapa) {
        salvarNoBanco(dadosBrutosMapa);
    } else {
        alert("Nenhum mapa gerado ainda.");
    }
});

function salvarNoBanco(dados) {
    fetch("salvar_mapa.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mapa: dados })
    })
        .then(response => response.text())
        .then(data => {
            alert("Mapa salvo com sucesso!");
        })
        .catch(error => {
            console.error("Erro ao salvar:", error);
            alert("Erro ao salvar o mapa.");
        });
}
