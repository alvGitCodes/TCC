const meses = ['extra', 'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

const signos = { Ari: "Áries", Tau: "Touro", Gem: "Gêmeos", Can: "Câncer", Leo: "Leão", Vir: "Virgem", Lib: "Libra", Sco: "Escorpião", Sag: "Sagitário", Cap: "Capricórnio", Aqu: "Aquário", Pis: "Peixes" };

const icones = { Ari: "♈︎", Tau: "♉︎", Gem: "♊︎", Can: "♋︎", Leo: "♌︎", Vir: "♍︎", Lib: "♎︎", Sco: "♏︎", Sag: "♐︎", Cap: "♑︎", Aqu: "♒︎", Pis: "♓︎" };

const coresSignos = {
    Ari: "#FF5733", Tau: "#9ACD32", Gem: "#ADD8E6", Can: "#87CEFA", Leo: "#FFC300", Vir: "#A3C1AD",
    Lib: "#FFB6C1", Sco: "#6A0DAD", Sag: "#FF8C42", Cap: "#8B8680", Aqu: "#00CED1", Pis: "#B0E0E6"
};

const traducoes = {
    aspect: {
        conjunction: "Conjunção", opposition: "Oposição", trine: "Trígono", square: "Quadratura", sextile: "Sextil",
        quincunx: "Quincúncio", semisquare: "Semiquadratura", sesquiquadrate: "Sesquiquadratura", parallel: "Paralelo",
        contraparallel: "Contraparalelo", decile: "Décil", novile: "Novil", undecile: "Undécil", duodecile: "Duodécil",
        biquintile: "Biquintil", quintile: "Quíntil", sesquiquintile: "Sesquiquintil", tridecile: "Tridecíl"
    },
    planets: {
        Sun: "Sol", Moon: "Lua", Mercury: "Mercúrio", Venus: "Vênus", Mars: "Marte", Jupiter: "Júxiter", Saturn: "Saturno",
        Uranus: "Urano", Neptune: "Netuno", Pluto: "Plutão", Mean_North_Node: "Nodo Norte", Mean_Node: "Nodo Norte",
        Mean_South_Node: "Nodo Sul", Chiron: "Quíron", Ascendant: "Ascendente", MC: "Meio do Céu",
        "Part of Fortune": "Parte da Fortuna", Lilith: "Lilith", Mean_Lilith: "Lilith Média", Vertex: "Vértice",
        Ceres: "Ceres", Pallas: "Palas", Juno: "Juno", Vesta: "Vesta", Eris: "Éris", Sedna: "Sedna"
    }
};