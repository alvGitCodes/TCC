// ===========================
// SELETORES DE ELEMENTOS HTML
// ===========================
const mapaWrapper = document.getElementById("mapaWrapper");
const chart = document.getElementById("chart");
const nomeUsuario = document.getElementById("nomeUsuario");
const localNasc = document.getElementById("localNasc");
const dataNasc = document.getElementById("dataNasc");
const signoAscendente = document.getElementById("signoAscendente");
const signoLua = document.getElementById("signoLua");
const signoSolar = document.getElementById("signoSolar");

const btnSalvar = document.getElementById("salvarMapa");

const sol = document.getElementById("sol");
const lua = document.getElementById("lua");
const mercurio = document.getElementById("mercurio");
const venus = document.getElementById("venus");
const marte = document.getElementById("marte");
const jupiter = document.getElementById("jupiter");
const saturno = document.getElementById("saturno");
const urano = document.getElementById("urano");
const netuno = document.getElementById("netuno");
const plutao = document.getElementById("plutao");
const northNode = document.getElementById("northNode");
const chiron = document.getElementById("chiron");
const ascendente = document.getElementById("ascendente");
const mc = document.getElementById("mc");

// =======================
// DADOS DO sessionStorage
// =======================
const nome = sessionStorage.getItem("nome");
const pais = sessionStorage.getItem("pais");
const cidade = sessionStorage.getItem("cidade");
const data = sessionStorage.getItem("data");
const hora = sessionStorage.getItem("hora");

let dadosBrutosMapa = null; // variável global para armazenar

console.log("Dados recuperados do sessionStorage:", { nome, pais, cidade, data, hora });

// =====================
// EXTRAS E CONSTANTES
// =====================
const meses = ['extra', 'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
    'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

const signos = {
    Ari: "Áries",
    Tau: "Touro",
    Gem: "Gêmeos",
    Can: "Câncer",
    Leo: "Leão",
    Vir: "Virgem",
    Lib: "Libra",
    Sco: "Escorpião",
    Sag: "Sagitário",
    Cap: "Capricórnio",
    Aqu: "Aquário",
    Pis: "Peixes"
};

const icones = {
    Ari: "♈︎",
    Tau: "♉︎",
    Gem: "♊︎",
    Can: "♋︎",
    Leo: "♌︎",
    Vir: "♍︎",
    Lib: "♎︎",
    Sco: "♏︎",
    Sag: "♐︎",
    Cap: "♑︎",
    Aqu: "♒︎",
    Pis: "♓︎"
};

const coresSignos = {
    Ari: "#FF5733",
    Tau: "#9ACD32",
    Gem: "#ADD8E6",
    Can: "#87CEFA",
    Leo: "#FFC300",
    Vir: "#A3C1AD",
    Lib: "#FFB6C1",
    Sco: "#6A0DAD",
    Sag: "#FF8C42",
    Cap: "#8B8680",
    Aqu: "#00CED1",
    Pis: "#B0E0E6"
};

const traducoes = {
    aspect: {
        conjunction: "Conjunção",
        opposition: "Oposição",
        trine: "Trígono",
        square: "Quadratura",
        sextile: "Sextil",
        quincunx: "Quincúncio",
        semisquare: "Semiquadratura",
        sesquiquadrate: "Sesquiquadratura",
        parallel: "Paralelo",
        contraparallel: "Contraparalelo",
        decile: "Décil",
        novile: "Novil",
        undecile: "Undécil",
        duodecile: "Duodécil",
        biquintile: "Biquintil",
        quintile: "Quíntil",
        sesquiquintile: "Sesquiquintil",
        tridecile: "Tridecíl"
    },
    planets: {
        Sun: "Sol",
        Moon: "Lua",
        Mercury: "Mercúrio",
        Venus: "Vênus",
        Mars: "Marte",
        Jupiter: "Júpiter",
        Saturn: "Saturno",
        Uranus: "Urano",
        Neptune: "Netuno",
        Pluto: "Plutão",
        Mean_North_Node: "Nodo Norte",
        Mean_Node: "Nodo Norte",
        Mean_South_Node: "Nodo Sul",
        Chiron: "Quíron",
        Ascendant: "Ascendente",
        MC: "Meio do Céu", "Part of Fortune": "Parte da Fortuna",
        Lilith: "Lilith",
        Mean_Lilith: "Lilith Média",
        Vertex: "Vértice",
        Ceres: "Ceres",
        Pallas: "Palas",
        Juno: "Juno",
        Vesta: "Vesta",
        Eris: "Éris",
        Sedna: "Sedna"
    }
};

// =====================
// FUNÇÕES AUXILIARES
// =====================
const funcHoraData = (date, time) => {
    const [year, month, day] = date.split("-").map(Number);
    const [hour, minute] = time.split(":").map(Number);
    console.log("Componentes de data e hora:", { year, month, day, hour, minute });// Log
    return { year, month, day, hour, minute };
};

async function coordenadas(city, country) {
    const geoUrl = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(city)},${encodeURIComponent(country)}&format=json`;
    console.log("Buscando coordenadas para:", { city, country }); //log

    try {
        const response = await fetch(geoUrl);
        const data = await response.json();
        console.log("Resposta da API de coordenadas:", data); //log
        if (!data.length) throw new Error("Local não encontrado");

        const { lat, lon } = data[0];
        console.log("Coordenadas encontradas:", { latitude: lat, longitude: lon });//log

        return { latitude: parseFloat(lat), longitude: parseFloat(lon) };
    } catch (error) {
        console.error("Erro ao buscar coordenadas:", error);
        return null;
    }
}

function traduzir(nome, tipo) {
    if (tipo === "aspect") {
        return traducoes.aspect[nome] || nome;
    }
    if (tipo === "planet") {
        return traducoes.planets[nome] || nome;

    }
    return nome;
}

function decimalToDMS(decimal) {
    const degrees = Math.floor(decimal);// Parte inteira do número é o grau
    const decimalPart = decimal - degrees;// A parte decimal é a parte a ser convertida para minutos e segundos

    const minutesFloat = decimalPart * 60;// Multiplica a parte decimal por 60 para obter os minutos
    const minutes = Math.floor(minutesFloat);

    const secondsFloat = (minutesFloat - minutes) * 60;// A parte decimal dos minutos é convertida para segundos
    const seconds = Math.round(secondsFloat);

    return `${degrees}° ${minutes}′`;// Retorna o valor formatado em graus, minutos e segundos
}

// =====================
// CHAMADA À API
// =====================
async function buscarDadosApi() {
    const { year, month, day, hour, minute } = funcHoraData(data, hora);

    const localDate = new Date(Date.UTC(year, month - 1, day, hour, minute));
    console.log("Hora ajustada para BRT (UTC -3):", localDate.toISOString());

    const coordinates = await coordenadas(cidade, pais);
    if (!coordinates) {
        mapaWrapper.innerHTML = "<p>Erro ao determinar as coordenadas da cidade. Verifique os dados e tente novamente.</p>";
        return;
    }

    console.log("Dados enviados para a API:", {
        name: nome,
        year: localDate.getUTCFullYear(),
        month: localDate.getUTCMonth() + 1, // Meses começam de 0
        day: localDate.getUTCDate(),
        hour: localDate.getUTCHours(),
        minute: localDate.getUTCMinutes(),
        longitude: coordinates.longitude,
        latitude: coordinates.latitude,
        city: cidade,
        nation: pais,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone, 
        zodiac_type: "Tropic",
    });

    // API começo

    try {
        const response = await fetch("https://astrologer.p.rapidapi.com/api/v4/birth-chart", {
            method: "POST",
            headers: {
                "x-rapidapi-key": "5b16d2b17amsh6fbfe59609fd74bp140226jsn41be27e7e58b",
                "x-rapidapi-host": "astrologer.p.rapidapi.com",
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                subject: {
                    name: nome,
                    year: localDate.getUTCFullYear(),
                    month: localDate.getUTCMonth() + 1, // meses são indexados em 0
                    day: localDate.getUTCDate(),
                    hour: localDate.getUTCHours(),
                    minute: localDate.getUTCMinutes(),
                    longitude: coordinates.longitude,
                    latitude: coordinates.latitude,
                    city: cidade,
                    nation: pais,
                    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                    zodiac_type: "Tropic",
                },
                theme: 'dark',
                language: "PT",
                wheel_only: false
            })
        });

        console.log("Status da resposta da API:", response.status);

        if (!response.ok) {
            const errorText = await response.text();
            console.error("Erro na API:", errorText);
            throw new Error("Erro na API");
        }

        const result = await response.json();
        console.log("Resposta da API:", result);//log
        renderizarMapaAstral(result);

    } catch (error) {
        console.error("Erro ao buscar dados da API:", error);
        mapaWrapper.innerHTML = "<p>Ocorreu um erro ao gerar o mapa astral. Tente novamente mais tarde.</p>";
    }
}



// ===========================
// RENDERIZAÇÃO DO MAPA ASTRAL
// ===========================
function renderizarMapaAstral(dados) {
    dadosBrutosMapa = dados;
    console.log("Dados recebidos para renderizar o mapa astral:", dados);//log

    if (!dados) {
        mapaWrapper.innerHTML = "<p>Não foi possível gerar o mapa astral.</p>";
        return;
    }

    // Preencher informações principais
    nomeUsuario.innerHTML = dados.data.name;
    localNasc.innerHTML = `${dados.data.city}, ${dados.data.nation}.`;
    // dataNasc.innerHTML = `${dados.data.day} de ${meses[dados.data.month]} de ${dados.data.year}, ${dados.data.hour}:${dados.data.minute}`;
    dataNasc.innerHTML = `${dados.data.day} de ${meses[dados.data.month]} de ${dados.data.year}, ${String(dados.data.hour).padStart(2, '0')}:${String(dados.data.minute).padStart(2, '0')}`;

    chart.innerHTML = dados.chart;

    const getNomeCompletoSigno = sigla => signos[sigla];

    const getSignoCerto = (sigla) => {
        const icone = icones[sigla];
        const cor = coresSignos[sigla];
        return `<span style="color:${cor};">${icone}</span>`;
    };

    // Preencher planetas e pontos
    sol.innerHTML = '☉ Sol em ' + decimalToDMS(dados.data.sun.position) + ' ' + getSignoCerto(dados.data.sun.sign) + ' ' + getNomeCompletoSigno(dados.data.sun.sign);
    lua.innerHTML = '☽ Lua em ' + decimalToDMS(dados.data.moon.position) + ' ' + getSignoCerto(dados.data.moon.sign) + ' ' + getNomeCompletoSigno(dados.data.moon.sign);
    mercurio.innerHTML = '☿ Mercúrio em ' + decimalToDMS(dados.data.mercury.position) + ' ' + getSignoCerto(dados.data.mercury.sign) + ' ' + getNomeCompletoSigno(dados.data.mercury.sign);
    venus.innerHTML = '♀︎ Vênus em ' + decimalToDMS(dados.data.venus.position) + ' ' + getSignoCerto(dados.data.venus.sign) + ' ' + getNomeCompletoSigno(dados.data.venus.sign);
    marte.innerHTML = '♂︎ Marte em ' + decimalToDMS(dados.data.mars.position) + ' ' + getSignoCerto(dados.data.mars.sign) + ' ' + getNomeCompletoSigno(dados.data.mars.sign);
    jupiter.innerHTML = '♃ Júpiter em ' + decimalToDMS(dados.data.jupiter.position) + ' ' + getSignoCerto(dados.data.jupiter.sign) + ' ' + getNomeCompletoSigno(dados.data.jupiter.sign);
    saturno.innerHTML = '♄ Saturno em ' + decimalToDMS(dados.data.saturn.position) + ' ' + getSignoCerto(dados.data.saturn.sign) + ' ' + getNomeCompletoSigno(dados.data.saturn.sign);
    urano.innerHTML = '♅ Urano em ' + decimalToDMS(dados.data.uranus.position) + ' ' + getSignoCerto(dados.data.uranus.sign) + ' ' + getNomeCompletoSigno(dados.data.uranus.sign);
    netuno.innerHTML = '♆ Netuno em ' + decimalToDMS(dados.data.neptune.position) + ' ' + getSignoCerto(dados.data.neptune.sign) + ' ' + getNomeCompletoSigno(dados.data.neptune.sign);
    plutao.innerHTML = '♇ Plutão em ' + decimalToDMS(dados.data.pluto.position) + ' ' + getSignoCerto(dados.data.pluto.sign) + ' ' + getNomeCompletoSigno(dados.data.pluto.sign);
    northNode.innerHTML = '☊ Nodo Norte em ' + decimalToDMS(dados.data.true_node.position) + ' ' + getSignoCerto(dados.data.true_node.sign) + ' ' + getNomeCompletoSigno(dados.data.true_node.sign);
    chiron.innerHTML = '⚷ Chiron em ' + decimalToDMS(dados.data.chiron.position) + ' ' + getSignoCerto(dados.data.chiron.sign) + ' ' + getNomeCompletoSigno(dados.data.chiron.sign);
    ascendente.innerHTML = '♁ Ascendente em ' + decimalToDMS(dados.data.ascendant.position) + ' ' + getSignoCerto(dados.data.ascendant.sign) + ' ' + getNomeCompletoSigno(dados.data.ascendant.sign);
    mc.innerHTML = '♁ MC em ' + decimalToDMS(dados.data.tenth_house.position) + ' ' + getSignoCerto(dados.data.tenth_house.sign) + ' ' + getNomeCompletoSigno(dados.data.tenth_house.sign);

    signoSolar.innerHTML = getSignoCerto(dados.data.sun.sign) + ' ' + getNomeCompletoSigno(dados.data.sun.sign);

    signoAscendente.innerHTML = getSignoCerto(dados.data.first_house.sign) + ' ' + getNomeCompletoSigno(dados.data.first_house.sign);

    signoLua.innerHTML = getSignoCerto(dados.data.moon.sign) + ' ' + getNomeCompletoSigno(dados.data.moon.sign);

    // Renderizar aspectos
    const aspectosContainer = document.getElementById("aspectos");
    aspectosContainer.innerHTML = "";

    if (dados.aspects) {
        dados.aspects.forEach(aspecto => {
            const aspectoDiv = document.createElement("div");
            aspectoDiv.classList.add("aspecto");

            const p1Nome = traduzir(aspecto.p1_name, "planet");
            const p2Nome = traduzir(aspecto.p2_name, "planet");
            const aspectName = traduzir(aspecto.aspect, "aspect");

            if (aspecto.orbit >= 0) {
                aspectoDiv.innerHTML = `${p1Nome} ${aspectName} ${p2Nome} <span style="color:#00A2FF; font-size: 0.8em; font-weight: 500;">orb ${aspecto.orbit.toFixed(0)} °</span>`;
                // aspectoDiv.innerHTML = `${p1Nome} ${aspectName} ${p2Nome} <span style="color:#00A2FF; font-size: 0.8em;">Órbita: ${aspecto.orbit.toFixed(2)}°</span>`;
            } else {
                aspectoDiv.innerHTML = `${p1Nome} ${aspectName} ${p2Nome} <span style="color:rgb(255, 92, 16); font-size: 0.8em; font-weight: 500;">orb ${aspecto.orbit.toFixed(0)} °</span>`;
            }

            aspectosContainer.appendChild(aspectoDiv);
        });
    } else {
        aspectosContainer.innerHTML = "<p>Não há aspectos disponíveis para este mapa astral.</p>";
    }

    console.log("Mapa Astral Renderizado");

    // Atualiza a variável com os dados brutos do mapa para o botão de salvar

}


// Botão de salvar
btnSalvar.addEventListener("click", () => {
    if (!dadosBrutosMapa) {
        alert("Nenhum mapa astral carregado.");
        return;
    }

    fetch("php/salvar_mapa.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            mapa: JSON.stringify(dadosBrutosMapa) // transforma o objeto em string JSON
        })
    })
        .then(response => response.text())
        .then(data => {
            console.log("Resposta do PHP:", data);
            alert(data); // Exibe a mensagem do PHP (sucesso ou erro)
        })
        .catch(error => {
            console.error("Erro ao salvar mapa:", error);
            alert("Erro ao salvar o mapa astral.");
        });
});


function salvarNoBanco(dados) {
    const dadosParaSalvar = {
        // nome: dados.data.name,
        // cidade: dados.data.city,
        // pais: dados.data.nation,
        // data: `${dados.data.day} de ${meses[dados.data.month]} de ${dados.data.year}`,
        // hora: `${String(dados.data.hour).padStart(2, '0')}:${String(dados.data.minute).padStart(2, '0')}`,
        mapaAstral: dados.data
    };

    console.log("Dados a serem salvos:", dadosParaSalvar);

    // Aqui você pode implementar a lógica para salvar os dados no banco de dados
    // Por exemplo, usando uma requisição fetch para uma API que salva os dados

    alert("Mapa astral salvo com sucesso!");
}


// =====================
// EXECUÇÃO INICIAL
// =====================
// buscarDadosApi();


