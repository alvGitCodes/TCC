const btnCalcular = document.getElementById("btnCalcular");
const descricaoPar = document.getElementById("descricaoPar");

const cartasTarot = {
    1: { nome: "O Mago", imagem: "../imagens/cartas/o_mago.jpg" },
    2: { nome: "A Sacerdotisa", imagem: "../imagens/cartas/a_sacerdotisa.jpg" },
    3: { nome: "A Imperatriz", imagem: "../imagens/cartas/a_imperatriz.jpg" },
    4: { nome: "O Imperador", imagem: "../imagens/cartas/o_imperador.jpg" },
    5: { nome: "O Hierofante", imagem: "../imagens/cartas/o_hierofante.jpg" },
    6: { nome: "Os Enamorados", imagem: "../imagens/cartas/os_enamorados.jpg" },
    7: { nome: "O Carro", imagem: "../imagens/cartas/o_carro.jpg" },
    8: { nome: "A Força", imagem: "../imagens/cartas/a_forca.jpg" },
    9: { nome: "O Eremita", imagem: "../imagens/cartas/o_ermitão.jpg" },
    10: { nome: "A Roda da Fortuna", imagem: "../imagens/cartas/a_roda_da_fortuna.jpg" },
    11: { nome: "A Justiça", imagem: "../imagens/cartas/a_justica.jpg" },
    12: { nome: "O Enforcado", imagem: "../imagens/cartas/o_enforcado.jpg" },
    13: { nome: "A Morte", imagem: "../imagens/cartas/a_morte.jpg" },
    14: { nome: "A Temperança", imagem: "../imagens/cartas/a_temperanca.jpg" },
    15: { nome: "O Diabo", imagem: "../imagens/cartas/o_diabo.jpg" },
    16: { nome: "A Torre", imagem: "../imagens/cartas/a_torre.jpg" },
    17: { nome: "A Estrela", imagem: "../imagens/cartas/a_estrela.jpg" },
    18: { nome: "A Lua", imagem: "../imagens/cartas/a_lua.jpg" },
    19: { nome: "O Sol", imagem: "../imagens/cartas/o_sol.jpg" },
    20: { nome: "O Julgamento", imagem: "../imagens/cartas/o_julgamento.jpg" },
    21: { nome: "O Mundo", imagem: "../imagens/cartas/o_mundo.jpg" }
};

btnCalcular.addEventListener("click", function () {
    const dia = parseInt(document.getElementById("dia").value);
    const mes = parseInt(document.getElementById("mes").value);
    const ano = parseInt(document.getElementById("ano").value);

    if (!dia || !mes || !ano) {
        alert("Preencha corretamente dia, mês e ano.");
        return;
    }

    let anoBase = ano >= 2000 ? 20 : 19;
    console.log(`Ano base: ${anoBase}`);
    let soma = mes + dia + anoBase + (ano % 100);
    console.log(`Soma inicial: ${soma}`);
    let carta1 = 0;
    let carta2 = 0;
    let carta3 = null;

    // Redução conforme instruções
    if (soma > 99) {
        let str = soma.toString();
        carta1 = parseInt(str.substring(0, 2)) + parseInt(str.substring(2));
    } else {
        carta1 = soma;
    }

    // Exceção para 19
    if (carta1 === 19) {
        carta2 = 10;
        carta3 = 1;
    } else {
        // Segunda carta é a redução da primeira
        carta2 = [...carta1.toString()].reduce((a, b) => a + parseInt(b), 0);
    }

    // Atualizar visualmente
    const c1 = cartasTarot[carta1];
    const c2 = cartasTarot[carta2];
    const c3 = carta3 ? cartasTarot[carta3] : null;

    let cartaA = document.getElementById("cartaA");
    let cartaB = document.getElementById("cartaB");

    cartaA.innerHTML = `<img src="${c1.imagem}" alt="${c1.nome}"><p>${c1.nome}</p>`;
    cartaB.innerHTML = `<img src="${c2.imagem}" alt="${c2.nome}"><p>${c2.nome}</p>`;

    if (c3) {
        if (!document.getElementById("cartaC")) {
            let novaCarta = document.createElement("div");
            novaCarta.id = "cartaC";
            document.getElementById("cartasDescobertas").appendChild(novaCarta);
        }
        const cartaC = cartasTarot[carta3];
        document.getElementById("cartaC").innerHTML = `<img src="${cartaC.imagem}" alt="${cartaC.nome}"><p>${cartaC.nome}</p>`;
    } else {
        const cartaC = document.getElementById("cartaC");
        if (cartaC) cartaC.remove();
    }

    if (c1.nome === "A Morte" && c2.nome === "O Imperador") {
        descricaoPar.innerHTML = `
        <h3>A Morte (XIII) - Carta 1:</h3>
        <p>
            A Morte, frequentemente mal interpretada, não é um fim literal, mas um símbolo poderoso de transformação e renascimento. 
            Representa o momento crucial de abandonar o velho para dar espaço ao novo. Essa carta sugere que, ao longo da vida, 
            você passará por grandes mudanças, muitas vezes inesperadas, mas sempre necessárias para o seu crescimento. 
            Ao contrário do que possa parecer, não é um presságio de algo negativo, mas um convite para deixar para trás o que não serve mais, 
            seja em termos de crenças, relacionamentos ou fases da vida. Cada transformação traz consigo a possibilidade de uma nova jornada, 
            mais alinhada com seu verdadeiro eu.
        </p>
        
        <h3>O Imperador (IV) – Carta 2:</h3>
        <p>
            O Imperador simboliza a autoridade, a estabilidade e a liderança. Essa carta indica que você tem um forte senso de estrutura e controle, 
            além de uma habilidade natural para comandar e organizar o ambiente ao seu redor. Sua energia é racional, lógica e voltada para a construção 
            de bases sólidas, tanto no campo pessoal quanto no profissional. Há em você uma tendência a buscar segurança através da ordem e da responsabilidade, 
            valorizando regras claras e objetivos bem definidos. Sua força está na capacidade de manter a compostura mesmo em situações desafiadoras, 
            tomando decisões firmes e ponderadas.
        </p>

        <h3>Interpretação:</h3>
        <p>
            A combinação entre A Morte e O Imperador revela uma dinâmica interessante entre mudança e estrutura. 
            Você tem o dom raro de equilibrar transformação e estabilidade — é capaz de reformular sua vida completamente, 
            sem perder o eixo central da sua identidade. Quando algo chega ao fim, você reconstrói com base sólida, 
            aprendendo com a experiência e mantendo a disciplina necessária para seguir adiante. 
            Essa dualidade permite que você seja alguém que se reinventa com sabedoria: 
            abraça o novo com coragem, mas sem abrir mão dos princípios que sustentam sua caminhada. 
            Sua evolução acontece em ciclos, sempre apoiada por um senso profundo de ordem interna.
        </p>
    `
    } else if (c1.nome === "A Roda da Fortuna" && c2.nome === "O Mago") {
        descricaoPar.innerHTML = `
        <h3>A Roda da Fortuna (X) - Carta 1:</h3>
        <p>
            A Roda da Fortuna simboliza os ciclos imprevisíveis da vida, as viradas inesperadas do destino e a impermanência de todas as coisas. 
            Ela lembra que nada é fixo, e que a sorte pode mudar a qualquer instante — para melhor ou para pior. 
            Essa carta convida à aceitação do fluxo natural da existência e à confiança de que, mesmo nos altos e baixos, 
            há uma ordem maior se desdobrando.
        </p>

        <h3>O Mago (I) – Carta 2:</h3>
        <p>
            O Mago representa o poder pessoal, a iniciativa e a capacidade de transformar ideias em realidade. 
            Ele domina os quatro elementos e age com plena consciência de seu potencial criativo. 
            Com o Mago, surge a mensagem de que você possui todas as ferramentas necessárias para moldar sua vida, 
            bastando direcionar sua energia com intenção clara e foco determinado.
        </p>

        <h3>Interpretação:</h3>
        <p>
            Juntas, essas cartas revelam um equilíbrio entre destino e vontade. 
            Mostram que, embora a vida traga eventos fora de seu controle, você tem o poder de responder a eles 
            com criatividade e ação consciente. O segredo está em reconhecer quando fluir com os ventos do destino 
            e quando agir com intencionalidade para guiar o curso.
        </p>
    `
    } else if (c1.nome === "A Justiça" && c2.nome === "A Sacerdotisa") {
        descricaoPar.innerHTML = `
        <h3>A Justiça (XI) - Carta 1:</h3>
        <p>
            A Justiça fala sobre equilíbrio, verdade e responsabilidade. Ela busca o discernimento imparcial e a sabedoria ética, 
            exigindo que decisões sejam tomadas com base em fatos e consequências. Essa carta aponta para um momento em que você deve 
            encarar as repercussões de suas ações com clareza, ponderação e honestidade.
        </p>

        <h3>A Sacerdotisa (II) – Carta 2:</h3>
        <p>
            A Sacerdotisa representa o mistério, a intuição e os conhecimentos ocultos. 
            Ela guarda os segredos que só podem ser acessados através do silêncio e da contemplação profunda. 
            Sua presença convida à introspecção e à confiança em sua sabedoria interior, além do que é visto ou dito.
        </p>

        <h3>Interpretação:</h3>
        <p>
            Esse par une razão e intuição, sugerindo que as melhores decisões vêm do equilíbrio entre lógica e sensibilidade espiritual. 
            Ele ensina que justiça verdadeira não vem apenas de regras externas, mas também do entendimento profundo e silencioso do coração.
        </p>
    `
    } else if (c1.nome === "O Enforcado" && c2.nome === "A Imperatriz") {
        descricaoPar.innerHTML = `
        <h3>O Enforcado (XII) - Carta 1:</h3>
        <p>
            O Enforcado representa uma pausa voluntária, uma rendição ao momento presente para alcançar uma nova perspectiva. 
            Ele ensina que nem toda ação leva ao progresso — às vezes, é necessário esperar, refletir ou ver as coisas de um ângulo 
            totalmente diferente para encontrar sentido ou direção.
        </p>

        <h3>A Imperatriz (III) – Carta 2:</h3>
        <p>
            A Imperatriz simboliza abundância, nutrição e a conexão com a natureza e o feminino criativo. 
            Ela traz uma energia fértil e protetora, ligada ao crescimento orgânico, ao cuidado com os outros e com o próprio corpo. 
            É uma carta de amor, beleza e prosperidade interior.
        </p>

        <h3>Interpretação:</h3>
        <p>
            Juntas, essas cartas sugerem que o florescimento pessoal muitas vezes requer paciência e entrega. 
            Antes de colher frutos, é necessário compreender os processos internos e respeitar os ciclos da vida. 
            Ao suspender o ritmo acelerado, você encontra um solo mais fértil dentro de si para cultivar aquilo que deseja.
        </p>
    `
    } else if (c1.nome === "A Temperança" && c2.nome === "O Hierophante") {
        descricaoPar.innerHTML = `
        <h3>A Temperança (XIV) - Carta 1:</h3>
        <p>
            A Temperança fala de moderação, harmonia e integração. Ela convida à união dos opostos, à paciência e à busca de equilíbrio 
            em todas as áreas da vida. Essa carta é um lembrete de que o caminho mais sábio é aquele trilhado com calma e consciência, 
            onde tudo tem seu tempo certo.
        </p>

        <h3>O Hierofante (V) – Carta 2:</h3>
        <p>
            O Hierofante representa tradição, espiritualidade institucionalizada e sabedoria ancestral. 
            Ele simboliza a orientação que vem de mestres, sistemas de crença ou estruturas sociais. 
            É uma figura de autoridade espiritual que transmite conhecimento dentro de padrões estabelecidos.
        </p>

        <h3>Interpretação:</h3>
        <p>
            Este par traz uma mensagem de crescimento espiritual equilibrado. 
            Enquanto o Hierofante oferece os alicerces da tradição e do ensinamento formal, 
            a Temperança sugere que a verdadeira evolução vem da capacidade de integrar esses valores com flexibilidade e discernimento. 
            Caminhar entre estrutura e liberdade é o desafio e a chave.
        </p>
    `
    } else if (c1.nome === "O Diabo" && c2.nome === "Os Enamorados") {
        descricaoPar.innerHTML = `
        <h3>O Diabo (XV) - Carta 1:</h3>
        <p>
            O Diabo representa as amarras, os vícios, os desejos intensos e as ilusões que aprisionam. 
            Ele traz à tona os aspectos da sombra, os apegos destrutivos e a necessidade de confrontar aquilo que limita a liberdade pessoal. 
            Não é um vilão, mas um espelho que revela onde você pode estar se sabotando.
        </p>

        <h3>Os Enamorados (VI) – Carta 2:</h3>
        <p>
            Os Enamorados representam escolhas significativas, vínculos emocionais e a busca pela união genuína. 
            Essa carta fala sobre amor, parceria e a importância de decisões feitas com o coração, mesmo que envolvam desafios.
        </p>

        <h3>Interpretação:</h3>
        <p>
            Unidos, esses arcanos revelam a dualidade do desejo e da liberdade. 
            O par alerta para relações ou decisões que podem parecer intensas ou sedutoras, mas que precisam ser examinadas com atenção. 
            O verdadeiro amor e a verdadeira escolha surgem quando você reconhece e se liberta das ilusões que o prendem.
        </p>
    `
    } else if (c1.nome === "A Torre" && c2.nome === "O Carro") {
        descricaoPar.innerHTML = `
        <h3>A Torre (XVI) - Carta 1:</h3>
        <p>
            A Torre é uma ruptura súbita, um colapso necessário que destrói ilusões e estruturas que já não sustentam o crescimento. 
            Apesar de chocante, essa carta traz libertação — abre espaço para a verdade e para um novo começo construído com mais autenticidade.
        </p>

        <h3>O Carro (VII) – Carta 2:</h3>
        <p>
            O Carro representa conquista, controle e determinação. Ele conduz a energia para a frente com foco, coragem e disciplina. 
            Essa carta indica que, com força de vontade e direção clara, é possível superar obstáculos e alcançar metas importantes.
        </p>

        <h3>Interpretação:</h3>
        <p>
            Esse par mostra que, mesmo diante da queda, há um impulso interior capaz de se reerguer com mais força. 
            A destruição trazida pela Torre é o estopim para o movimento audaz do Carro — um chamado para se libertar do passado 
            e seguir com convicção rumo ao novo.
        </p>
    `
    } else if (c1.nome === "A Estrela" && c2.nome === "A Força") {
        descricaoPar.innerHTML = `
        <h3>A Estrela (XVII) - Carta 1:</h3>
        <p>
            A Estrela é símbolo de esperança, cura e inspiração. Ela oferece um vislumbre de luz após tempos difíceis, acalmando o espírito 
            e conectando-o com a beleza e a paz do universo. Essa carta é uma promessa silenciosa de que dias melhores virão, 
            e que a fé pode ser restaurada.
        </p>

        <h3>A Força (VIII) – Carta 2:</h3>
        <p>
            A Força representa domínio emocional, coragem interior e compaixão. 
            Ela não impõe pela força bruta, mas sim pela gentileza e autocontrole. 
            Sua energia fala de firmeza com ternura, de poder sustentado pelo coração.
        </p>

        <h3>Interpretação:</h3>
        <p>
            Juntas, essas cartas compõem uma mensagem de resiliência luminosa. Mesmo nos momentos de fragilidade, há força. 
            E mesmo diante da luta, há esperança. Este par encoraja você a enfrentar os desafios com serenidade e confiança, 
            sabendo que a luz interior nunca se apaga.
        </p>
    `
    } else if (c1.nome === "A Lua" && c2.nome === "O Eremita") {
        descricaoPar.innerHTML = `
        <h3>A Lua (XVIII) - Carta 1:</h3>
        <p>
            A Lua representa mistério, intuição e ilusões. Ela conduz por caminhos incertos, onde nem tudo é o que parece, 
            desafiando você a confiar em seus sentimentos mais profundos e a navegar pelos territórios do inconsciente. 
            É uma carta que pede cuidado com enganos e atenção ao mundo interno.
        </p>

        <h3>O Eremita (IX) – Carta 2:</h3>
        <p>
            O Eremita é o buscador solitário da sabedoria. Ele se afasta do ruído externo para ouvir a própria alma, 
            guiado por sua lanterna interior. Essa carta representa introspecção, paciência e a busca por significados mais profundos na vida.
        </p>

        <h3>Interpretação:</h3>
        <p>
            Juntos, esses arcanos indicam um tempo de silêncio e autoconhecimento profundo. 
            Há lições valiosas a serem descobertas nos territórios sombrios da mente, desde que você caminhe com cautela e reflexão. 
            A verdade não está nas aparências, mas no que é revelado no escuro.
        </p>
    `
    } else if (c1.nome === "O Sol" && c2.nome === "A Roda da Fortuna" && c3.nome === "O Mago") {
        descricaoPar.innerHTML = `
        <h3>O Sol (XIX) - Carta 1:</h3>
        <p>
            O Sol irradia clareza, vitalidade e alegria. Ele dissolve dúvidas e traz à tona tudo o que é verdadeiro, 
            iluminando a consciência e celebrando o sucesso pessoal. Essa carta é um símbolo de autenticidade, confiança e otimismo renovado.
        </p>

        <h3>A Roda da Fortuna (X) – Carta 2:</h3>
        <p>
            A Roda da Fortuna gira trazendo mudanças imprevisíveis, que desafiam o controle, mas que também oferecem novas possibilidades. 
            Ela lembra que, mesmo nas reviravoltas, há propósito e sabedoria no fluxo dos acontecimentos.
        </p>

        <h3>O Mago (I) – Carta 3:</h3>
        <p>
            O Mago manifesta sua realidade com foco e intenção. Ele é o criador de oportunidades, aquele que transforma potencial em ação. 
            Essa carta lembra que você tem poder de iniciativa, e que seus pensamentos moldam sua experiência.
        </p>

        <h3>Interpretação:</h3>
        <p>
            Esse trio combina luz, transformação e ação consciente. Você está em um momento fértil, onde a clareza do Sol, 
            as mudanças da Roda e a vontade do Mago convergem para impulsionar a criação de uma nova fase. 
            Aproveite esse ciclo com consciência e coragem.
        </p>
    `
    } else if (c1.nome === "O Julgamento" && c2.nome === "A Sacerdotisa") {
        descricaoPar.innerHTML = `
        <h3>O Julgamento (XX) - Carta 1:</h3>
        <p>
            O Julgamento marca um momento de despertar espiritual, chamado à responsabilidade e renascimento. 
            Ele sugere que é hora de encarar as consequências das escolhas passadas e, ao mesmo tempo, de se libertar de antigos fardos 
            para seguir em frente com um propósito mais elevado.
        </p>

        <h3>A Sacerdotisa (II) – Carta 2:</h3>
        <p>
            A Sacerdotisa representa a introspecção, o mistério e a sabedoria silenciosa. 
            Ela convida a ouvir a intuição, mergulhar nas profundezas da alma e confiar nos sinais que não são ditos em voz alta. 
            Sua presença fala de conexão com o sagrado e o oculto.
        </p>

        <h3>Interpretação:</h3>
        <p>
            Este par une o chamado externo à verdade com a escuta interna. 
            É um momento de despertar espiritual profundo, onde sua alma está sendo convocada a se alinhar com um propósito maior, 
            mas essa resposta só pode vir do silêncio e da escuta interior.
        </p>
    `
    } else if (c1.nome === "O Mundo" && c2.nome === "A Imperatriz") {
        descricaoPar.innerHTML = `
        <h3>O Mundo (XXI) - Carta 1:</h3>
        <p>
            O Mundo simboliza realização, completude e integração. 
            É o fim de um ciclo e o início de outro, onde tudo o que foi aprendido se manifesta em uma nova consciência. 
            Essa carta celebra o êxito conquistado com esforço e crescimento verdadeiro.
        </p>

        <h3>A Imperatriz (III) – Carta 2:</h3>
        <p>
            A Imperatriz traz a energia da criação, fertilidade e expressão amorosa. 
            Ela representa o nascimento de ideias, projetos e relações em solo fértil, nutrido por carinho e atenção.
        </p>

        <h3>Interpretação:</h3>
        <p>
            Juntas, essas cartas falam de uma fase de plenitude criativa. 
            Você chegou a um ponto de maturidade e realização, e agora está pronto para criar e nutrir algo novo a partir desse lugar de abundância. 
            O ciclo se fecha, e uma nova criação floresce com amor e propósito.
        </p>
    `
    }

});

