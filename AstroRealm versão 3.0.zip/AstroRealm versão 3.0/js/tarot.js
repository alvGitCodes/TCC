let cartas = [];

fetch("cartas.json")
  .then(res => res.json())
  .then(data => {
    cartas = data;
  });

function tirarCartas() {
  if (cartas.length < 3) {
    alert("Cartas ainda carregando...");
    return;
  }

  // Sorteia 3 cartas diferentes
  const sorteadas = [];
  while (sorteadas.length < 3) {
    const carta = cartas[Math.floor(Math.random() * cartas.length)];
    if (!sorteadas.includes(carta)) {
      sorteadas.push(carta);
    }
  }

  const posicoes = ["Passado", "Presente", "Futuro"];
  const container = document.getElementById("resultadoTarot");
  container.innerHTML = "";

  sorteadas.forEach((carta, i) => {
    const div = document.createElement("div");
    div.className = "carta";
    div.innerHTML = `
      <h2>${posicoes[i]}: ${carta.name}</h2>
      <p><strong>Significado:</strong> ${carta.meaning_up}</p>
      <p><em>${carta.desc}</em></p>
    `;
    container.appendChild(div);
  });
}
