<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/layoutSignos.css">
    <link rel="stylesheet" href="../css/footer.css">

    <script src="../js/cssGeral.js" defer></script>

    <title>Peixes</title>
</head>

<body>
    <div id="content">
        <header>
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <li class="menuItem"><a href="../horoscopo.php">Horóscopo</a></li>
                    <li class="menuItem dropdown">
                        <a href="../signos.php">Os Signos</a>
                        <ul class="dropdown-content">
                            <li><a href="aries.php">Áries</a></li>
                            <li><a href="touro.php">Touro</a></li>
                            <li><a href="gemeos.php">Gêmeos</a></li>
                            <li><a href="cancer.php">Câncer</a></li>
                            <li><a href="leao.php">Leão</a></li>
                            <li><a href="virgem.php">Virgem</a></li>
                            <li><a href="libra.php">Libra</a></li>
                            <li><a href="escorpiao.php">Escorpião</a></li>
                            <li><a href="sagitario.php">Sagitário</a></li>
                            <li><a href="capricornio.php">Capricórnio</a></li>
                            <li><a href="aquario.php">Aquário</a></li>
                            <li><a href="peixes.php">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                </ul>

                <div id="divPerfil">
                <?php if (isset($_SESSION['usuario_nome'])): ?>
                    <a href="../perfil.php" class="usuario-logado">
                        <div id="divWrapPerfil">
                            <?php
                            $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                            ?>
                            <img src="../imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                            <div id="divInfoLogado">
                                <h3>Meu Perfil</h3>
                                <div>
                                    <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php else: ?>
                    <a href="../login.php">Login</a>
                <?php endif; ?>
            </div>

            </nav>
        </header>

        <div id="conteudoSignos">
            <table id="cabecalho">
                <tr>
                    <td id="divImageSign">
                        <span class="agua">♓︎</span>
                    </td>
                    <td id="tituloSign">
                        Signo do Zodíaco: Peixes
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <ul id="listCharSigns">
                            <li><strong>Elemento:</strong> Água</li>
                            <li><strong>Cor:</strong> Verde-mar, Lilás</li>
                            <li><strong>Planeta Regente:</strong> Netuno</li>
                            <li><strong>Melhor Compatibilidade:</strong> Câncer, Escorpião</li>
                            <li><strong>Período Correspondente:</strong> 19 de Fevereiro à 20 de Março</li>
                        </ul>
                    </td>
                </tr>
            </table>

            <a href="../horoscoposGerais.php?signo=pisces"><button id="btnPrevisoes">Previsões Para Peixes</button></a>

            <div id="infoSigno">

                <h2 id="chamadaSigno">Peixes: O Sonhador do Zodíaco</h2>

                <p style="margin-bottom: -20px;">
                    Peixes é o último signo do zodíaco, representando a espiritualidade, a empatia e a intuição. Regido
                    por <strong>Netuno</strong>, o planeta da inspiração e da imaginação, Peixes é um signo profundo,
                    sensível e sonhador. As pessoas nascidas sob este signo (aproximadamente entre <strong>19 de
                        fevereiro e 20 de março</strong>) são conhecidas por sua natureza intuitiva e compassiva.
                </p>

                <h3 class="blockTitle">✨Características Positivas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Empatia:</strong> Peixes tem uma incrível capacidade de se colocar no lugar do outro e
                        compreender as emoções alheias.</li>
                    <li><strong>Intuição:</strong> Peixes é extremamente intuitivo, muitas vezes tomando decisões
                        baseadas em um sentimento profundo que vai além da razão.</li>
                    <li><strong>Criatividade:</strong> Pessoas de Peixes são criativas e têm uma grande imaginação,
                        sendo frequentemente atraídas por atividades artísticas e espirituais.</li>
                    <li><strong>Generosidade:</strong> Peixes tem um coração generoso e está sempre disposto a ajudar os
                        outros, especialmente aqueles em situações difíceis.</li>
                </ul>

                <h3 class="blockTitle">👿Características Negativas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Escapismo:</strong> Quando se sentem sobrecarregados, os piscianos podem se afastar da
                        realidade e se refugiar em mundos imaginários ou vícios.</li>
                    <li><strong>Indecisão:</strong> A forte intuição de Peixes pode, às vezes, torná-los indecisos, pois
                        são influenciados por suas emoções e pelas necessidades dos outros.</li>
                    <li><strong>Vitimismo:</strong> Em alguns momentos, Peixes pode se sentir vítima das circunstâncias,
                        o que pode levá-los a se entregar ao pessimismo ou ao desânimo.</li>
                </ul>

                <h3 class="blockTitle">🤝Relacionamentos e Carreira</h3>
                <p>
                    <strong>Relacionamentos:</strong><br>
                    Nos relacionamentos, Peixes é extremamente amoroso, romântico e leal. Os piscianos são parceiros
                    dedicados que buscam uma conexão profunda e emocional com seus entes queridos. Eles se dão bem com
                    pessoas que são compreensivas e que valorizam a intuição e a empatia.
                </p>
                <p>
                    <strong>Carreira:</strong><br>
                    Profissões relacionadas à arte, à música e ao cuidado com os outros são ideais para Peixes. São bons
                    em áreas como psicologia, medicina, trabalho social e qualquer ocupação que envolva apoio emocional
                    ou criatividade.
                </p>

                <h3 class="blockTitle">♥️Compatibilidade com Outros Signos</h3>
                <p>
                    Peixes se dá bem com outros signos de <strong>Água</strong> (Câncer, Escorpião), que compartilham
                    sua natureza sensível e emocional. Também pode ter boa compatibilidade com signos de
                    <strong>Terra</strong> (Touro, Virgem, Capricórnio), que trazem equilíbrio e estabilidade às suas
                    vidas.
                </p>

                <h3 class="blockTitle">😎Piscianos Famosos</h3>
                <ul class="listaInfoSign">
                    <li><strong>Albert Einstein:</strong> Físico</li>
                    <li><strong>Rihanna:</strong> Cantora</li>
                    <li><strong>Chuck Norris:</strong> Ator e artista marcial</li>
                    <li><strong>Bruce Willis:</strong> Ator</li>
                    <li><strong>Eva Mendes:</strong> Atriz</li>
                </ul>

                <p>
                    Peixes é um signo de grande profundidade emocional e espiritual. Eles são sonhadores, sensíveis e
                    generosos, com uma forte conexão com sua intuição e a arte!
                </p>
                <a href="../mapaGratis.html">
                    <div class="btnPrevisoesBot">Criar Mapa Gratuito</div>
                </a>
            </div>
        </div>
    </div>

    <footer>
        <div id="footerContent">

            <div id="footerDivs">

                <div id="logoWrapper">
                    <div id="logoFooter">Astro<span id="spanFooter">Realm</span></div>
                    <p>
                        Descubra seu destino e conecte-se com o universo através da astrologia. <br>Explore os
                        mistérios
                        dos
                        signos e muito mais!
                    </p>
                </div>

                <div class="colunaFooter">
                    <h3>Contato</h3>
                    <ul>
                        <li>Email: contato@astrorealm.com</li>
                        <li>Telefone: (11) 1234-5678</li>
                        <li>
                            <ul id="redesSociaisLinks">
                                <li><a href="https://github.com/alvGitCodes"><img
                                            src="../imagens/icones footer/github_1051275.png" title="GitHub"
                                            alt="github">
                                        <div>Github</div>
                                    </a></li>
                                <li><a href=""><img src="../imagens/icones footer/linkedin_1051282.png" title="Linkedin"
                                            alt="linkedin">LinkedIn</a></li>
                                <li><a href=""><img src="../imagens/icones footer/whatsapp_1051272.png"
                                            alt="">WhatsApp</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="colunaFooter">
                    <h3>Recursos</h3>
                    <ul class="reucursosLinks">
                        <li><a href="https://freepik.com/">Freepik</a></li>
                        <li><a href="https://rapidapi.com/">Rapid Api</a></li>
                        <li><a href="https://rapidapi.com/gbattaglia/api/astrologer">Astrologer</a></li>
                        <li><a href="https://rapidapi.com/ashutosh.devil7/api/horoscope19">Horoscope</a></li>
                        <li><a href="https://rapidapi.com/gatzuma/api/deep-translate1">Deep Translate</a></li>
                    </ul>
                </div>

            </div>

            <p class="footerCredits">© 2024 AstroRealm. Todos os direitos reservados. Imagens por Freepik.</p>
    </footer>

    <button id="scrollToTopBtn" title="Voltar ao topo">&#11205;</button>
</body>

</html>