<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/layoutSignos.css">
    <link rel="stylesheet" href="../css/footer.css">

    <script src="../js/cssGeral.js" defer></script>

    <title>Aries</title>
</head>

<body>
    <div id="content">
        <header>
            <!-- <div id="contato"></div> -->
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <li class="menuItem"><a href="../horoscopo.php">Horóscopo</a></li>

                    <!-- Menu Dropdown para Signos do Zodíaco -->
                    <li class="menuItem dropdown">
                        <a href="../signos.php">Os Signos</a>
                        <ul class="dropdown-content">
                            <li><a href="aries.php">Áries</a></li>
                            <li><a href="touro.php">Touro</a></li>
                            <li><a href="gemeos.php">Gêmeos</a></li>
                            <li><a href="cancer.php">Câncer</a></li>
                            <li><a href="leao.php">Leão</a></li>
                            <li><a href="virgem.php">Virgem</a></li>
                            <li><a href="libra.php">Libra</a></li>
                            <li><a href="escorpiao.php">Escorpião</a></li>
                            <li><a href="sagitario.php">Sagitário</a></li>
                            <li><a href="capricornio.php">Capricórnio</a></li>
                            <li><a href="aquario.php">Aquário</a></li>
                            <li><a href="peixes.php">Peixes</a></li>
                        </ul>
                    </li>

                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                </ul>

                <div id="divPerfil">
                <?php if (isset($_SESSION['usuario_nome'])): ?>
                    <a href="../perfil.php" class="usuario-logado">
                        <div id="divWrapPerfil">
                            <?php
                            $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                            ?>
                            <img src="../imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                            <div id="divInfoLogado">
                                <h3>Meu Perfil</h3>
                                <div>
                                    <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php else: ?>
                    <a href="../login.php">Login</a>
                <?php endif; ?>
            </div>

            </nav>

        </header>

        <div id="conteudoSignos">

            <table id="cabecalho">
                <tr>
                    <td id="divImageSign">
                        <span class="fogo">♈︎</span>
                    </td>
                    <td id="tituloSign">
                        Signo do Zodíaco: Áries
                    </td>
                </tr>
                <tr>
                    <td>

                    </td>
                    <td>
                        <ul id="listCharSigns">
                            <li><strong>Elemento:</strong> Fogo</li>
                            <li><strong>Cor:</strong> Vermelho</li>
                            <li><strong>Planeta Regente:</strong> Marte</li>
                            <li><strong>Melhor Compatibilidade:</strong> Leão, Sagitário</li>
                            <li><strong>Período Correspondente:</strong> 21 de Março à 19 de Abril</li>
                        </ul>
                    </td>
                </tr>
            </table>

            <a href="../horoscoposGerais.php?signo=aries"><button id="btnPrevisoes">Previsões Para Áries</button></a>

            <div id="infoSigno">

                <h2 id="chamadaSigno">Áries: O Pioneiro do Zodíaco</h2>

                <p style="margin-bottom: -20px;">
                    Áries é o primeiro signo do zodíaco, associado ao elemento <strong>Fogo</strong> e regido pelo
                    planeta
                    <strong>Marte</strong>, o deus da guerra na mitologia romana. Os nascidos sob esse signo
                    (aproximadamente entre
                    <strong>21 de março e 19 de abril</strong>) são conhecidos por sua energia, determinação e impulso.
                </p>

                <h3 class="blockTitle">✨Características Positivas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Coragem e ousadia:</strong> Arianos têm a coragem de perseguir o que desejam,
                        enfrentando desafios sem hesitar. Eles são destemidos quando se trata de explorar o
                        desconhecido.</li>
                    <li><strong>Determinação e iniciativa:</strong> Este é um signo de liderança. Pessoas de Áries
                        adoram tomar a frente e fazer as coisas acontecerem.</li>
                    <li><strong>Espontaneidade:</strong> Sua energia vibrante os torna impulsivos, o que frequentemente
                        leva a aventuras emocionantes.</li>
                    <li><strong>Entusiasmo e vitalidade:</strong> Eles vivem a vida com paixão e contagiam os outros com
                        sua disposição otimista.</li>
                </ul>

                <h3 class="blockTitle">👿Características Negativas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Impulsividade e impaciência:</strong> O desejo de agir rapidamente pode levar a decisões
                        precipitadas, sem considerar as consequências.</li>
                    <li><strong>Temperamento forte:</strong> Quando contrariados, os arianos podem reagir de forma
                        explosiva e até agressiva, especialmente se sentirem que seu ritmo não é acompanhado.</li>
                    <li><strong>Egocentrismo:</strong> Arianos podem ser tão focados em si mesmos que às vezes são
                        percebidos como egoístas.</li>
                </ul>

                <h3 class="blockTitle">🤝Relacionamentos e Carreira</h3>
                <p>
                    <strong>Relacionamentos</strong><br>
                    Intensos e apaixonados, arianos mergulham de cabeça nos relacionamentos. Eles buscam parceiros que
                    compartilhem sua energia e entusiasmo, mas também exigem reciprocidade emocional.
                </p>

                <p>
                    <strong>Carreira</strong><br>
                    Áries se destaca em ambientes competitivos. Com habilidades naturais de liderança e disposição para
                    assumir riscos, eles brilham como empreendedores, líderes ou inovadores.
                </p>

                <h3 class="blockTitle">♥️Compatibilidade com Outros Signos</h3>
                <p>
                    Áries geralmente combina bem com signos de <strong>Fogo</strong> (Leão e Sagitário) e
                    <strong>Ar</strong> (Gêmeos, Libra e Aquário), que acompanham sua energia. No entanto, as relações
                    com signos de <strong>Terra</strong> (Touro, Virgem, Capricórnio) e <strong>Água</strong> (Câncer,
                    Escorpião, Peixes) podem ser mais desafiadoras devido às diferenças de ritmo e abordagem emocional.
                </p>

                <h3 class="blockTitle">😎Arianos Famosos</h3>
                <ul class="listaInfoSign">
                    <li><strong>Maradona:</strong> Futebolista</li>
                    <li><strong>Lady Gaga:</strong> Cantora</li>
                    <li><strong>Robert Downey Jr.:</strong> Ator</li>
                    <li><strong>Emma Watson:</strong> Atriz</li>
                    <li><strong>Eddie Murphy:</strong> Ator e comediante</li>
                </ul>

                <p>
                    Áries, com sua natureza dinâmica e destemida, é o pioneiro do zodíaco, sempre em busca de novos
                    desafios e pronto para tomar as rédeas da própria vida!
                </p>
                <a href="../mapaGratis.html">
                    <div class="btnPrevisoesBot">Criar Mapa Gratuito</div>
                </a>
            </div>
        </div>
    </div>

    <footer>
        <div id="footerContent">

            <div id="footerDivs">

                <div id="logoWrapper">
                    <div id="logoFooter">Astro<span id="spanFooter">Realm</span></div>
                    <p>
                        Descubra seu destino e conecte-se com o universo através da astrologia. <br>Explore os
                        mistérios
                        dos
                        signos e muito mais!
                    </p>
                </div>

                <div class="colunaFooter">
                    <h3>Contato</h3>
                    <ul>
                        <li>Email: contato@astrorealm.com</li>
                        <li>Telefone: (11) 1234-5678</li>
                        <li>
                            <ul id="redesSociaisLinks">
                                <li><a href="https://github.com/alvGitCodes"><img
                                            src="../imagens/icones footer/github_1051275.png" title="GitHub"
                                            alt="github">
                                        <div>Github</div>
                                    </a></li>
                                <li><a href=""><img src="../imagens/icones footer/linkedin_1051282.png" title="Linkedin"
                                            alt="linkedin">LinkedIn</a></li>
                                <li><a href=""><img src="../imagens/icones footer/whatsapp_1051272.png"
                                            alt="">WhatsApp</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="colunaFooter">
                    <h3>Recursos</h3>
                    <ul class="reucursosLinks">
                        <li><a href="https://freepik.com/">Freepik</a></li>
                        <li><a href="https://rapidapi.com/">Rapid Api</a></li>
                        <li><a href="https://rapidapi.com/gbattaglia/api/astrologer">Astrologer</a></li>
                        <li><a href="https://rapidapi.com/ashutosh.devil7/api/horoscope19">Horoscope</a></li>
                        <li><a href="https://rapidapi.com/gatzuma/api/deep-translate1">Deep Translate</a></li>
                    </ul>
                </div>

            </div>

            <p class="footerCredits">© 2024 AstroRealm. Todos os direitos reservados. Imagens por Freepik.</p>
    </footer>

    <button id="scrollToTopBtn" title="Voltar ao topo">&#11205;</button>
</body>

</html>