<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/layoutSignos.css">
    <link rel="stylesheet" href="../css/footer.css">

    <script src="../js/cssGeral.js" defer></script>

    <title>Leão</title>
</head>

<body>
    <div id="content">
        <header>
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <li class="menuItem"><a href="../horoscopo.php">Horóscopo</a></li>
                    <li class="menuItem dropdown">
                        <a href="../signos.php">Os Signos</a>
                        <ul class="dropdown-content">
                            <li><a href="aries.php">Áries</a></li>
                            <li><a href="touro.php">Touro</a></li>
                            <li><a href="gemeos.php">Gêmeos</a></li>
                            <li><a href="cancer.php">Câncer</a></li>
                            <li><a href="leao.php">Leão</a></li>
                            <li><a href="virgem.php">Virgem</a></li>
                            <li><a href="libra.php">Libra</a></li>
                            <li><a href="escorpiao.php">Escorpião</a></li>
                            <li><a href="sagitario.php">Sagitário</a></li>
                            <li><a href="capricornio.php">Capricórnio</a></li>
                            <li><a href="aquario.php">Aquário</a></li>
                            <li><a href="peixes.php">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                </ul>

                <div id="divPerfil">
                <?php if (isset($_SESSION['usuario_nome'])): ?>
                    <a href="../perfil.php" class="usuario-logado">
                        <div id="divWrapPerfil">
                            <?php
                            $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                            ?>
                            <img src="../imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                            <div id="divInfoLogado">
                                <h3>Meu Perfil</h3>
                                <div>
                                    <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php else: ?>
                    <a href="../login.php">Login</a>
                <?php endif; ?>
            </div>

            </nav>
        </header>

        <div id="conteudoSignos">
            <table id="cabecalho">
                <tr>
                    <td id="divImageSign">
                        <span class="fogo">♌︎</span>
                    </td>
                    <td id="tituloSign">
                        Signo do Zodíaco: Leão
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <ul id="listCharSigns">
                            <li><strong>Elemento:</strong> Fogo</li>
                            <li><strong>Cor:</strong> Dourado</li>
                            <li><strong>Planeta Regente:</strong> Sol</li>
                            <li><strong>Melhor Compatibilidade:</strong> Áries, Sagitário</li>
                            <li><strong>Período Correspondente:</strong> 23 de Julho à 22 de Agosto</li>
                        </ul>
                    </td>
                </tr>
            </table>

            <a href="../horoscoposGerais.php?signo=leo"><button id="btnPrevisoes">Previsões Para Leão</button></a>

            <div id="infoSigno">
                <h2 id="chamadaSigno">Leão: O Rei do Zodíaco</h2>
                <p style="margin-bottom: -20px;">
                    Leão é o quinto signo do zodíaco, associado ao elemento <strong>Fogo</strong> e regido pelo
                    <strong>Sol</strong>, símbolo de vitalidade e brilho.
                    Nascidos entre <strong>23 de julho e 22 de agosto</strong>, leoninos são conhecidos por sua
                    confiança, carisma e desejo de liderança.
                </p>

                <h3 class="blockTitle">✨Características Positivas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Confiança:</strong> Leoninos exalam uma aura de segurança que atrai as pessoas ao seu
                        redor.</li>
                    <li><strong>Generosidade:</strong> São calorosos e adoram ajudar, sempre que possível.</li>
                    <li><strong>Lealdade:</strong> Protegem aqueles que amam e são amigos fiéis.</li>
                    <li><strong>Carisma:</strong> Seu brilho natural os torna o centro das atenções, onde quer que
                        estejam.</li>
                </ul>

                <h3 class="blockTitle">👿Características Negativas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Orgulho:</strong> Leoninos podem ter dificuldade em admitir erros ou aceitar críticas.
                    </li>
                    <li><strong>Teimosia:</strong> Quando acreditam estar certos, é difícil convencê-los do contrário.
                    </li>
                    <li><strong>Necessidade de atenção:</strong> Às vezes, exageram na busca por validação externa.</li>
                </ul>

                <h3 class="blockTitle">🤝Relacionamentos e Carreira</h3>
                <p>
                    <strong>Relacionamentos:</strong><br>
                    Apaixonados e leais, leoninos buscam parceiros que os admirem e compartilhem sua energia. Eles têm
                    uma natureza protetora e gostam de mostrar afeto.
                </p>
                <p>
                    <strong>Carreira:</strong><br>
                    Carreiras que permitam liderança ou criatividade, como gestão, artes cênicas ou publicidade, são
                    ideais para Leão. Eles se destacam em posições que os permitam brilhar.
                </p>

                <h3 class="blockTitle">♥️Compatibilidade com Outros Signos</h3>
                <p>
                    Leão combina bem com outros signos de <strong>Fogo</strong> (Áries, Sagitário), que compartilham seu
                    entusiasmo, e com signos de <strong>Ar</strong> (Gêmeos, Libra), que equilibram sua energia. Com
                    signos de <strong>Água</strong> e <strong>Terra</strong>, o relacionamento pode exigir mais esforço.
                </p>

                <h3 class="blockTitle">😎Leoninos Famosos</h3>
                <ul class="listaInfoSign">
                    <li><strong>Madonna:</strong> Cantora</li>
                    <li><strong>Barack Obama:</strong> Político</li>
                    <li><strong>Jennifer Lopez:</strong> Atriz e cantora</li>
                    <li><strong>Daniel Radcliffe:</strong> Ator</li>
                    <li><strong>Whitney Houston:</strong> Cantora</li>
                </ul>

                <p>
                    Leão é o sol que aquece o zodíaco, trazendo vitalidade, confiança e brilho para todos ao seu redor.
                </p>
                <a href="../mapaGratis.html">
                    <div class="btnPrevisoesBot">Criar Mapa Gratuito</div>
                </a>
            </div>
        </div>
    </div>

    <footer>
        <div id="footerContent">

            <div id="footerDivs">

                <div id="logoWrapper">
                    <div id="logoFooter">Astro<span id="spanFooter">Realm</span></div>
                    <p>
                        Descubra seu destino e conecte-se com o universo através da astrologia. <br>Explore os
                        mistérios
                        dos
                        signos e muito mais!
                    </p>
                </div>

                <div class="colunaFooter">
                    <h3>Contato</h3>
                    <ul>
                        <li>Email: contato@astrorealm.com</li>
                        <li>Telefone: (11) 1234-5678</li>
                        <li>
                            <ul id="redesSociaisLinks">
                                <li><a href="https://github.com/alvGitCodes"><img
                                            src="../imagens/icones footer/github_1051275.png" title="GitHub"
                                            alt="github">
                                        <div>Github</div>
                                    </a></li>
                                <li><a href=""><img src="../imagens/icones footer/linkedin_1051282.png" title="Linkedin"
                                            alt="linkedin">LinkedIn</a></li>
                                <li><a href=""><img src="../imagens/icones footer/whatsapp_1051272.png"
                                            alt="">WhatsApp</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="colunaFooter">
                    <h3>Recursos</h3>
                    <ul class="reucursosLinks">
                        <li><a href="https://freepik.com/">Freepik</a></li>
                        <li><a href="https://rapidapi.com/">Rapid Api</a></li>
                        <li><a href="https://rapidapi.com/gbattaglia/api/astrologer">Astrologer</a></li>
                        <li><a href="https://rapidapi.com/ashutosh.devil7/api/horoscope19">Horoscope</a></li>
                        <li><a href="https://rapidapi.com/gatzuma/api/deep-translate1">Deep Translate</a></li>
                    </ul>
                </div>

            </div>

            <p class="footerCredits">© 2024 AstroRealm. Todos os direitos reservados. Imagens por Freepik.</p>
    </footer>

    <button id="scrollToTopBtn" title="Voltar ao topo">&#11205;</button>
</body>

</html>