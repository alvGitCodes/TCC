<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/layoutSignos.css">
    <link rel="stylesheet" href="../css/footer.css">

    <script src="../js/cssGeral.js" defer></script>

    <title>Touro</title>
</head>

<body>
    <div id="content">
        <header>
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <li class="menuItem"><a href="../horoscopo.php">Horóscopo</a></li>
                    <li class="menuItem dropdown">
                        <a href="../signos.php">Os Signos</a>
                        <ul class="dropdown-content">
                            <li><a href="aries.php">Áries</a></li>
                            <li><a href="touro.php">Touro</a></li>
                            <li><a href="gemeos.php">Gêmeos</a></li>
                            <li><a href="cancer.php">Câncer</a></li>
                            <li><a href="leao.php">Leão</a></li>
                            <li><a href="virgem.php">Virgem</a></li>
                            <li><a href="libra.php">Libra</a></li>
                            <li><a href="escorpiao.php">Escorpião</a></li>
                            <li><a href="sagitario.php">Sagitário</a></li>
                            <li><a href="capricornio.php">Capricórnio</a></li>
                            <li><a href="aquario.php">Aquário</a></li>
                            <li><a href="peixes.php">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                </ul>

                <div id="divPerfil">
                    <?php if (isset($_SESSION['usuario_nome'])): ?>
                        <a href="../perfil.php" class="usuario-logado">
                            <div id="divWrapPerfil">
                                <?php
                                $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                                ?>
                                <img src="../imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                                <div id="divInfoLogado">
                                    <h3>Meu Perfil</h3>
                                    <div>
                                        <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php else: ?>
                        <a href="../login.php">Login</a>
                    <?php endif; ?>
                </div>

            </nav>
        </header>

        <div id="conteudoSignos">
            <table id="cabecalho">
                <tr>
                    <td id="divImageSign">
                        <span class="terra">♉︎</span>
                    </td>
                    <td id="tituloSign">
                        Signo do Zodíaco: Touro
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <ul id="listCharSigns">
                            <li><strong>Elemento:</strong> Terra</li>
                            <li><strong>Cor:</strong> Verde</li>
                            <li><strong>Planeta Regente:</strong> Vênus</li>
                            <li><strong>Melhor Compatibilidade:</strong> Virgem, Capricórnio</li>
                            <li><strong>Período Correspondente:</strong> 20 de Abril à 20 de Maio</li>
                        </ul>
                    </td>
                </tr>
            </table>

            <a href="../horoscoposGerais.php?signo=taurus"><button id="btnPrevisoes">Previsões Para Touro</button></a>

            <div id="infoSigno">

                <h2 id="chamadaSigno">Touro: O Construtor da Estabilidade</h2>

                <p style="margin-bottom: -20px;">
                    Touro é o segundo signo do zodíaco, associado ao elemento <strong>Terra</strong> e regido pelo
                    planeta
                    <strong>Vênus</strong>, o que confere aos taurinos uma natureza prática, amor pela beleza e pela
                    estabilidade.
                    Os nascidos sob este signo (aproximadamente entre <strong>20 de abril e 20 de maio</strong>) são
                    conhecidos por sua
                    paciência, determinação e busca por conforto.
                </p>

                <h3 class="blockTitle">✨Características Positivas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Persistência:</strong> Taurinos são determinados e não desistem facilmente de seus
                        objetivos.</li>
                    <li><strong>Confiabilidade:</strong> São confiáveis e leais, especialmente em relacionamentos e no
                        trabalho.</li>
                    <li><strong>Praticidade:</strong> Touro tem uma abordagem prática para a vida, buscando soluções
                        sensatas para os desafios.</li>
                    <li><strong>Estabilidade:</strong> Eles valorizam a segurança e estão sempre em busca de construir
                        uma base sólida para o futuro.</li>
                </ul>

                <h3 class="blockTitle">👿Características Negativas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Teimosia:</strong> Quando Touro decide algo, é difícil mudar sua opinião.</li>
                    <li><strong>Materialismo:</strong> Podem ser excessivamente focados em bens materiais e conforto.
                    </li>
                    <li><strong>Lentidão:</strong> Sua natureza prática pode fazê-los parecer lentos para mudanças ou
                        novos desafios.</li>
                </ul>

                <h3 class="blockTitle">🤝Relacionamentos e Carreira</h3>
                <p>
                    <strong>Relacionamentos:</strong><br>
                    Taurinos buscam relacionamentos duradouros e significativos. Eles são parceiros leais, mas esperam o
                    mesmo nível
                    de compromisso em troca.
                </p>
                <p>
                    <strong>Carreira:</strong><br>
                    Touro se destaca em áreas que exigem paciência e atenção aos detalhes. Profissões relacionadas a
                    finanças, design,
                    agricultura ou culinária combinam com sua personalidade prática.
                </p>

                <h3 class="blockTitle">♥️Compatibilidade com Outros Signos</h3>
                <p>
                    Touro geralmente combina bem com signos de <strong>Terra</strong> (Virgem, Capricórnio) e
                    <strong>Água</strong> (Câncer,
                    Escorpião, Peixes), que apreciam sua estabilidade. No entanto, os signos de <strong>Fogo</strong> e
                    <strong>Ar</strong> podem
                    achar sua natureza um pouco lenta ou teimosa.
                </p>

                <h3 class="blockTitle">😎Taurinos Famosos</h3>
                <ul class="listaInfoSign">
                    <li><strong>Adele:</strong> Cantora</li>
                    <li><strong>David Beckham:</strong> Jogador de futebol</li>
                    <li><strong>Gigi Hadid:</strong> Modelo</li>
                    <li><strong>George Clooney:</strong> Ator</li>
                    <li><strong>William Shakespeare:</strong> Escritor</li>
                </ul>

                <p>
                    Touro, com sua natureza firme e confiável, é um signo que valoriza a construção de uma vida segura e
                    confortável.
                </p>
                <a href="../mapaGratis.html">
                    <div class="btnPrevisoesBot">Criar Mapa Gratuito</div>
                </a>
            </div>
        </div>
    </div>

    <footer>
        <div id="footerContent">

            <div id="footerDivs">

                <div id="logoWrapper">
                    <div id="logoFooter">Astro<span id="spanFooter">Realm</span></div>
                    <p>
                        Descubra seu destino e conecte-se com o universo através da astrologia. <br>Explore os
                        mistérios
                        dos
                        signos e muito mais!
                    </p>
                </div>

                <div class="colunaFooter">
                    <h3>Contato</h3>
                    <ul>
                        <li>Email: contato@astrorealm.com</li>
                        <li>Telefone: (11) 1234-5678</li>
                        <li>
                            <ul id="redesSociaisLinks">
                                <li><a href="https://github.com/alvGitCodes"><img
                                            src="../imagens/icones footer/github_1051275.png" title="GitHub"
                                            alt="github">
                                        <div>Github</div>
                                    </a></li>
                                <li><a href=""><img src="../imagens/icones footer/linkedin_1051282.png" title="Linkedin"
                                            alt="linkedin">LinkedIn</a></li>
                                <li><a href=""><img src="../imagens/icones footer/whatsapp_1051272.png"
                                            alt="">WhatsApp</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="colunaFooter">
                    <h3>Recursos</h3>
                    <ul class="reucursosLinks">
                        <li><a href="https://freepik.com/">Freepik</a></li>
                        <li><a href="https://rapidapi.com/">Rapid Api</a></li>
                        <li><a href="https://rapidapi.com/gbattaglia/api/astrologer">Astrologer</a></li>
                        <li><a href="https://rapidapi.com/ashutosh.devil7/api/horoscope19">Horoscope</a></li>
                        <li><a href="https://rapidapi.com/gatzuma/api/deep-translate1">Deep Translate</a></li>
                    </ul>
                </div>

            </div>

            <p class="footerCredits">© 2024 AstroRealm. Todos os direitos reservados. Imagens por Freepik.</p>
    </footer>

    <button id="scrollToTopBtn" title="Voltar ao topo">&#11205;</button>
</body>

</html>