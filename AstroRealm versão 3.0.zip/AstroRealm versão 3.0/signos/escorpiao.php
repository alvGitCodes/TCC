<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/layoutSignos.css">
    <link rel="stylesheet" href="../css/footer.css">

    <script src="../js/cssGeral.js" defer></script>

    <title>Escorpião</title>
</head>

<body>
    <div id="content">
        <header>
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <li class="menuItem"><a href="../horoscopo.php">Horóscopo</a></li>
                    <li class="menuItem dropdown">
                        <a href="../signos.php">Os Signos</a>
                        <ul class="dropdown-content">
                            <li><a href="aries.php">Áries</a></li>
                            <li><a href="touro.php">Touro</a></li>
                            <li><a href="gemeos.php">Gêmeos</a></li>
                            <li><a href="cancer.php">Câncer</a></li>
                            <li><a href="leao.php">Leão</a></li>
                            <li><a href="virgem.php">Virgem</a></li>
                            <li><a href="libra.php">Libra</a></li>
                            <li><a href="escorpiao.php">Escorpião</a></li>
                            <li><a href="sagitario.php">Sagitário</a></li>
                            <li><a href="capricornio.php">Capricórnio</a></li>
                            <li><a href="aquario.php">Aquário</a></li>
                            <li><a href="peixes.php">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                </ul>

                <div id="divPerfil">
                <?php if (isset($_SESSION['usuario_nome'])): ?>
                    <a href="../perfil.php" class="usuario-logado">
                        <div id="divWrapPerfil">
                            <?php
                            $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                            ?>
                            <img src="../imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                            <div id="divInfoLogado">
                                <h3>Meu Perfil</h3>
                                <div>
                                    <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php else: ?>
                    <a href="../login.php">Login</a>
                <?php endif; ?>
            </div>

            </nav>
        </header>

        <div id="conteudoSignos">
            <table id="cabecalho">
                <tr>
                    <td id="divImageSign">
                        <span class="agua">♏︎</span>
                    </td>
                    <td id="tituloSign">
                        Signo do Zodíaco: Escorpião
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <ul id="listCharSigns">
                            <li><strong>Elemento:</strong> Água</li>
                            <li><strong>Cor:</strong> Vermelho, preto</li>
                            <li><strong>Planeta Regente:</strong> Plutão</li>
                            <li><strong>Melhor Compatibilidade:</strong> Câncer, Peixes</li>
                            <li><strong>Período Correspondente:</strong> 23 de Outubro à 21 de Novembro</li>
                        </ul>
                    </td>
                </tr>
            </table>

            <a href="../horoscoposGerais.php?signo=scorpio"><button id="btnPrevisoes">Previsões Para
                    Escorpião</button></a>

            <div id="infoSigno">

                <h2 id="chamadaSigno">Escorpião: O Mestre da Transformação</h2>

                <p style="margin-bottom: -20px;">
                    Escorpião é o oitavo signo do zodíaco, associado ao elemento <strong>Água</strong> e regido por
                    <strong>Plutão</strong>, o planeta da transformação. Os nativos deste signo, nascidos entre
                    <strong>23 de outubro e 21 de novembro</strong>, são conhecidos por sua intensidade, mistério e
                    paixão.
                </p>

                <h3 class="blockTitle">✨Características Positivas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Intensidade emocional:</strong> Escorpianos sentem tudo de maneira profunda e intensa, o
                        que os torna extremamente leais e apaixonados.</li>
                    <li><strong>Determinação:</strong> Quando estabelecem um objetivo, escorpianos não param até
                        alcançá-lo. Sua perseverança é uma das suas maiores forças.</li>
                    <li><strong>Habilidade investigativa:</strong> São naturalmente curiosos e têm uma habilidade única
                        para descobrir segredos e entender as motivações das pessoas.</li>
                    <li><strong>Transformação:</strong> Escorpianos são excelentes em se reinventar, aproveitando a
                        capacidade de mudança e crescimento pessoal.</li>
                </ul>

                <h3 class="blockTitle">👿Características Negativas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Ciúmes e possessividade:</strong> O desejo de controlar pode levar a sentimentos de
                        ciúmes e possessividade, especialmente em relacionamentos.</li>
                    <li><strong>Vingança:</strong> Escorpianos podem ser vingativos quando se sentem traídos ou
                        injustiçados, guardando rancor por longos períodos.</li>
                    <li><strong>Teimosia:</strong> Eles são conhecidos por sua teimosia e por insistirem em suas
                        próprias opiniões, mesmo que isso cause conflitos.</li>
                </ul>

                <h3 class="blockTitle">🤝Relacionamentos e Carreira</h3>
                <p>
                    <strong>Relacionamentos:</strong><br>
                    Escorpianos são parceiros intensos e leais, mas também exigem um nível de profundidade emocional em
                    seus relacionamentos. Eles buscam um amor verdadeiro e estão dispostos a se entregar completamente,
                    mas não toleram traições.
                </p>
                <p>
                    <strong>Carreira:</strong><br>
                    Com uma mente aguçada e uma forte ética de trabalho, Escorpião se destaca em profissões que exigem
                    investigação, psicologia, medicina e gestão de crises. Eles são ótimos em lidar com situações
                    difíceis e complexas.
                </p>

                <h3 class="blockTitle">♥️Compatibilidade com Outros Signos</h3>
                <p>
                    Escorpião é mais compatível com outros signos de <strong>Água</strong> (Câncer, Peixes), que
                    compartilham sua profunda natureza emocional. Eles também podem se dar bem com
                    <strong>Terra</strong> (Touro, Virgem, Capricórnio), pois os ajudam a se estabilizar.
                </p>

                <h3 class="blockTitle">😎Escorpianos Famosos</h3>
                <ul class="listaInfoSign">
                    <li><strong>Katy Perry:</strong> Cantora</li>
                    <li><strong>Leonardo DiCaprio:</strong> Ator</li>
                    <li><strong>Ryan Gosling:</strong> Ator</li>
                    <li><strong>Bill Gates:</strong> Empresário</li>
                    <li><strong>Emma Stone:</strong> Atriz</li>
                </ul>

                <p>
                    Escorpião é um signo poderoso e transformador, sempre em busca de profundidade, autenticidade e
                    emoção. Seu magnetismo e paixão o tornam inesquecível para aqueles que entram em seu círculo.
                </p>
                <a href="../mapaGratis.html">
                    <div class="btnPrevisoesBot">Criar Mapa Gratuito</div>
                </a>
            </div>
        </div>
    </div>

    <footer>
        <div id="footerContent">

            <div id="footerDivs">

                <div id="logoWrapper">
                    <div id="logoFooter">Astro<span id="spanFooter">Realm</span></div>
                    <p>
                        Descubra seu destino e conecte-se com o universo através da astrologia. <br>Explore os
                        mistérios
                        dos
                        signos e muito mais!
                    </p>
                </div>

                <div class="colunaFooter">
                    <h3>Contato</h3>
                    <ul>
                        <li>Email: contato@astrorealm.com</li>
                        <li>Telefone: (11) 1234-5678</li>
                        <li>
                            <ul id="redesSociaisLinks">
                                <li><a href="https://github.com/alvGitCodes"><img
                                            src="../imagens/icones footer/github_1051275.png" title="GitHub"
                                            alt="github">
                                        <div>Github</div>
                                    </a></li>
                                <li><a href=""><img src="../imagens/icones footer/linkedin_1051282.png" title="Linkedin"
                                            alt="linkedin">LinkedIn</a></li>
                                <li><a href=""><img src="../imagens/icones footer/whatsapp_1051272.png"
                                            alt="">WhatsApp</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="colunaFooter">
                    <h3>Recursos</h3>
                    <ul class="reucursosLinks">
                        <li><a href="https://freepik.com/">Freepik</a></li>
                        <li><a href="https://rapidapi.com/">Rapid Api</a></li>
                        <li><a href="https://rapidapi.com/gbattaglia/api/astrologer">Astrologer</a></li>
                        <li><a href="https://rapidapi.com/ashutosh.devil7/api/horoscope19">Horoscope</a></li>
                        <li><a href="https://rapidapi.com/gatzuma/api/deep-translate1">Deep Translate</a></li>
                    </ul>
                </div>

            </div>

            <p class="footerCredits">© 2024 AstroRealm. Todos os direitos reservados. Imagens por Freepik.</p>
    </footer>

    <button id="scrollToTopBtn" title="Voltar ao topo">&#11205;</button>
</body>

</html>