<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['redirecionar_para'] = '../colecao.php';
    header("Location: login.php");
    exit();
}

// Verifica se o ID do mapa foi passado pela URL
if (isset($_GET['id'])) {
    $mapa_id = $_GET['id'];
    $usuario_id = $_SESSION['usuario_id'];

    // Conexão com o banco de dados
    $conn = new mysqli("localhost", "root", "", "astroteste");

    if ($conn->connect_error) {
        die("Erro de conexão: " . $conn->connect_error);
    }

    // Verifica se o mapa pertence ao usuário
    $sql = "SELECT usuario_id FROM card_astral WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $mapa_id);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($mapa_usuario_id);
    $stmt->fetch();

    // Se o mapa pertence ao usuário logado, exclui
    if ($mapa_usuario_id == $usuario_id) {
        // Excluir o mapa astral
        $delete_sql = "DELETE FROM card_astral WHERE id = ?";
        $delete_stmt = $conn->prepare($delete_sql);
        $delete_stmt->bind_param("i", $mapa_id);
        if ($delete_stmt->execute()) {
            $_SESSION['mensagem'] = "Mapa excluído com sucesso!";
        } else {
            $_SESSION['mensagem'] = "Erro ao excluir o mapa!";
        }
    } else {
        $_SESSION['mensagem'] = "Você não tem permissão para excluir este mapa.";
    }

    // Fechar a conexão
    $stmt->close();
    $delete_stmt->close();
    $conn->close();
} else {
    $_SESSION['mensagem'] = "ID do mapa não encontrado!";
}

// Redireciona de volta para a página de coleção
header("Location: ../colecao.php");
exit();
?>
