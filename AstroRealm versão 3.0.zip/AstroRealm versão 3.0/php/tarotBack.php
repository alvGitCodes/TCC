<?php
// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "astroteste");

if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Número de cartas a serem tiradas
$numero_cartas = 3;  // O usuário pode escolher quantas cartas tirar

// Buscar cartas aleatórias
$sql = "SELECT * FROM cartas_tarot ORDER BY RAND() LIMIT ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $numero_cartas);
$stmt->execute();
$result = $stmt->get_result();

// Armazenar as cartas tiradas
$cartas_tiradas = [];
while ($row = $result->fetch_assoc()) {
    $cartas_tiradas[] = $row;
}

// Fechar a conexão
$stmt->close();
$conn->close();
?>