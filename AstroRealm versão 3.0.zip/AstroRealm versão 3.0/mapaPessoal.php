<?php
session_start();
require_once 'php/conexao.php'; // seu arquivo de conexão com o banco

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo "Mapa não especificado.";
    exit;
}

$mapa_id = intval($_GET['id']);
$usuario_id = $_SESSION['usuario_id'];

// Buscar o mapa astral do banco
$sql = "SELECT dados_mapa FROM mapas_astrais WHERE id = ? AND usuario_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $mapa_id, $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Mapa não encontrado.";
    exit;
}

$row = $result->fetch_assoc();
$dados_mapa = json_decode($row['dados_mapa'], true);
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mapa Pessoal</title>
    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/mapaPessoal.css">
    <link rel="stylesheet" href="css/footer.css">

    <script src="js/colecaoPessoal.js" defer></script>
</head>

<body>
    <div id="content">
        <header>
            <!-- <div id="contato"></div> -->
            <nav class="menu">
                <div id="logo" class="logoMapa"><a href="index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="index.php">Home</a></li>
                    <li class="menuItem"><a href="horoscopo.php">Horóscopo</a></li>

                    <!-- Menu Dropdown para Signos do Zodíaco -->
                    <li class="menuItem dropdown">
                        <a href="signos.php">Os Signos</a>
                        <ul class="dropdown-content">
                            <li><a href="signos/aries.php">Áries</a></li>
                            <li><a href="signos/touro.php">Touro</a></li>
                            <li><a href="signos/gemeos.php">Gêmeos</a></li>
                            <li><a href="signos/cancer.php">Câncer</a></li>
                            <li><a href="signos/leao.php">Leão</a></li>
                            <li><a href="signos/virgem.php">Virgem</a></li>
                            <li><a href="signos/libra.php">Libra</a></li>
                            <li><a href="signos/escorpiao.php">Escorpião</a></li>
                            <li><a href="signos/sagitario.php">Sagitário</a></li>
                            <li><a href="signos/capricornio.php">Capricórnio</a></li>
                            <li><a href="signos/aquario.php">Aquário</a></li>
                            <li><a href="signos/peixes.php">Peixes</a></li>
                        </ul>
                    </li>

                    <li class="menuItem"><a href="astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="colecao.php">Coleção</a></li>
                </ul>

                <div id="divPerfil">
                    <?php if (isset($_SESSION['usuario_nome'])): ?>
                        <a href="perfil.php" class="usuario-logado">
                            <div id="divWrapPerfil">
                                <?php
                                $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                                ?>
                                <img src="imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                                <div id="divInfoLogado">
                                    <h3>Meu Perfil</h3>
                                    <div>
                                        <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                    <?php endif; ?>
                </div>

            </nav>

        </header>

        <div id="conteudoMapaPessoal">
            <div id="perfilTop">
                <div id="fotoPerfil" data-sign="<?php echo $dados_mapa['data']['sun']['sign'] ?? ''; ?>">
                    <?php echo $dados_mapa['data']['sun']['emoji'] ?? ''; ?>
                </div>
                <div id="infoPerfil">
                    <h2><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></h2>
                    <div id="divInfoPessoal">
                        <div class="infoTop">
                            <div class="simboloTop"><?php echo $dados_mapa['data']['sun']['emoji'] ?? ''; ?></div>
                            <div class="signTop">Sol</div>
                        </div>
                        <div class="infoTop">
                            <div class="simboloTop"><?php echo $dados_mapa['data']['moon']['emoji'] ?? ''; ?></div>
                            <div class="signTop">Lua</div>
                        </div>
                        <div class="infoTop">
                            <div class="simboloTop"><?php echo $dados_mapa['data']['ascendant']['emoji'] ?? ''; ?></div>
                            <div class="signTop">Asc</div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- <h2 style="margin: auto; width: fit-content;">Previsões de Hoje</h2> -->
            <ul class="menuMobile">
                <li title="Horóscopo de Áries"><a href="horoscoposGerais.php?signo=aries">♈︎</a></li>
                <li title="Horóscopo de Touro"><a href="horoscoposGerais.php?signo=taurus">♉︎</a></li>
                <li title="Horóscopo de Gêmeos"><a href="horoscoposGerais.php?signo=gemini">♊︎</a></li>
                <li title="Horóscopo de Câncer"><a href="horoscoposGerais.php?signo=cancer">♋︎</a></li>
                <li title="Horóscopo de Leão"><a href="horoscoposGerais.php?signo=leo">♌︎</a></li>
                <li title="Horóscopo de Virgem"><a href="horoscoposGerais.php?signo=virgo">♍︎</a></li>
                <li title="Horóscopo de Libra"><a href="horoscoposGerais.php?signo=libra">♎︎</a></li>
                <li title="Horóscopo de Escorpião"><a href="horoscoposGerais.php?signo=scorpio">♏︎</a></li>
                <li title="Horóscopo de Sagitário"><a href="horoscoposGerais.php?signo=sagittarius">♐︎</a></li>
                <li title="Horóscopo de Capricórnio"><a href="horoscoposGerais.php?signo=capricorn">♑︎</a></li>
                <li title="Horóscopo de Aquário"><a href="horoscoposGerais.php?signo=aquarius">♒︎</a></li>
                <li title="Horóscopo de Peixes"><a href="horoscoposGerais.php?signo=pisces">♓︎</a></li>
            </ul>
            <h2>Planetas</h2>
            <div id="planetas">

                <?php
                $planetasValidos = [
                    'sun',
                    'moon',
                    'mercury',
                    'venus',
                    'mars',
                    'jupiter',
                    'saturn',
                    'uranus',
                    'neptune',
                    'pluto'
                ];

                foreach ($dados_mapa['data'] as $planeta => $info) {
                    if (!in_array($planeta, $planetasValidos)) continue;

                    echo '<div id="divPlaneta">';
                    echo '<div id="ico">' . htmlspecialchars($info['emoji']) . '</div>';
                    echo '<div id="dados">';
                    echo '<div class="nomePlaneta"><strong>' . ucfirst($planeta) . '</strong></div>';
                    echo '<div id="signoPlaneta">';
                    echo '<span id="signoPlanetaSimbolo">' . htmlspecialchars($info['emoji']) . '</span> ';
                    echo '<span id="signoPlanetaNome">' . htmlspecialchars($info['sign']) . '</span> ';
                    echo '<span>' . round($info['position'], 1) . 'º</span>';
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
                ?>
            </div>

            <hr>

            <div id="aspectos">
                <?php
                if (!empty($dados_mapa['aspects'])) {
                    echo '<h2>Aspectos Planetários</h2>';
                    echo '<div class="aspectos-container">';
                    foreach ($dados_mapa['aspects'] as $aspecto) {
                        $p1 = ucfirst($aspecto['p1_name']);
                        $p2 = ucfirst($aspecto['p2_name']);
                        $tipo = ucfirst($aspecto['aspect']);
                        $graus = round($aspecto['diff'], 1);
                        $orbit = round($aspecto['orbit'], 2);

                        echo '<div class="aspecto">';
                        echo "<strong>$p1</strong> <span class='aspecto-tipo'>$tipo</span> <strong>$p2</strong><br>";
                        echo "<span class='aspecto-diff'>Diferença: {$graus}°</span> | ";
                        echo "<span class='aspecto-orbit'>Órbita: {$orbit}°</span>";
                        echo '</div>';
                    }
                    echo '</div>';
                } else {
                    echo "<p>Nenhum aspecto encontrado.</p>";
                }
                ?>

            </div>

        </div>
    </div>
</body>

</html>