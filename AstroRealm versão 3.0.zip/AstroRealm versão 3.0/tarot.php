<?php
$cartas_tiradas = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Conexão com o banco de dados
    $conn = new mysqli("localhost", "root", "", "astroteste");

    if ($conn->connect_error) {
        die("Erro de conexão: " . $conn->connect_error);
    }

    // Número de cartas a serem tiradas
    $numero_cartas = 3;

    // Buscar cartas aleatórias
    $sql = "SELECT * FROM cartas_tarot ORDER BY RAND() LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $numero_cartas);
    $stmt->execute();
    $result = $stmt->get_result();

    // Armazenar as cartas tiradas
    while ($row = $result->fetch_assoc()) {
        $cartas_tiradas[] = $row;
    }

    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Tiragem de Tarot</title>
    <link rel="stylesheet" href="css/tarot.css">
</head>
<body>

<h1>Tiragem de Cartas de Tarot</h1>

<form method="POST">
    <button type="submit">Tirar Cartas</button>
</form>

<div class="resultados">
    <?php if (!empty($cartas_tiradas)): ?>
        <h2>Resultado da Tiragem</h2>
        <?php foreach ($cartas_tiradas as $carta): ?>
            <div class="carta">
                <img src="<?= htmlspecialchars($carta['imagem']) ?>" alt="<?= htmlspecialchars($carta['nome']) ?>">
                <h3><?= htmlspecialchars($carta['nome']) ?></h3>
                <p><strong>Tipo:</strong> <?= htmlspecialchars($carta['tipo']) ?></p>
                <p><strong>Significado:</strong> <?= htmlspecialchars($carta['significado']) ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

</body>
</html>
