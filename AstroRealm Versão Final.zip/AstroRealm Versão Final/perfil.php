<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['redirecionar_para'] = 'perfil.php';
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "astroteste");
if ($conn->connect_error) {
    die("Erro na conexão: " . $conn->connect_error);
}

$usuario_id = $_SESSION['usuario_id'];
$usuario_nome = $_SESSION['usuario_nome'];

// Atualizar dados
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Excluir conta
    if (isset($_POST['excluir_conta']) && $_POST['excluir_conta'] === '1') {
        $conn->query("DELETE FROM usuarios WHERE id = $usuario_id");
        session_destroy();
        header("Location: index.php");
        exit();
    }

    if (!empty($_POST['novo_nome'])) {
        $novo_nome = $conn->real_escape_string($_POST['novo_nome']);
        $conn->query("UPDATE usuarios SET nome = '$novo_nome' WHERE id = $usuario_id");
        $_SESSION['usuario_nome'] = $novo_nome;
        $usuario_nome = $novo_nome;
    }

    if (!empty($_POST['novo_email'])) {
        $novo_email = $conn->real_escape_string($_POST['novo_email']);
        $conn->query("UPDATE usuarios SET email = '$novo_email' WHERE id = $usuario_id");
    }

    if (!empty($_POST['nova_senha'])) {
        $nova_senha_hash = password_hash($_POST['nova_senha'], PASSWORD_DEFAULT);
        $conn->query("UPDATE usuarios SET senha = '$nova_senha_hash' WHERE id = $usuario_id");
    }

    if (!empty($_POST['foto_perfil'])) {
        $foto = $conn->real_escape_string($_POST['foto_perfil']);
        $conn->query("UPDATE usuarios SET foto = '$foto' WHERE id = $usuario_id");
        $_SESSION['usuario_foto'] = $foto;
    }
}

// Buscar foto atual
$result = $conn->query("SELECT foto FROM usuarios WHERE id = $usuario_id");
$foto = $result->fetch_assoc()['foto'] ?? 'terra.png';
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AstroRealm: Perfil do Usuário</title>
    <link rel="icon" type="image/x-icon" href="imagens/ico/argentina1.png">
    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/perfil.css">
</head>

<body>
<div id="content">
<header>
        <!-- <div id="contato"></div> -->
        <nav class="menu">
            <div id="logo"><a href="index.php">Astro<span id="logoSpan">Realm</span></a></div>
            <ul id="listaMenu">
                

            </ul>

            <div id="divPerfil">
                <?php if (isset($_SESSION['usuario_nome'])): ?>
                    <a href="perfil.php" class="usuario-logado">
                        <div id="divWrapPerfil">
                            <?php
                            $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                            ?>
                            <img src="imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                            <div id="divInfoLogado">
                                <h3>Meu Perfil</h3>
                                <div>
                                    <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php else: ?>
                    <a href="login.php">Login</a>
                <?php endif; ?>
            </div>

        </nav>

    </header>


    <div class="perfil-container">
        <h2><?= htmlspecialchars($usuario_nome) ?></h2>

        <img src="imagens/perfis/<?= htmlspecialchars($foto) ?>" class="foto-perfil" id="perfilPreview">

        <form method="POST">
            <label for="novo_nome">Alterar nome:</label>
            <input type="text" id="novo_nome" name="novo_nome" value="<?= htmlspecialchars($usuario_nome) ?>">

            <label for="novo_email">Alterar email:</label>
            <input type="email" id="novo_email" name="novo_email" placeholder="Digite seu novo email">

            <label for="nova_senha">Alterar senha:</label>
            <input type="password" id="nova_senha" name="nova_senha" placeholder="Nova senha">

            <input type="hidden" name="foto_perfil" id="fotoSelecionada" value="<?= htmlspecialchars($foto) ?>">

            <p>Escolha sua nova foto de perfil:</p>
            <div class="galeria">
                <?php
                $imagens = ['terra.png', 'marte.png', 'jupiter.png', 'venus.png', 'saturno.png'];
                foreach ($imagens as $img): ?>
                    <img src="imagens/perfis/<?= $img ?>" data-nome="<?= $img ?>" class="<?= $foto === $img ? 'selecionada' : '' ?>">
                <?php endforeach; ?>
            </div>

            <div class="botoes-acoes">
                <button type="submit">Salvar Alterações</button>
                <button type="submit" name="excluir_conta" value="1" class="botao-excluir" onclick="return confirm('Tem certeza que deseja excluir sua conta?')">Excluir Conta</button>
            </div>
        </form>

        <a class="logout" href="php/logout.php">Sair da conta</a>
    </div>

    <script>
        const imagens = document.querySelectorAll('.galeria img');
        const inputFoto = document.getElementById('fotoSelecionada');
        const preview = document.getElementById('perfilPreview');

        imagens.forEach(img => {
            img.addEventListener('click', () => {
                imagens.forEach(i => i.classList.remove('selecionada'));
                img.classList.add('selecionada');
                inputFoto.value = img.dataset.nome;
                preview.src = "imagens/perfis/" + img.dataset.nome;
            });
        });
    </script>
</div>
   
</body>

</html>