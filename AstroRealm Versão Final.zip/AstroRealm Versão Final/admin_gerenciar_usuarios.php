<?php
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$host = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'astroteste';

$conn = new mysqli($host, $usuario, $senha, $banco);
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

$sql = "SELECT id, nome, email, tipo_usuario, foto FROM usuarios";
$resultado = $conn->query($sql);

// Check for success or error messages from form submission
$sucesso = isset($_GET['sucesso']) ? "Usuário atualizado com sucesso!" : null;
$erro = isset($_GET['erro']) ? $_GET['erro'] : null;
?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AstroRealm - Gerenciar Usuários</title>
    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/admin.css">
    <link rel="icon" type="image/x-icon" href="imagens/ico/argentina1.png">
 
</head>

<body>
    <div id="topo">
        <nav class="menu menuIndex">
            <div id="logo"><a href="index.php">Astro<span id="logoSpan">Realm</span></a></div>
            <ul id="listaMenu">
                <li class="menuItem"><a href="index.php">Home</a></li>
                <li class="menuItem"><a href="horoscopo.php">Horóscopo</a></li>
                <li class="menuItem"><a href="signos.php">Os Signos</a></li>
                <li class="menuItem"><a href="astrologia.php">Astrologia</a></li>
                <li class="menuItem"><a href="etapas/etapa1.php">Tarot</a></li>
                <li class="menuItem"><a href="venda.html">Meu Mapa</a></li>
                <li class="menuItem"><a href="colecao.php">Coleção</a></li>
                <li class="menuItem"><a href="admin_gerenciar_usuarios.php" class="underline">Gerenciar Usuários</a></li>
            </ul>
            <div id="divPerfil">
                <a href="perfil.php" class="usuario-logado">
                    <div id="divWrapPerfil">
                        <img src="imagens/perfis/<?php echo htmlspecialchars($_SESSION['usuario_foto'] ?? 'terra.png'); ?>" alt="Foto do Usuário" aria-label="Foto de perfil do usuário">
                        <div id="divInfoLogado">
                            <h3>Meu Perfil</h3>
                            <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                        </div>
                    </div>
                </a>
            </div>
        </nav>
        <div id="content">
            <h2>Gerenciar Usuários</h2>
            <?php if ($sucesso): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo htmlspecialchars($sucesso); ?>
                    <span class="close" aria-label="Fechar alerta">×</span>
                </div>
            <?php endif; ?>
            <?php if ($erro): ?>
                <div class="alert alert-error" role="alert">
                    <?php echo htmlspecialchars($erro); ?>
                    <span class="close" aria-label="Fechar alerta">×</span>
                </div>
            <?php endif; ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Tipo</th>
                        <th>Foto</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($usuario = $resultado->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $usuario['id']; ?></td>
                            <td><?php echo htmlspecialchars($usuario['nome']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['email']); ?></td>
                            <td><?php echo $usuario['tipo_usuario']; ?></td>
                            <td><img src="imagens/perfis/<?php echo htmlspecialchars($usuario['foto']); ?>" alt="Foto de <?php echo htmlspecialchars($usuario['nome']); ?>" style="width: 50px; height: 50px; border-radius: 50%;"></td>
                            <td>
                                
                                 <a href="editar_usuario.php?id=<?php echo $usuario['id']; ?>" class="btnEdit edit">Editar</a>
                                <a href="php/excluir_usuario.php?id=<?php echo $usuario['id']; ?>" class="btnEdit secondary" onclick="return confirm('Tem certeza que deseja excluir este usuário?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <a href="index.php" class="btnEdit secondary">Voltar</a>
        </div>
    </div>
  
</body>

</html>
<?php
$conn->close();
?>