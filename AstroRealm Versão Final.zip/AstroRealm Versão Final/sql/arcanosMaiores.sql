INSERT INTO cartas_tarot (nome, tipo, imagem, significado) VALUES
('O Louco', 'Arcano Maior', 'o_louco.jpg', 'Simboliza novos começos, liberdade, e espontaneidade.'),
('O Mago', 'Arcano Maior', 'o_mago.jpg', 'Representa habilidade, poder e transformação.'),
('A Sacerdotisa', 'Arcano Maior', 'a_sacerdotisa.jpg', 'Simboliza sabedoria, mistério e intuição.'),
('A Imperatriz', 'Arcano Maior', 'a_imperatriz.jpg', 'Simboliza fertilidade, criação e nutrição.'),
('O Imperador', 'Arcano Maior', 'o_imperador.jpg', 'Representa autoridade, estrutura e estabilidade.'),
('O Hierofante', 'Arcano Maior', 'o_hierofante.jpg', 'Simboliza tradição, espiritualidade e orientação.'),
('Os Enamorados', 'Arcano Maior', 'os_enamorados.jpg', 'Representam escolhas, amor e harmonia.'),
('O Carro', 'Arcano Maior', 'o_carro.jpg', 'Simboliza determinação, vitória e superação.'),
('A Força', 'Arcano Maior', 'a_forca.jpg', 'Representa coragem, controle e compaixão.'),
('O Eremita', 'Arcano Maior', 'o_ermitão.jpg', 'Simboliza introspecção, sabedoria e busca interior.'),
('A Roda da Fortuna', 'Arcano Maior', 'a_roda_da_fortuna.jpg', 'Representa destino, ciclos e mudanças inesperadas.'),
('A Justiça', 'Arcano Maior', 'a_justica.jpg', 'Simboliza equilíbrio, verdade e responsabilidade.'),
('O Enforcado', 'Arcano Maior', 'o_enforcado.jpg', 'Representa sacrifício, rendição e nova perspectiva.'),
('A Morte', 'Arcano Maior', 'a_morte.jpg', 'Simboliza fim de ciclos, transformação e renascimento.'),
('A Temperança', 'Arcano Maior', 'a_temperanca.jpg', 'Representa equilíbrio, paciência e harmonia.'),
('O Diabo', 'Arcano Maior', 'o_diabo.jpg', 'Simboliza vícios, materialismo e ilusões.'),
('A Torre', 'Arcano Maior', 'a_torre.jpg', 'Representa ruptura, revelações e mudanças súbitas.'),
('A Estrela', 'Arcano Maior', 'a_estrela.jpg', 'Simboliza esperança, inspiração e cura.'),
('A Lua', 'Arcano Maior', 'a_lua.jpg', 'Representa ilusões, emoções e o subconsciente.'),
('O Sol', 'Arcano Maior', 'o_sol.jpg', 'Simboliza alegria, sucesso e vitalidade.'),
('O Julgamento', 'Arcano Maior', 'o_julgamento.jpg', 'Representa renascimento, avaliação e redenção.'),
('O Mundo', 'Arcano Maior', 'o_mundo.jpg', 'Simboliza realização, conclusão e plenitude.');

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Há momentos em que a vida exige não um gesto brusco, mas a firmeza serena de quem domina seus impulsos com sabedoria. Controlar as emoções, especialmente nos períodos mais turbulentos, é sinal de profundo crescimento interior. É na calma que reside o verdadeiro poder.',
  interpretacao_posicao_2 = 'Mesmo diante de pressões externas, o equilíbrio emocional continua sendo um farol que orienta ações ponderadas. Há algo grandioso na capacidade de enfrentar desafios sem ceder ao desespero ou à raiva. Persistir, ainda que em silêncio, é uma virtude rara e transformadora.',
  interpretacao_posicao_3 = 'Essa energia resiliente também se reflete na forma como se lida com as próprias fragilidades. Com paciência e autocompaixão, é possível transmutar vulnerabilidades em força interior, permitindo que um novo nível de confiança floresça naturalmente no caminho da superação.',
  interpretacao_perdida = 'A força interior para dominar desafios com coragem ficou inexplorada, sugerindo que a resiliência emocional teria pavimentado um caminho de superação.'
WHERE nome = 'A Força';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Às vezes é necessário parar, inverter o olhar e aceitar que não temos controle sobre tudo. Esse tipo de pausa, forçada ou escolhida, pode se revelar profundamente reveladora. É nela que nascem os questionamentos mais sinceros sobre quem se é e o que se valoriza.',
  interpretacao_posicao_2 = 'Mesmo que tudo pareça suspenso no tempo, essa imobilidade pode conter uma sabedoria silenciosa. O momento de espera convida à introspecção, pedindo um novo tipo de entrega — não ao sofrimento, mas ao aprendizado que brota da renúncia e da contemplação.',
  interpretacao_posicao_3 = 'Com o tempo, esse estado de entrega revela um novo horizonte. A libertação não vem por resistir, mas por enxergar de outro ângulo. Uma nova visão da vida surge quando se permite mudar o foco, redescobrindo propósitos antes encobertos pela pressa e pelo controle.',
  interpretacao_perdida = 'A rendição a uma nova perspectiva ficou em segundo plano, sugerindo que abrir mão do controle poderia ter revelado um propósito maior.'
WHERE nome = 'O Enforcado';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Há um impulso latente de seguir adiante sem certezas, com uma vontade quase inocente de se lançar ao desconhecido. Essa energia espontânea pode ser libertadora, mas também exige cuidado com distrações e imprudências. O momento convida a abraçar a liberdade, mas com atenção aos riscos que vêm com a falta de direção.',
  interpretacao_posicao_2 = 'Movimentos impensados do passado ou decisões tomadas com o coração mais do que com a razão ainda reverberam no presente. É possível que uma parte sua esteja buscando escapar de responsabilidades, ansiando por algo novo, mesmo sem saber exatamente o quê. Avaliar onde a leveza termina e a negligência começa pode trazer clareza sobre como agir daqui em diante.',
  interpretacao_posicao_3 = 'A abertura para novas experiências está próxima, e com ela vem a possibilidade de recomeçar sob uma nova perspectiva. Deixar para trás velhas estruturas mentais permitirá que algo inesperado floresça. Um salto de fé pode ser necessário, mas o segredo está em confiar no processo sem perder o senso de propósito.',
  interpretacao_perdida = 'Um caminho de liberdade e aventura permaneceu intocado, sugerindo que a espontaneidade poderia ter aberto portas inesperadas. O destino não seguido aqui é o de abraçar o desconhecido sem medo.'
WHERE nome = 'O Louco';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'A força criativa está em plena manifestação, e há diante de você as ferramentas necessárias para construir algo significativo. Este é um momento de iniciativa, em que a confiança nas próprias habilidades deve guiar suas escolhas. Saber que você tem o domínio sobre o que está criando pode transformar intenções em realidade.',
  interpretacao_posicao_2 = 'Muito do que você vive hoje está enraizado em um esforço passado de afirmação e controle. Talvez tenha sido necessário mostrar força, convencer os outros — ou a si mesmo — de sua capacidade. Agora é hora de refletir se as bases do que você construiu são sólidas ou se algo foi iniciado apenas para provar um ponto. A mágica só acontece quando há verdade.',
  interpretacao_posicao_3 = 'O futuro traz oportunidades de ação e realização, desde que haja alinhamento entre o que se deseja e o que se faz. A influência está ao seu alcance, mas deve ser exercida com responsabilidade. Usar o talento de forma consciente permitirá que ideias ganhem forma e que sua presença cause impacto real.',
  interpretacao_perdida = 'Uma oportunidade de canalizar seu poder criativo ficou à margem, indicando que a confiança em suas habilidades poderia ter transformado o curso dos eventos.'
WHERE nome = 'O Mago';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Há momentos em que o silêncio e a introspecção dizem mais do que mil palavras. Tudo ao seu redor pode parecer agitado, mas dentro de você existe uma sabedoria profunda que pede para ser ouvida. Esta é uma fase em que observar, refletir e confiar nos próprios instintos se mostra mais valioso do que qualquer ação imediata.',
  interpretacao_posicao_2 = 'Você pode estar sendo guiado por uma intuição mais forte do que percebe, mas há também um medo de confiar totalmente nesse instinto. As emoções estão recolhidas, talvez por proteção, talvez por prudência. Existe uma dualidade entre o que você sabe e o que você demonstra, e isso pode estar interferindo na clareza de suas decisões. É tempo de integrar razão e sensibilidade, deixando que ambas colaborem em vez de disputarem espaço.',
  interpretacao_posicao_3 = 'Após um tempo de silêncio e introspecção, o momento de agir com sabedoria se aproxima. As experiências vividas moldaram uma percepção mais profunda, e agora é possível tomar atitudes mais alinhadas com sua verdade. O que antes era dúvida se transforma em direção. Você percebe que a clareza nem sempre vem de fora — muitas vezes ela surge ao aceitar a complexidade dos próprios sentimentos.',
  interpretacao_perdida = 'A sabedoria intuitiva que poderia ter guiado suas escolhas foi deixada de lado, sugerindo que ouvir o silêncio interior teria revelado verdades ocultas.'
WHERE nome = 'A Sacerdotisa';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'A energia da criação e da abundância se manifesta com força agora. Este é um tempo fértil, não apenas no sentido literal, mas também em ideias, relacionamentos e projetos. Você se encontra num ponto onde nutrir o que é importante se torna prioridade, e isso exige dedicação afetiva e presença constante. Tudo aquilo que é cuidado com amor tende a florescer com vigor.',
  interpretacao_posicao_2 = 'Você tem doado muito de si aos outros — talvez até mais do que deveria. Existe um desejo sincero de cuidar, mas é importante observar se o equilíbrio entre dar e receber está sendo respeitado. A generosidade, quando bem direcionada, constrói vínculos profundos. Mas quando excessiva, pode levar ao esgotamento emocional. Olhe com carinho para suas próprias necessidades também.',
  interpretacao_posicao_3 = 'O tempo agora é de colheita. Tudo aquilo que você semeou com dedicação e afeto começa a gerar frutos. Você percebe que o carinho investido retorna de formas inesperadas, e isso traz uma sensação de realização. É hora de confiar que o seu valor não está apenas no que oferece aos outros, mas também naquilo que permite florescer em si mesmo.',
  interpretacao_perdida = 'A energia de criação e abundância não foi plenamente explorada, apontando que nutrir seus projetos ou relações poderia ter florescido de forma inesperada.'
WHERE nome = 'A Imperatriz';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Neste início, a estrutura se faz necessária. Estabilidade, ordem e responsabilidade tomam o centro da cena, pedindo uma postura mais racional diante dos desafios. É momento de assumir o controle das situações, estabelecer limites e conduzir os rumos com firmeza e clareza de propósito.',
  interpretacao_posicao_2 = 'Internamente, há uma necessidade de segurança e de estabelecer bases sólidas para o que se deseja construir. As experiências vividas reforçam o valor da disciplina e da organização, convidando você a agir com mais estratégia. Emoções contidas podem estar servindo de alicerce para decisões ponderadas e duradouras.',
  interpretacao_posicao_3 = 'No fechamento, o equilíbrio entre autoridade e sensibilidade se torna visível. As conquistas que vieram pela firmeza agora exigem maturidade emocional para serem mantidas. O poder não é mais visto como imposição, mas como a responsabilidade de proteger e sustentar aquilo que é valioso.',
  interpretacao_perdida = 'A estabilidade e autoridade que poderiam ter estruturado seu caminho foram evitadas, sugerindo que a liderança firme teria trazido ordem ao caos.'
WHERE nome = 'O Imperador';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Há uma busca por sentido que ultrapassa o cotidiano. Tradições, valores e sistemas de crença começam a assumir um papel mais relevante em suas escolhas. Este é um momento de escutar conselhos, aprender com os mais experientes e encontrar apoio em estruturas já testadas pelo tempo.',
  interpretacao_posicao_2 = 'Internamente, cresce a necessidade de alinhar os valores pessoais com aquilo que se pratica. Existe uma tensão entre seguir padrões e ouvir a própria verdade, mas também uma oportunidade de síntese. O processo de autoeducação e amadurecimento espiritual caminha lado a lado com o desejo de pertencer.',
  interpretacao_posicao_3 = 'Ao final, o aprendizado se solidifica em sabedoria compartilhada. O que antes era apenas conhecimento passa a ser vivido, ensinado e transmitido. A confiança em princípios bem fundamentados gera estabilidade emocional, e o desejo de orientar os outros nasce naturalmente como expressão do próprio crescimento.',
  interpretacao_perdida = 'A orientação espiritual ou tradicional ficou em segundo plano, indicando que seguir conselhos sábios ou valores estabelecidos poderia ter oferecido clareza.'
WHERE nome = 'O Hierofante';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Surge um momento em que escolhas precisam ser feitas com o coração em sintonia com a razão. Dilemas internos podem apontar para caminhos distintos, e o desafio está em agir com autenticidade, ouvindo tanto os desejos profundos quanto a sabedoria adquirida. As relações pessoais também assumem papel central nesta fase.',
  interpretacao_posicao_2 = 'O ambiente emocional se revela como um espelho das suas decisões afetivas passadas. O apego ou a hesitação pode estar freando avanços importantes. Por trás dos sentimentos há lições sobre entrega, confiança e a necessidade de harmonia interior antes de buscar equilíbrio em vínculos externos.',
  interpretacao_posicao_3 = 'A conclusão mostra que as escolhas feitas com verdade ecoam positivamente na sua trajetória. Mais do que decidir entre dois caminhos, trata-se de unir partes suas que antes pareciam opostas. A integração emocional traz clareza e revela a força que nasce do compromisso consigo mesmo e com os outros.',
  interpretacao_perdida = 'Uma escolha significativa no amor ou nas parcerias não foi tomada, sugerindo que a harmonia poderia ter sido encontrada ao priorizar conexões verdadeiras.'
WHERE nome = 'Os Enamorados';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Uma energia intensa impulsiona suas ações. Existe foco, determinação e uma vontade poderosa de conquistar metas e superar obstáculos. No entanto, é importante manter a direção clara e não se deixar levar pela pressa ou pelo excesso de ambição. A vitória só se sustenta com disciplina.',
  interpretacao_posicao_2 = 'Internamente, pode haver um conflito entre forças opostas. A mente quer seguir em frente, mas o coração pede pausa para refletir. Esse momento exige domínio sobre os impulsos e alinhamento entre intenção e ação. Superar as contradições internas é o primeiro passo rumo ao progresso verdadeiro.',
  interpretacao_posicao_3 = 'Ao final, o caminho percorrido revela conquistas marcantes e também amadurecimento emocional. Você reconhece que chegar ao destino não é tudo: importa também como você chegou até lá. A jornada se torna um símbolo de autocontrole, coragem e do equilíbrio entre razão e emoção.',
  interpretacao_perdida = 'A determinação para superar obstáculos permaneceu adormecida, apontando que um foco intenso poderia ter conduzido a vitórias inesperadas.'
WHERE nome = 'O Carro';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Este é um tempo de acerto de contas, em que tudo aquilo que foi plantado começa a se manifestar com exatidão. Existe uma necessidade de honestidade, responsabilidade e clareza nas decisões. A vida cobra equilíbrio, e qualquer desvio é rapidamente confrontado pela realidade objetiva dos fatos.',
  interpretacao_posicao_2 = 'Em um nível mais profundo, há uma busca por alinhamento entre o que você pensa, sente e faz. Talvez surja um peso ao refletir sobre atitudes passadas ou julgamentos que pareciam corretos no momento. Esse processo de revisão interna pode ser desconfortável, mas essencial para restaurar a integridade pessoal.',
  interpretacao_posicao_3 = 'Com o tempo, o equilíbrio retorna e a consciência se alinha com a ação. As relações se tornam mais transparentes e os compromissos mais justos. Aquilo que parecia confuso agora encontra clareza, e as escolhas se firmam em bases éticas e coerentes. A harmonia é conquistada por meio da verdade.',
  interpretacao_perdida = 'A busca por justiça e equilíbrio foi negligenciada, apontando que a verdade e a responsabilidade poderiam ter trazido harmonia ao seu caminho.'
WHERE nome = 'A Justiça';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Você se encontra em um ciclo de introspecção, onde as respostas não virão do exterior, mas da escuta profunda de si mesmo. O mundo desacelera para que você possa observar melhor suas motivações, medos e desejos. Essa pausa é fértil e traz luz ao que antes estava confuso ou negligenciado.',
  interpretacao_posicao_2 = 'Internamente, pode haver um sentimento de isolamento ou distanciamento. No entanto, esse silêncio é necessário para a maturação das ideias e das emoções. A solidão não é ausência, mas presença concentrada. É tempo de observar com cuidado e construir discernimento antes de dar novos passos.',
  interpretacao_posicao_3 = 'Ao final do caminho, você percebe que as respostas sempre estiveram dentro de si. A sabedoria adquirida nessa jornada interior fortalece sua confiança e sua clareza. Agora, é possível seguir adiante com mais consciência, firmeza e serenidade diante dos desafios da vida.',
  interpretacao_perdida = 'A busca por respostas internas foi deixada de lado, indicando que a introspecção poderia ter revelado uma sabedoria profunda para guiar suas decisões.'
WHERE nome = 'O Eremita';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Você está no centro de um ciclo de mudanças inevitáveis, em que acontecimentos parecem se mover por forças maiores que o seu controle. Há uma energia de transição no ar, sugerindo que o que hoje é certo pode não ser amanhã. É importante manter-se flexível e atento aos sinais do momento.',
  interpretacao_posicao_2 = 'Internamente, essa fase traz tanto excitação quanto insegurança. Você pode sentir que está sendo puxado em direções opostas ou que as coisas estão acontecendo rápido demais. Apesar da instabilidade, há também oportunidades inesperadas surgindo, e sua habilidade de se adaptar será fundamental.',
  interpretacao_posicao_3 = 'Com o tempo, compreende-se que toda mudança, mesmo as mais desafiadoras, vêm com a chance de renovação. O movimento da vida retoma seu equilíbrio natural, e aquilo que parecia caótico agora se organiza em uma nova direção. O destino se revela não como acaso, mas como uma dança entre escolhas e possibilidades.',
  interpretacao_perdida = 'As voltas do destino não foram abraçadas, sugerindo que aceitar as mudanças cíclicas poderia ter alinhado você com novas oportunidades.'
WHERE nome = 'A Roda da Fortuna';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Chegou a hora de encerrar um ciclo que já não faz sentido em sua vida. A transformação se impõe, pedindo coragem para soltar o que não serve mais. É um convite a deixar morrer antigas formas de ser, para que algo novo possa nascer com mais autenticidade e liberdade.',
  interpretacao_posicao_2 = 'Essa transição pode ser sentida de maneira intensa, provocando medo, resistência ou até mesmo luto. No entanto, a dor vem da tentativa de segurar o que já terminou. Aceitar o fim como parte natural da existência abre espaço para insights profundos e uma regeneração verdadeira.',
  interpretacao_posicao_3 = 'Após o luto simbólico, surge uma força renovada. O que foi deixado para trás dá lugar a uma paisagem mais limpa, mais clara, onde você pode plantar com mais consciência. A vida segue seu curso com mais leveza e propósito, permitindo que você floresça com novas raízes e direção.',
  interpretacao_perdida = 'A transformação que encerra ciclos antigos não foi acolhida, indicando que deixar ir poderia ter aberto espaço para um renascimento poderoso.'
WHERE nome = 'A Morte';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'O momento pede equilíbrio, paciência e moderação. Você está sendo chamado a harmonizar forças internas e externas, buscando um caminho do meio entre extremos. As soluções não virão por imposição, mas sim por conciliação, escuta e adaptação sensível aos fluxos da vida.',
  interpretacao_posicao_2 = 'Há um anseio profundo por paz e estabilidade, ainda que disfarçado sob a superfície das emoções. Talvez você esteja tentando ajustar-se a situações que ainda não compreende completamente. Pequenos gestos e atitudes conscientes agora terão efeitos duradouros no seu bem-estar e nas suas relações.',
  interpretacao_posicao_3 = 'Com o tempo, torna-se evidente que a cura verdadeira não acontece de forma abrupta, mas sim por meio da constância, da escuta e da integração cuidadosa dos aprendizados. A leveza que surge é fruto de uma alquimia interna que transforma experiências díspares em sabedoria silenciosa.',
  interpretacao_perdida = 'A paciência para encontrar equilíbrio foi evitada, sugerindo que a moderação poderia ter harmonizado conflitos internos ou externos.'
WHERE nome = 'A Temperança';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Você pode estar preso a padrões que limitam sua liberdade ou obscurecem seu discernimento. Há uma força de sedução em jogo, que promete prazer imediato ou controle, mas à custa da autenticidade. Este é um momento para observar com honestidade os vínculos que te aprisionam.',
  interpretacao_posicao_2 = 'Por dentro, há tensão entre desejo e repressão, impulso e responsabilidade. As emoções podem se tornar dominantes ou mesmo sabotadoras, especialmente se você evita olhar de frente para seus próprios desejos ou medos. É preciso coragem para enfrentar a sombra e reconhecer o que está no comando.',
  interpretacao_posicao_3 = 'A libertação não acontece com confronto, mas com consciência. Ao reconhecer o que está por trás das máscaras e ilusões, abre-se um caminho para escolhas mais conscientes. A força que antes o acorrentava pode ser transmutada em poder interior, capaz de romper com o ciclo da dependência e da negação.',
  interpretacao_perdida = 'A libertação de amarras materiais ou emocionais não foi buscada, apontando que enfrentar ilusões poderia ter trazido verdadeira liberdade.'
WHERE nome = 'O Diabo';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Há momentos em que estruturas antes consideradas sólidas começam a ruir de forma inesperada. O chão pode parecer instável, e as certezas se desfazem rapidamente. Isso representa uma grande quebra de paradigmas, mas também um convite para reconstruir a vida com mais autenticidade e verdade.',
  interpretacao_posicao_2 = 'Internamente, existe uma tensão acumulada que pode estar à beira de se manifestar. Muitas vezes, insistimos em manter situações insustentáveis por medo da mudança, e isso cria uma pressão que precisa ser liberada. O impulso destrutivo pode ser doloroso, mas também libertador, abrindo espaço para o que é novo e real.',
  interpretacao_posicao_3 = 'Após a queda, o que resta é a essência. Esse abalo serve para revelar o que é verdadeiro e o que precisa ser deixado para trás. No vazio deixado pela destruição, nasce a oportunidade de uma nova fundação, mais alinhada com quem você realmente é, sem ilusões ou autoengano.',
  interpretacao_perdida = 'A ruptura que traria revelações ficou intocada, sugerindo que uma mudança abrupta poderia ter destruído barreiras para um novo começo.'
WHERE nome = 'A Torre';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Surge um chamado de fé silenciosa que se acende como um farol mesmo nos momentos mais escuros. Essa presença tranquila não impõe, mas inspira. É a esperança que renasce mesmo quando tudo parece incerto, e que traz a promessa de um novo ciclo mais leve e sereno.',
  interpretacao_posicao_2 = 'Em seu íntimo, há uma conexão sutil com algo maior que transcende as dificuldades imediatas. Essa força não é barulhenta nem dramática — ela brota da calma e da confiança em si mesmo. Quando você se permite aquietar, consegue ouvir o que sua intuição já sabe: tudo está se encaminhando com sabedoria.',
  interpretacao_posicao_3 = 'Ao seguir a luz interna com consistência e gentileza, a jornada torna-se mais clara. O caminho não precisa ser forçado, apenas seguido com honestidade e fé. As bênçãos que chegam agora são fruto de escolhas feitas com o coração e com uma entrega silenciosa à vida como ela é.',
  interpretacao_perdida = 'A esperança que ilumina o caminho após a escuridão foi deixada de lado, indicando que a fé em novos começos poderia ter inspirado cura.'
WHERE nome = 'A Estrela';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Este é um momento que exige atenção redobrada, pois há risco de ilusões, enganos e interpretações equivocadas da realidade. As coisas podem não estar tão claras quanto parecem, e é possível que sentimentos de confusão, dúvida ou insegurança estejam influenciando suas percepções. É importante evitar decisões impulsivas e observar com mais profundidade antes de agir.',
  interpretacao_posicao_2 = 'Internamente, os medos antigos podem estar se projetando nas situações atuais. Algo dentro de você talvez ainda não tenha sido completamente compreendido ou digerido. A intuição está forte, mas também há necessidade de discernimento para não ser conduzido por fantasias ou pensamentos distorcidos que nascem da ansiedade.',
  interpretacao_posicao_3 = 'À medida que a névoa se dissipa, torna-se possível enxergar o caminho com mais clareza. A travessia por esse território emocional instável pode ter sido desafiadora, mas trouxe revelações importantes. Agora é hora de transformar a sensibilidade em força e seguir adiante com mais confiança e sabedoria.',
  interpretacao_perdida = 'As emoções profundas e o subconsciente não foram explorados, sugerindo que enfrentar ilusões teria revelado verdades escondidas.'
WHERE nome = 'A Lua';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Há uma clareza vibrante iluminando sua trajetória neste momento. Você pode estar experimentando um senso renovado de confiança, vitalidade e realização. O brilho dessa fase não vem apenas de fora — ele nasce de uma conexão verdadeira com sua essência e com a alegria de ser quem você é.',
  interpretacao_posicao_2 = 'Dentro de você há uma luz que aquece e motiva, mesmo que às vezes seja esquecida. Esse brilho interior pede para ser reconhecido e cultivado com afeto. Quando você se permite celebrar suas conquistas e olhar para si com ternura, tudo ao redor começa a responder com mais harmonia.',
  interpretacao_posicao_3 = 'O futuro se desenha com possibilidades expansivas, frutos daquilo que foi construído com sinceridade e dedicação. É hora de colher os frutos da autenticidade e compartilhar sua luz com o mundo. A simplicidade, a alegria e o amor caminham ao seu lado — basta continuar iluminando os passos com verdade.',
  interpretacao_perdida = 'A vitalidade e a alegria de um sucesso radiante ficaram à margem, apontando que abraçar a luz interior poderia ter trazido conquistas.'
WHERE nome = 'O Sol';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Chega um momento em que é necessário fazer uma pausa e refletir sobre tudo o que foi vivido até agora. As experiências passadas retornam à consciência, trazendo lições valiosas e oportunidades de reconhecimento. Há um chamado interno para reavaliar escolhas, liberar culpas antigas e se preparar para um novo ciclo mais consciente.',
  interpretacao_posicao_2 = 'Por dentro, pulsa a necessidade de renovação e libertação. Um despertar silencioso acontece quando se compreende que já não é mais possível carregar os fardos que pertencem ao passado. Existe um desejo sincero de fazer as pazes com o que foi, aceitar o que é, e abrir espaço para aquilo que ainda virá, com leveza e autenticidade.',
  interpretacao_posicao_3 = 'À medida que as peças se encaixam, o sentimento é de renascimento. As decisões que forem tomadas agora têm o poder de alterar profundamente o curso da jornada. A clareza conquistada permite trilhar um novo caminho com mais confiança, alinhado aos valores que realmente importam.',
  interpretacao_perdida = 'O chamado para um renascimento pessoal foi ignorado, sugerindo que a autorreflexão poderia ter conduzido a uma redenção transformadora.'
WHERE nome = 'O Julgamento';

UPDATE cartas_tarot
SET 
  interpretacao_posicao_1 = 'Há um senso de plenitude no ar, como se todas as partes da jornada estivessem, enfim, se unificando em um só propósito. Os ciclos anteriores parecem ter levado a um ponto de equilíbrio e compreensão mais profundos. É o momento de respirar com tranquilidade e reconhecer o próprio crescimento.',
  interpretacao_posicao_2 = 'Internamente, existe a sensação de estar onde se deve estar. Mesmo que nem tudo esteja perfeito, há uma paz interior que surge da aceitação. A conexão com o todo se intensifica, e a percepção de pertencimento ao fluxo da vida traz conforto, harmonia e propósito à caminhada.',
  interpretacao_posicao_3 = 'O caminho adiante se apresenta como uma continuação natural do que já foi realizado com dedicação e verdade. Há promessas de expansão, celebração e novos horizontes, frutos de um ciclo que se encerra com sabedoria. A sensação é de missão cumprida — e de que algo ainda mais belo está por vir.',
  interpretacao_perdida = 'A plenitude de uma jornada concluída não foi alcançada, indicando que a realização total poderia ter coroado seus esforços com sucesso.'
WHERE nome = 'O Mundo';
/*==============================================================================================================================================================================================================================================================================================================================================*/

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "A Carta do Louco: O Chamado da Aventura",
    "introducao": "A carta do Louco, marcada com o número 0, é o ponto de partida dos Arcanos Maiores no tarô. Representa o início de uma jornada, cheia de potencial, curiosidade e liberdade. O Louco é o aventureiro destemido, pronto para dar um salto de fé no desconhecido, guiado pela confiança no universo e por uma alma cheia de possibilidades.",
    "simbologia": "No baralho Rider-Waite, o Louco é retratado como um jovem caminhando alegremente rumo a um precipício. Ele carrega uma mochila leve, simbolizando desapego, e segura uma rosa branca, que representa pureza e intenções claras. Um cão pula a seus pés, podendo ser um guia intuitivo ou um alerta contra a imprudência. O sol brilhante ao fundo ilumina sua jornada, enquanto montanhas distantes sugerem desafios e aspirações futuras.",
    "significados": {
        "direita": "Novos começos, espontaneidade, confiança no universo, liberdade, curiosidade. O Louco convida você a abraçar mudanças com coragem e a seguir sua intuição.",
        "invertida": "Imprudência, medo do novo, falta de direção. Pode indicar a necessidade de mais planejamento ou atenção aos riscos."
    },
    "contextos": {
        "amor": "Um novo romance ou uma fase de renovação nos relacionamentos. Na posição invertida, cuidado com decisões impulsivas ou falta de compromisso.",
        "carreira": "Oportunidade de explorar novos caminhos, como um projeto ou mudança de emprego. Invertida, sugere planejamento antes de agir.",
        "saude": "Um convite para adotar um estilo de vida mais leve. Invertida, alerta contra negligência ou excessos.",
        "espiritualidade": "Uma jornada de autodescoberta, guiada pela intuição. Invertida, pode indicar desconexão espiritual."
    },
    "curiosidade": "Como o número 0, o Louco representa o potencial infinito, o momento antes da manifestação. Ele é o protagonista da jornada dos Arcanos Maiores, iniciando um caminho de aprendizado e transformação."
}' WHERE id = 1;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "O Mago: O Mestre da Manifestação",
    "introducao": "O Mago, número 1, representa a habilidade de transformar ideias em realidade. Ele é o canal entre o espiritual e o material, simbolizando poder pessoal, criatividade e ação consciente.",
    "simbologia": "No Rider-Waite, o Mago está diante de uma mesa com os quatro naipes do tarô (copas, ouros, espadas, paus), representando os elementos. Sua varinha aponta para o céu, conectando o divino à terra, e a lemniscata acima de sua cabeça simboliza infinito.",
    "significados": {
        "direita": "Poder pessoal, habilidade, foco, criatividade, manifestação. O Mago incentiva a usar seus talentos para criar mudanças.",
        "invertida": "Manipulação, falta de foco, talentos desperdiçados. Pode indicar bloqueios criativos ou uso indevido de poder."
    },
    "contextos": {
        "amor": "Atração magnética ou início de uma conexão apaixonada. Invertida, cuidado com manipulações emocionais.",
        "carreira": "Oportunidades para brilhar e usar suas habilidades. Invertida, sugere falta de clareza nos objetivos.",
        "saude": "Energia vital elevada, ideal para iniciar hábitos saudáveis. Invertida, alerta para esgotamento.",
        "espiritualidade": "Conexão com o divino através da ação consciente. Invertida, desconexão ou dúvida espiritual."
    },
    "curiosidade": "O Mago é associado ao planeta Mercúrio, que rege comunicação e intelecto, reforçando sua energia de manifestação."
}' WHERE id = 2;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "A Sacerdotisa: A Guardiã da Intuição",
    "introducao": "A Sacerdotisa, número 2, é a guardiã do inconsciente e da sabedoria interior. Ela representa intuição, mistério e conexão com o divino feminino.",
    "simbologia": "No Rider-Waite, a Sacerdotisa está sentada entre dois pilares, com um véu ao fundo, simbolizando o acesso ao inconsciente. O pergaminho em suas mãos representa conhecimento esotérico.",
    "significados": {
        "direita": "Intuição, sabedoria interior, mistério, paciência. A Sacerdotisa pede que você confie em sua voz interior.",
        "invertida": "Desconexão da intuição, segredos revelados, superficialidade. Pode indicar ignorar sinais internos."
    },
    "contextos": {
        "amor": "Conexão profunda e intuitiva. Invertida, sugere falta de comunicação ou segredos.",
        "carreira": "Confiar na intuição para decisões profissionais. Invertida, alerta para falta de clareza.",
        "saude": "Ouvir o corpo e suas necessidades. Invertida, negligência com a saúde mental.",
        "espiritualidade": "Forte conexão com o divino e o inconsciente. Invertida, dificuldade em acessar a espiritualidade."
    },
    "curiosidade": "A Sacerdotisa é associada à Lua, simbolizando ciclos, intuição e o inconsciente."
}' WHERE id = 3;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "A Imperatriz: A Mãe da Abundância",
    "introducao": "A Imperatriz, número 3 dos Arcanos Maiores, é a personificação da fertilidade, da criatividade e da abundância. Ela representa o arquétipo da mãe, trazendo cuidado, nutrição e beleza para a vida. A Imperatriz convida você a se conectar com a natureza, a criar com paixão e a nutrir seus projetos e relacionamentos.",
    "simbologia": "No baralho Rider-Waite, a Imperatriz está sentada em um trono cercado por natureza exuberante, com um campo de trigo e uma cascata ao fundo, simbolizando fertilidade e abundância. Sua coroa de estrelas representa conexão divina, e o cetro em sua mão simboliza poder criativo.",
    "significados": {
        "direita": "Abundância, criatividade, fertilidade, cuidado maternal, conexão com a natureza. A Imperatriz encoraja a nutrir seus projetos e a expressar sua criatividade.",
        "invertida": "Bloqueio criativo, negligência emocional, excesso de controle, carência. Pode indicar desconexão com a natureza ou falta de autocuidado."
    },
    "contextos": {
        "amor": "Relações amorosas baseadas em carinho, apoio e conexão emocional. Na posição invertida, pode indicar carência afetiva ou dependência emocional.",
        "carreira": "Projetos criativos florescem, com oportunidades para crescimento. Invertida, sugere estagnação ou falta de inspiração no trabalho.",
        "saude": "Foco no autocuidado e na conexão com o corpo, como práticas de bem-estar. Invertida, alerta para descuido com a saúde física ou emocional.",
        "espiritualidade": "Conexão profunda com a natureza e o divino feminino. Invertida, pode indicar desconexão espiritual ou dificuldade em encontrar harmonia."
    },
    "curiosidade": "A Imperatriz é associada ao planeta Vênus, que rege o amor, a beleza e a criatividade, reforçando sua energia de abundância e harmonia."
}' WHERE id = 4;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "O Imperador: O Pilar da Estrutura",
    "introducao": "O Imperador, número 4 dos Arcanos Maiores, representa autoridade, estrutura e disciplina. Ele é o arquétipo do pai, trazendo ordem, estabilidade e proteção. O Imperador convida você a estabelecer limites claros, assumir o controle de sua vida e liderar com responsabilidade.",
    "simbologia": "No baralho Rider-Waite, o Imperador está sentado em um trono de pedra, segurando um cetro e um globo, simbolizando poder e domínio. As montanhas ao fundo representam solidez, enquanto suas vestes vermelhas indicam ação e autoridade.",
    "significados": {
        "direita": "Disciplina, autoridade, estabilidade, liderança, proteção. O Imperador sugere que você crie estrutura e assuma responsabilidade por suas ações.",
        "invertida": "Rigidez, abuso de poder, falta de controle, caos. Pode indicar inflexibilidade ou dificuldade em liderar de forma equilibrada."
    },
    "contextos": {
        "amor": "Relações baseadas em segurança e compromisso. Na posição invertida, pode indicar controle excessivo ou falta de apoio emocional.",
        "carreira": "Sucesso através de organização e liderança. Invertida, sugere conflitos de poder ou desorganização no trabalho.",
        "saude": "Benefícios de uma rotina saudável e disciplinada. Invertida, alerta para estresse causado por rigidez ou falta de equilíbrio.",
        "espiritualidade": "Busca por estrutura espiritual ou orientação de mestres. Invertida, pode indicar dogmatismo ou resistência a crenças."
    },
    "curiosidade": "O Imperador é associado ao signo de Áries, que rege a iniciativa, a liderança e a energia assertiva."
}' WHERE id = 5;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "O Hierofante: O Guardião da Tradição",
    "introducao": "O Hierofante, número 5 dos Arcanos Maiores, representa tradição, espiritualidade organizada e orientação. Ele é o mestre espiritual que guia através de ensinamentos estabelecidos, simbolizando a busca por significado dentro de estruturas convencionais.",
    "simbologia": "No baralho Rider-Waite, o Hierofante está sentado entre dois pilares, segurando um cetro triplo, simbolizando autoridade espiritual. As chaves aos seus pés representam acesso ao conhecimento sagrado, enquanto os acólitos diante dele indicam aprendizado e submissão à tradição.",
    "significados": {
        "direita": "Tradição, orientação, moralidade, aprendizado, espiritualidade estruturada. O Hierofante sugere buscar orientação em sistemas estabelecidos ou mentores.",
        "invertida": "Rebelião contra normas, dogmatismo, falta de orientação, inconformismo. Pode indicar questionamento de crenças ou rejeição de autoridades."
    },
    "contextos": {
        "amor": "Relações baseadas em valores compartilhados ou compromissos tradicionais, como casamento. Invertida, sugere conflitos de crenças ou desejo de liberdade.",
        "carreira": "Sucesso através de métodos tradicionais ou aprendizado formal. Invertida, alerta para ruptura com normas ou falta de direção.",
        "saude": "Seguir conselhos médicos tradicionais ou rotinas estabelecidas. Invertida, pode indicar resistência a tratamentos ou abordagens alternativas.",
        "espiritualidade": "Busca por ensinamentos espirituais dentro de tradições. Invertida, sugere questionamento de dogmas ou busca por espiritualidade não convencional."
    },
    "curiosidade": "O Hierofante é associado ao signo de Touro, que rege a estabilidade, os valores materiais e a conexão com a terra."
}' WHERE id = 6;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "Os Amantes: A Escolha do Coração",
    "introducao": "Os Amantes, número 6 dos Arcanos Maiores, representam amor, harmonia e escolhas importantes. Esta carta simboliza a união de opostos, decisões guiadas pelo coração e a busca por alinhamento entre valores e desejos.",
    "simbologia": "No baralho Rider-Waite, um casal está nu sob a bênção de um anjo, com o sol brilhando ao fundo. A árvore em chamas atrás do homem representa paixão, enquanto a árvore com a serpente atrás da mulher simboliza conhecimento. As montanhas ao fundo indicam aspirações elevadas.",
    "significados": {
        "direita": "Amor, harmonia, escolhas alinhadas, união, equilíbrio. Os Amantes sugerem decisões baseadas no coração e na autenticidade.",
        "invertida": "Desequilíbrio, escolhas difíceis, conflitos internos, desarmonia. Pode indicar dúvidas em relacionamentos ou decisões desalinhadas."
    },
    "contextos": {
        "amor": "Relações profundas, parcerias baseadas em amor e confiança. Invertida, sugere desentendimentos ou escolhas difíceis no amor.",
        "carreira": "Parcerias bem-sucedidas ou escolhas profissionais importantes. Invertida, alerta para conflitos no trabalho ou decisões erradas.",
        "saude": "Equilíbrio emocional e físico, com foco na harmonia. Invertida, pode indicar estresse causado por conflitos internos.",
        "espiritualidade": "Integração de opostos e alinhamento espiritual. Invertida, sugere dúvida ou desconexão com seus valores espirituais."
    },
    "curiosidade": "Os Amantes são associados ao signo de Gêmeos, que rege a dualidade, a comunicação e a conexão entre opostos."
}' WHERE id = 7;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "O Carro: A Força da Determinação",
    "introducao": "O Carro, número 7 dos Arcanos Maiores, simboliza movimento, determinação e controle. Representa a vitória alcançada através da força de vontade e da habilidade de equilibrar forças opostas para avançar em direção aos objetivos.",
    "simbologia": "No baralho Rider-Waite, um guerreiro conduz um carro puxado por duas esfinges (uma preta e outra branca), simbolizando a harmonia entre opostos. A armadura e as estrelas em sua coroa representam proteção e aspiração, enquanto a cidade ao fundo indica conquistas.",
    "significados": {
        "direita": "Determinação, vitória, controle, movimento, confiança. O Carro sugere que você está no comando e deve seguir em frente com foco.",
        "invertida": "Falta de direção, descontrole, obstáculos, agressividade. Pode indicar dificuldade em manter o foco ou superar barreiras."
    },
    "contextos": {
        "amor": "Progresso em relações através da determinação e comunicação clara. Invertida, sugere conflitos por controle ou falta de direção.",
        "carreira": "Avanço profissional com foco e liderança. Invertida, alerta para falta de planejamento ou obstáculos inesperados.",
        "saude": "Energia para superar desafios físicos ou mentais. Invertida, pode indicar exaustão ou falta de equilíbrio.",
        "espiritualidade": "Foco em objetivos espirituais com determinação. Invertida, sugere dispersão ou dificuldade em encontrar propósito."
    },
    "curiosidade": "O Carro é associado ao signo de Câncer, que rege a proteção emocional, a intuição e o movimento interno."
}' WHERE id = 8;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "A Força: O Poder da Coragem Interior",
    "introducao": "A Força, número 8 dos Arcanos Maiores, representa coragem, paciência e força interior. Esta carta simboliza o domínio das emoções e instintos através da compaixão e da determinação, mostrando que a verdadeira força vem de dentro.",
    "simbologia": "No baralho Rider-Waite, uma mulher acaricia um leão, simbolizando o controle gentil sobre os instintos selvagens. A lemniscata acima de sua cabeça representa infinito e equilíbrio, enquanto as flores em sua roupa indicam suavidade e conexão com a natureza.",
    "significados": {
        "direita": "Coragem, paciência, força interior, compaixão, autocontrole. A Força sugere que você enfrente desafios com serenidade e confiança.",
        "invertida": "Insegurança, raiva, falta de autocontrole, fraqueza. Pode indicar dificuldade em lidar com emoções ou impulsos."
    },
    "contextos": {
        "amor": "Relações baseadas em confiança, paciência e apoio mútuo. Invertida, sugere conflitos emocionais ou inseguranças.",
        "carreira": "Sucesso através da perseverança e controle emocional. Invertida, alerta para inseguranças ou conflitos no trabalho.",
        "saude": "Resiliência física e mental, ideal para superar desafios. Invertida, pode indicar exaustão emocional ou falta de cuidado.",
        "espiritualidade": "Domínio espiritual através da compaixão e da força interior. Invertida, sugere luta interna ou desconexão espiritual."
    },
    "curiosidade": "A Força é associada ao signo de Leão, que rege a coragem, a autoconfiança e a expressão do coração."
}' WHERE id = 9;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "O Eremita: A Busca pela Verdade Interior",
    "introducao": "O Eremita, número 9 dos Arcanos Maiores, simboliza introspecção, sabedoria e solitude. Ele representa a busca pela verdade interior através da reflexão e do autoconhecimento, convidando você a iluminar seu caminho com a luz da sabedoria.",
    "simbologia": "No baralho Rider-Waite, um velho segura uma lanterna que ilumina o caminho, simbolizando a busca pela verdade. Seu manto cinza representa neutralidade, e a montanha ao fundo indica isolamento e elevação espiritual.",
    "significados": {
        "direita": "Introspecção, sabedoria, orientação interior, solitude, busca espiritual. O Eremita sugere uma pausa para refletir e ouvir sua voz interior.",
        "invertida": "Isolamento excessivo, solidão, resistência à orientação, estagnação. Pode indicar medo de se conectar ou falta de introspecção."
    },
    "contextos": {
        "amor": "Reflexão sobre relações ou necessidade de tempo a sós. Invertida, sugere afastamento emocional ou solidão excessiva.",
        "carreira": "Busca por propósito ou reavaliação profissional. Invertida, alerta para estagnação ou falta de clareza nos objetivos.",
        "saude": "Foco na saúde mental e no descanso. Invertida, pode indicar negligência com o bem-estar ou isolamento prejudicial.",
        "espiritualidade": "Busca espiritual profunda através da meditação e introspecção. Invertida, sugere desconexão ou dificuldade em encontrar respostas."
    },
    "curiosidade": "O Eremita é associado ao signo de Virgem, que rege a análise, o serviço e a busca pela perfeição."
}' WHERE id = 10;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "A Roda da Fortuna: O Ciclo do Destino",
    "introducao": "A Roda da Fortuna, número 10 dos Arcanos Maiores, representa os ciclos da vida, a sorte e as mudanças inevitáveis. Ela simboliza o fluxo do destino, com seus altos e baixos, e a necessidade de se adaptar às transformações que a vida traz.",
    "simbologia": "No baralho Rider-Waite, uma roda gira com figuras mitológicas, como a esfinge e a serpente, simbolizando os ciclos da vida. As quatro figuras nos cantos (homem, águia, touro, leão) representam os elementos fixos do zodíaco, enquanto as nuvens indicam o mistério do destino.",
    "significados": {
        "direita": "Sorte, mudanças positivas, ciclos, destino, oportunidade. A Roda sugere que você aproveite as oportunidades e aceite o fluxo da vida.",
        "invertida": "Mudanças negativas, resistência aos ciclos, azar, estagnação. Pode indicar dificuldade em se adaptar ou contratempos inesperados."
    },
    "contextos": {
        "amor": "Mudanças positivas nas relações, como novos começos ou reconciliações. Invertida, sugere instabilidade emocional ou rupturas.",
        "carreira": "Oportunidades inesperadas ou mudanças no trabalho. Invertida, alerta para contratempos ou resistência à mudança.",
        "saude": "Ciclos de recuperação ou melhoria na saúde. Invertida, pode indicar desafios de saúde ou necessidade de adaptação.",
        "espiritualidade": "Aceitação do fluxo da vida e confiança no destino. Invertida, sugere resistência ao caminho espiritual ou dúvida."
    },
    "curiosidade": "A Roda da Fortuna é associada ao planeta Júpiter, que rege a expansão, a sorte e as oportunidades."
}' WHERE id = 11;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "A Justiça: O Equilíbrio da Verdade",
    "introducao": "A Justiça, número 11 dos Arcanos Maiores, simboliza equilíbrio, verdade e responsabilidade. Representa a imparcialidade e as consequências das ações, convidando você a avaliar suas escolhas com clareza e aceitar o karma de suas decisões.",
    "simbologia": "No baralho Rider-Waite, uma figura segura uma balança, simbolizando equilíbrio, e uma espada, representando verdade e julgamento. Os pilares ao fundo indicam estabilidade, e o véu vermelho sugere a imparcialidade da justiça divina.",
    "significados": {
        "direita": "Justiça, equilíbrio, responsabilidade, verdade, decisões justas. A Justiça sugere que você aja com integridade e aceite as consequências de suas escolhas.",
        "invertida": "Injustiça, desequilíbrio, negação de responsabilidade, parcialidade. Pode indicar situações injustas ou dificuldade em aceitar a verdade."
    },
    "contextos": {
        "amor": "Relações justas, baseadas em equilíbrio e respeito mútuo. Invertida, sugere desentendimentos ou falta de reciprocidade.",
        "carreira": "Decisões profissionais justas ou recompensas merecidas. Invertida, alerta para injustiça no trabalho ou conflitos legais.",
        "saude": "Equilíbrio físico e mental através de escolhas conscientes. Invertida, pode indicar negligência ou desequilíbrios na saúde.",
        "espiritualidade": "Busca pela verdade espiritual e aceitação do karma. Invertida, sugere negação de responsabilidade espiritual ou confusão."
    },
    "curiosidade": "A Justiça é associada ao signo de Libra, que rege o equilíbrio, a harmonia e a imparcialidade."
}' WHERE id = 12;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "O Enforcado: O Sacrifício pela Iluminação",
    "introducao": "O Enforcado, número 12 dos Arcanos Maiores, simboliza sacrifício, entrega e mudança de perspectiva. Representa uma pausa necessária para reflexão, convidando você a soltar o controle e ver a vida de um novo ângulo para alcançar iluminação.",
    "simbologia": "No baralho Rider-Waite, um homem está pendurado de cabeça para baixo por um pé, com uma auréola ao redor da cabeça, simbolizando iluminação espiritual. A árvore em forma de T representa equilíbrio, e sua expressão serena indica aceitação.",
    "significados": {
        "direita": "Sacrifício, entrega, nova perspectiva, pausa, iluminação. O Enforcado sugere que você se renda ao fluxo da vida para encontrar clareza.",
        "invertida": "Resistência à mudança, estagnação, vitimização, atrasos. Pode indicar medo de soltar ou apego a velhos padrões."
    },
    "contextos": {
        "amor": "Sacrifício por amor ou necessidade de mudar a perspectiva nas relações. Invertida, sugere relações estagnadas ou vitimização.",
        "carreira": "Pausa para reavaliar objetivos profissionais. Invertida, alerta para resistência à mudança ou falta de progresso.",
        "saude": "Repouso necessário para recuperação. Invertida, pode indicar negligência com o corpo ou estresse por resistência.",
        "espiritualidade": "Iluminação através da entrega e da introspecção. Invertida, sugere bloqueio espiritual ou dificuldade em mudar."
    },
    "curiosidade": "O Enforcado é associado ao planeta Netuno, que rege a espiritualidade, a ilusão e a entrega."
}' WHERE id = 13;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "A Morte: A Transformação Profunda",
    "introducao": "A Morte, número 13 dos Arcanos Maiores, simboliza transformação, finais e novos começos. Apesar de seu nome, ela raramente indica morte física, mas sim o fim de um ciclo para dar espaço a algo novo, representando renovação e mudança inevitável.",
    "simbologia": "No baralho Rider-Waite, um esqueleto cavalga um cavalo branco, segurando uma bandeira preta com uma rosa branca, simbolizando transformação e pureza. O sol nascente ao fundo indica esperança e renovação, enquanto as figuras ao redor representam a universalidade da mudança.",
    "significados": {
        "direita": "Transformação, finais necessários, renovação, mudança, libertação. A Morte sugere que você abrace o fim de um ciclo para abrir espaço ao novo.",
        "invertida": "Resistência à mudança, estagnação, apego ao passado, medo. Pode indicar dificuldade em deixar ir ou aceitar transformações."
    },
    "contextos": {
        "amor": "Fim de um ciclo amoroso ou transformação em relacionamentos. Invertida, sugere apego ao passado ou dificuldade em seguir em frente.",
        "carreira": "Mudança de carreira, projeto ou perspectiva profissional. Invertida, alerta para resistência à mudança ou estagnação.",
        "saude": "Recuperação transformadora ou necessidade de mudar hábitos. Invertida, pode indicar negligência ou medo de cuidar da saúde.",
        "espiritualidade": "Renovação espiritual profunda, com desapego de velhas crenças. Invertida, sugere resistência à transformação espiritual."
    },
    "curiosidade": "A Morte é associada ao signo de Escorpião, que rege a transformação, a regeneração e a intensidade emocional."
}' WHERE id = 14;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "A Temperança: O Equilíbrio Alquímico",
    "introducao": "A Temperança, número 14 dos Arcanos Maiores, simboliza equilíbrio, harmonia e moderação. Representa a fusão de opostos para criar algo novo, como um processo alquímico, convidando você a encontrar paciência e fluidez em sua jornada.",
    "simbologia": "No baralho Rider-Waite, um anjo com um pé na água e outro na terra mistura água entre dois jarros, simbolizando equilíbrio e transformação. As asas e o sol nascente ao fundo indicam elevação espiritual e renovação.",
    "significados": {
        "direita": "Equilíbrio, harmonia, paciência, moderação, integração. A Temperança sugere que você encontre o meio-termo e flua com a vida.",
        "invertida": "Desequilíbrio, excessos, impaciência, conflitos. Pode indicar falta de harmonia ou dificuldade em integrar opostos."
    },
    "contextos": {
        "amor": "Relações harmoniosas baseadas em paciência e compreensão. Invertida, sugere conflitos por desequilíbrio ou falta de moderação.",
        "carreira": "Colaboração equilibrada ou sucesso através da paciência. Invertida, alerta para tensões ou decisões precipitadas.",
        "saude": "Saúde equilibrada com foco em moderação. Invertida, pode indicar excessos ou negligência com o bem-estar.",
        "espiritualidade": "Integração espiritual e harmonia interior. Invertida, sugere desequilíbrio energético ou falta de conexão."
    },
    "curiosidade": "A Temperança é associada ao signo de Sagitário, que rege a expansão, a busca por significado e a aventura espiritual."
}' WHERE id = 15;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "O Diabo: As Correntes do Desejo",
    "introducao": "O Diabo, número 15 dos Arcanos Maiores, simboliza desejos, vícios e limitações autoimpostas. Representa a luta contra a sombra interior, convidando você a enfrentar suas obsessões e buscar a liberdade de correntes materiais ou emocionais.",
    "simbologia": "No baralho Rider-Waite, um casal está acorrentado aos pés de uma figura demoníaca, simbolizando escravidão aos desejos. As chamas no chifre do Diabo representam paixão, enquanto as correntes soltas indicam que a libertação é possível.",
    "significados": {
        "direita": "Vícios, desejos, limitações, materialismo, obsessão. O Diabo sugere que você enfrente o que o prende e busque liberdade.",
        "invertida": "Libertação, superação de vícios, liberdade, autoconhecimento. Pode indicar a quebra de correntes ou o reconhecimento de padrões limitantes."
    },
    "contextos": {
        "amor": "Relações obsessivas ou baseadas em desejo físico. Invertida, sugere libertação emocional ou fim de padrões tóxicos.",
        "carreira": "Ambição materialista ou apego ao status. Invertida, indica busca por propósito ou liberdade de pressões externas.",
        "saude": "Vícios ou hábitos prejudiciais à saúde. Invertida, sugere recuperação ou superação de comportamentos destrutivos.",
        "espiritualidade": "Enfrentar a sombra interior para crescer espiritualmente. Invertida, indica libertação de crenças limitantes."
    },
    "curiosidade": "O Diabo é associado ao signo de Capricórnio, que rege a ambição, a responsabilidade e a busca por controle."
}' WHERE id = 16;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "A Torre: A Queda das Ilusões",
    "introducao": "A Torre, número 16 dos Arcanos Maiores, simboliza rupturas, revelações e mudanças súbitas. Representa a destruição de estruturas falsas ou insustentáveis, abrindo caminho para a verdade e a reconstrução.",
    "simbologia": "No baralho Rider-Waite, uma torre é atingida por um raio, com pessoas caindo, simbolizando colapso e libertação. As chamas representam purificação, e as nuvens escuras indicam transformação abrupta.",
    "significados": {
        "direita": "Mudança súbita, revelação, destruição de ilusões, despertar, libertação. A Torre sugere que você aceite a mudança para crescer.",
        "invertida": "Medo da mudança, reconstrução lenta, resistência, negação. Pode indicar tentativa de evitar colapsos ou verdades difíceis."
    },
    "contextos": {
        "amor": "Rupturas ou revelações que transformam relações. Invertida, sugere evitar confrontos ou apego a relações insustentáveis.",
        "carreira": "Mudanças inesperadas no trabalho, como demissões ou reestruturações. Invertida, alerta para resistência à mudança ou reconstrução lenta.",
        "saude": "Crises que levam à renovação ou necessidade de atenção imediata. Invertida, pode indicar negligência ou medo de enfrentar problemas.",
        "espiritualidade": "Despertar espiritual através da destruição de crenças falsas. Invertida, sugere negação da verdade ou dificuldade em mudar."
    },
    "curiosidade": "A Torre é associada ao planeta Marte, que rege a ação, o conflito e a transformação abrupta."
}' WHERE id = 17;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "A Estrela: A Luz da Esperança",
    "introducao": "A Estrela, número 17 dos Arcanos Maiores, simboliza esperança, inspiração e renovação. Após a destruição da Torre, ela representa a luz que guia para a cura e o renascimento, trazendo confiança e serenidade.",
    "simbologia": "No baralho Rider-Waite, uma mulher nua despeja água em um lago e na terra, simbolizando cura e equilíbrio. O céu estrelado, com uma grande estrela brilhante, representa esperança, enquanto as sete estrelas menores indicam os chakras ou harmonia universal.",
    "significados": {
        "direita": "Esperança, inspiração, cura, renovação, serenidade. A Estrela sugere que você confie no futuro e siga sua luz interior.",
        "invertida": "Falta de fé, desespero, atrasos na cura, dúvida. Pode indicar dificuldade em encontrar esperança ou confiança."
    },
    "contextos": {
        "amor": "Renovação emocional ou um novo começo nas relações. Invertida, sugere insegurança ou dificuldade em confiar no amor.",
        "carreira": "Oportunidades inspiradoras ou renovação profissional. Invertida, alerta para falta de motivação ou atrasos.",
        "saude": "Recuperação e bem-estar físico e mental. Invertida, pode indicar lentidão na cura ou necessidade de autocuidado.",
        "espiritualidade": "Conexão com o divino e renovação espiritual. Invertida, sugere dúvida espiritual ou desconexão."
    },
    "curiosidade": "A Estrela é associada ao signo de Aquário, que rege a inovação, o humanitarismo e a visão de futuro."
}' WHERE id = 18;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "A Lua: O Mistério do Inconsciente",
    "introducao": "A Lua, número 18 dos Arcanos Maiores, simboliza ilusão, intuição e o inconsciente. Representa a jornada pelo desconhecido, onde medos, sonhos e desejos ocultos emergem, convidando você a confiar na sua intuição para navegar pela incerteza e encontrar clareza.",
    "simbologia": "No baralho Rider-Waite, a lua ilumina um caminho entre duas torres, com um lobo e um cão uivando, simbolizando instintos selvagens e domesticados. Um lagostim emerge da água, representando o inconsciente, enquanto as torres indicam dualidade e os limites entre o consciente e o inconsciente.",
    "significados": {
        "direita": "Intuição, ilusão, sonhos, medos, inconsciente. A Lua sugere que você explore seu mundo interior e confie na sua intuição, mesmo em meio à incerteza.",
        "invertida": "Clareza, superação de medos, verdade revelada, estabilidade emocional. Pode indicar o fim de ilusões ou a resolução de confusões."
    },
    "contextos": {
        "amor": "Emoções confusas ou incertezas em relacionamentos, com necessidade de ouvir o coração. Invertida, sugere clareza emocional ou resolução de mal-entendidos.",
        "carreira": "Incertezas profissionais ou situações pouco claras. Invertida, indica maior clareza ou superação de obstáculos no trabalho.",
        "saude": "Ansiedade, sono perturbado ou questões emocionais afetando o bem-estar. Invertida, sugere melhora na saúde mental ou maior equilíbrio.",
        "espiritualidade": "Exploração profunda do inconsciente e conexão com a intuição. Invertida, indica clareza espiritual ou superação de dúvidas."
    },
    "curiosidade": "A Lua é associada ao signo de Peixes, que rege a intuição, os sonhos e a conexão com o inconsciente."
}' WHERE id = 19;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "O Sol: A Luz da Alegria",
    "introducao": "O Sol, número 19 dos Arcanos Maiores, simboliza alegria, sucesso e vitalidade. Representa a clareza após a escuridão, trazendo confiança, energia positiva e a celebração das conquistas, como uma criança que vive com autenticidade e entusiasmo.",
    "simbologia": "No baralho Rider-Waite, uma criança nua cavalga um cavalo branco sob um sol brilhante, simbolizando pureza, alegria e liberdade. As flores de girassol ao fundo representam vitalidade, enquanto a bandeira vermelha indica paixão e vitória.",
    "significados": {
        "direita": "Alegria, sucesso, clareza, vitalidade, confiança. O Sol sugere que você celebre suas conquistas e viva com autenticidade e entusiasmo.",
        "invertida": "Falta de confiança, atrasos, energia baixa, dúvidas. Pode indicar dificuldade em encontrar alegria ou obstáculos temporários."
    },
    "contextos": {
        "amor": "Relações felizes, vibrantes e cheias de energia positiva. Invertida, sugere mal-entendidos ou necessidade de reacender a paixão.",
        "carreira": "Sucesso profissional, reconhecimento e realização. Invertida, alerta para obstáculos temporários ou falta de motivação.",
        "saude": "Vitalidade elevada, com energia para cuidar do corpo e da mente. Invertida, sugere necessidade de descanso ou atenção ao bem-estar.",
        "espiritualidade": "Conexão com a luz interior e celebração da vida. Invertida, indica dúvida espiritual ou dificuldade em encontrar propósito."
    },
    "curiosidade": "O Sol é associado ao próprio Sol, que simboliza vida, energia e a fonte de toda a criação no sistema astrológico."
}' WHERE id = 20;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "O Julgamento: O Chamado da Renovação",
    "introducao": "O Julgamento, número 20 dos Arcanos Maiores, simboliza renascimento, avaliação e despertar. Representa um chamado para transformar sua vida, refletir sobre o passado e abraçar uma nova versão de si mesmo com propósito e clareza.",
    "simbologia": "No baralho Rider-Waite, um anjo toca uma trombeta, despertando figuras que emergem de caixões, simbolizando renascimento e julgamento. O mar e as montanhas ao fundo representam emoção e aspiração, enquanto a cruz na trombeta indica equilíbrio espiritual.",
    "significados": {
        "direita": "Renascimento, avaliação, chamado, transformação, clareza. O Julgamento sugere que você ouça seu chamado interior e aja com propósito.",
        "invertida": "Autocrítica, atrasos, resistência ao chamado, dúvida. Pode indicar dificuldade em perdoar a si mesmo ou medo de mudar."
    },
    "contextos": {
        "amor": "Renovação nas relações ou reconciliação através da honestidade. Invertida, sugere dificuldade em perdoar ou seguir em frente.",
        "carreira": "Novas oportunidades ou um chamado para mudar de direção profissional. Invertida, alerta para medo de mudança ou estagnação.",
        "saude": "Recuperação transformadora ou necessidade de avaliar hábitos. Invertida, sugere negligência ou resistência a melhorias.",
        "espiritualidade": "Despertar espiritual e conexão com seu propósito maior. Invertida, indica dúvida interior ou dificuldade em ouvir o chamado."
    },
    "curiosidade": "O Julgamento é associado ao planeta Plutão, que rege a transformação, a regeneração e o poder interior."
}' WHERE id = 21;

UPDATE cartas_tarot SET descricao_detalhada = '{
    "titulo": "O Mundo: A Plenitude da Conclusão",
    "introducao": "O Mundo, número 21 dos Arcanos Maiores, simboliza conclusão, realização e integração. Representa o fim de um ciclo com sucesso, trazendo harmonia, plenitude e a sensação de estar completo, pronto para começar uma nova jornada.",
    "simbologia": "No baralho Rider-Waite, uma figura dança dentro de uma coroa de louros, segurando varinhas, simbolizando vitória e equilíbrio. As quatro figuras nos cantos (homem, águia, touro, leão) representam os elementos fixos do zodíaco, enquanto a coroa indica realização.",
    "significados": {
        "direita": "Conclusão, realização, harmonia, plenitude, integração. O Mundo sugere que você celebre suas conquistas e se sinta completo.",
        "invertida": "Atrasos na conclusão, incompletude, falta de fechamento, estagnação. Pode indicar dificuldade em finalizar um ciclo ou alcançar metas."
    },
    "contextos": {
        "amor": "Relações completas, harmoniosas e profundamente conectadas. Invertida, sugere ciclos inacabados ou necessidade de resolução.",
        "carreira": "Sucesso, realização profissional ou conclusão de projetos importantes. Invertida, alerta para projetos incompletos ou falta de foco.",
        "saude": "Bem-estar total, com equilíbrio físico e mental. Invertida, sugere necessidade de autocuidado ou atenção a questões pendentes.",
        "espiritualidade": "Integração espiritual e conexão com o todo. Invertida, indica busca por completude ou dificuldade em encontrar propósito."
    },
    "curiosidade": "O Mundo é associado ao planeta Saturno, que rege a estrutura, a responsabilidade e a recompensa pelo trabalho árduo."
}' WHERE id = 22;