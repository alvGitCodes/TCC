document.addEventListener("DOMContentLoaded", function () {
    const btnCalcular = document.getElementById("btnCalcular");
    const descricaoPar = document.getElementById("descricaoPar");
    const cartaA = document.getElementById("cartaA");
    const cartaB = document.getElementById("cartaB");
    const cartasTarot = {
        1: { nome: "O Mago", imagem: "../imagens/cartas/o_mago.jpg" },
        2: { nome: "A Sacerdotisa", imagem: "../imagens/cartas/a_sacerdotisa.jpg" },
        3: { nome: "A Imperatriz", imagem: "../imagens/cartas/a_imperatriz.jpg" },
        4: { nome: "O Imperador", imagem: "../imagens/cartas/o_imperador.jpg" },
        5: { nome: "O Hierofante", imagem: "../imagens/cartas/o_hierofante.jpg" },
        6: { nome: "Os Enamorados", imagem: "../imagens/cartas/os_enamorados.jpg" },
        7: { nome: "O Carro", imagem: "../imagens/cartas/o_carro.jpg" },
        8: { nome: "A Força", imagem: "../imagens/cartas/a_forca.jpg" },
        9: { nome: "O Eremita", imagem: "../imagens/cartas/o_ermitão.jpg" },
        10: { nome: "A Roda da Fortuna", imagem: "../imagens/cartas/a_roda_da_fortuna.jpg" },
        11: { nome: "A Justiça", imagem: "../imagens/cartas/a_justica.jpg" },
        12: { nome: "O Enforcado", imagem: "../imagens/cartas/o_enforcado.jpg" },
        13: { nome: "A Morte", imagem: "../imagens/cartas/a_morte.jpg" },
        14: { nome: "A Temperança", imagem: "../imagens/cartas/a_temperanca.jpg" },
        15: { nome: "O Diabo", imagem: "../imagens/cartas/o_diabo.jpg" },
        16: { nome: "A Torre", imagem: "../imagens/cartas/a_torre.jpg" },
        17: { nome: "A Estrela", imagem: "../imagens/cartas/a_estrela.jpg" },
        18: { nome: "A Lua", imagem: "../imagens/cartas/a_lua.jpg" },
        19: { nome: "O Sol", imagem: "../imagens/cartas/o_sol.jpg" },
        20: { nome: "O Julgamento", imagem: "../imagens/cartas/o_julgamento.jpg" },
        21: { nome: "O Mundo", imagem: "../imagens/cartas/o_mundo.jpg" },
    };


    btnCalcular.addEventListener("click", function () {
        const dia = parseInt(document.getElementById("dia").value);
        const mes = parseInt(document.getElementById("mes").value);
        const ano = parseInt(document.getElementById("ano").value);

      
        if (!dia || !mes || !ano || dia < 1 || dia > 31 || mes < 1 || mes > 12 || ano < 1000 || ano > 9999) {
            descricaoPar.innerHTML = "<p style='color:red;'>Por favor, insira uma data válida.</p>";
            cartaA.innerHTML = `<img src="../imagens/backgrounds/backDiario.jpg" style="object-fit: cover;">`;
            cartaB.innerHTML = `<img src="../imagens/backgrounds/backDiario.jpg" style="object-fit: cover;">`;
            const cartaC = document.getElementById("cartaC");
            if (cartaC) cartaC.remove();
            return;
        }

       
        const century = Math.floor(ano / 100);
        const year = ano % 100;
        let sum = dia + mes + century + year;

      
        while (sum > 21) {
            if (sum === 30) {
                sum = 12;
                break;
            }
            const sumStr = sum.toString();
            if (sum > 99) {
                const first = parseInt(sumStr.substring(0, 2));
                const last = parseInt(sumStr.substring(2));
                sum = first + last;
            } else {
                const first = parseInt(sumStr.substring(0, 1));
                const last = parseInt(sumStr.substring(1));
                sum = first + last;
            }
        }

        
        let cardIds = [];
        switch (sum) {
            case 1:
            case 10:
                cardIds = [10, 1]; 
                break;
            case 2:
            case 11:
            case 20:
                cardIds = [11, 2]; 
                break;
            case 3:
            case 12:
            case 21:
                cardIds = [12, 3]; 
                break;
            case 4:
            case 13:
                cardIds = [13, 4];
                break;
            case 5:
            case 14:
                cardIds = [14, 5]; 
                break;
            case 6:
            case 15:
                cardIds = [15, 6]; 
                break;
            case 7:
            case 16:
                cardIds = [16, 7]; 
                break;
            case 8:
            case 17:
                cardIds = [17, 8]; 
                break;
            case 9:
            case 18:
                cardIds = [18, 9]; 
                break;
            case 19:
                cardIds = [19, 10, 1]; 
                break;
            default:
                descricaoPar.innerHTML = "<p style='color:red;'>Erro ao calcular as cartas.</p>";
                return;
        }

        
        if (cartasTarot[cardIds[0]] && cartasTarot[cardIds[1]]) {
            cartaA.innerHTML = `<img src="${cartasTarot[cardIds[0]].imagem}" alt="${cartasTarot[cardIds[0]].nome}"><p>${cartasTarot[cardIds[0]].nome}</p>`;
            cartaB.innerHTML = `<img src="${cartasTarot[cardIds[1]].imagem}" alt="${cartasTarot[cardIds[1]].nome}"><p>${cartasTarot[cardIds[1]].nome}</p>`;

            
            if (cardIds[2] && cartasTarot[cardIds[2]]) {
                let cartaC = document.getElementById("cartaC");
                if (!cartaC) {
                    cartaC = document.createElement("div");
                    cartaC.id = "cartaC";
                    cartaC.className = "cartaRevelada";
                    document.getElementById("cartasDescobertas").appendChild(cartaC);
                }
                cartaC.innerHTML = `<img src="${cartasTarot[cardIds[2]].imagem}" alt="${cartasTarot[cardIds[2]].nome}"><p>${cartasTarot[cardIds[2]].nome}</p>`;
            } else {
                const cartaC = document.getElementById("cartaC");
                if (cartaC) cartaC.remove();
            }

            
            const c1 = cartasTarot[cardIds[0]];
            const c2 = cartasTarot[cardIds[1]];
            const c3 = cardIds[2] ? cartasTarot[cardIds[2]] : null;

            if (c1.nome === "A Morte" && c2.nome === "O Imperador") {
                descricaoPar.innerHTML = `
                    <h3>A Morte (XIII) - Carta 1:</h3>
                    <p>A Morte simboliza transformação e renascimento, indicando a necessidade de abandonar o velho para abraçar o novo. Representa mudanças significativas que promovem crescimento pessoal.</p>
                    <h3>O Imperador (IV) – Carta 2:</h3>
                    <p>O Imperador representa autoridade, estabilidade e liderança. Indica um forte senso de estrutura e habilidade para organizar e comandar com racionalidade.</p>
                    <h3>Interpretação:</h3>
                    <p>Essa combinação sugere um equilíbrio entre transformação e estabilidade. Você se reinventa com coragem, mantendo princípios sólidos, evoluindo em ciclos apoiados por ordem interna.</p>
                `;
            } else if (c1.nome === "A Roda da Fortuna" && c2.nome === "O Mago") {
                descricaoPar.innerHTML = `
                    <h3>A Roda da Fortuna (X) - Carta 1:</h3>
                    <p>A Roda da Fortuna simboliza ciclos e mudanças imprevisíveis, convidando à aceitação do fluxo natural da vida e confiança em uma ordem maior.</p>
                    <h3>O Mago (I) – Carta 2:</h3>
                    <p>O Mago representa poder pessoal e criatividade, indicando que você possui as ferramentas para moldar sua realidade com foco e intenção.</p>
                    <h3>Interpretação:</h3>
                    <p>Este par equilibra destino e vontade. Você pode responder às mudanças com criatividade, fluindo com o destino ou agindo intencionalmente para guiar seu caminho.</p>
                `;
            } else if (c1.nome === "A Justiça" && c2.nome === "A Sacerdotisa") {
                descricaoPar.innerHTML = `
                    <h3>A Justiça (XI) - Carta 1:</h3>
                    <p>A Justiça representa equilíbrio e verdade, exigindo decisões éticas baseadas em fatos e responsabilidade pelas consequências.</p>
                    <h3>A Sacerdotisa (II) – Carta 2:</h3>
                    <p>A Sacerdotisa simboliza intuição e sabedoria oculta, convidando à introspecção e confiança nos sinais internos.</p>
                    <h3>Interpretação:</h3>
                    <p>Esse par une razão e intuição, sugerindo que as melhores decisões equilibram lógica e sensibilidade espiritual, encontrando justiça no coração.</p>
                `;
            } else if (c1.nome === "O Enforcado" && c2.nome === "A Imperatriz") {
                descricaoPar.innerHTML = `
                    <h3>O Enforcado (XII) - Carta 1:</h3>
                    <p>O Enforcado representa pausa e rendição, sugerindo que novas perspectivas surgem ao esperar e refletir.</p>
                    <h3>A Imperatriz (III) – Carta 2:</h3>
                    <p>A Imperatriz simboliza abundância e criatividade, ligada ao crescimento e harmonia com a natureza.</p>
                    <h3>Interpretação:</h3>
                    <p>Essas cartas indicam que o florescimento requer paciência. Respeitar ciclos internos cria um solo fértil para cultivar seus desejos.</p>
                `;
            } else if (c1.nome === "A Temperança" && c2.nome === "O Hierofante") {
                descricaoPar.innerHTML = `
                    <h3>A Temperança (XIV) - Carta 1:</h3>
                    <p>A Temperança fala de harmonia e moderação, unindo opostos com paciência para encontrar equilíbrio.</p>
                    <h3>O Hierofante (V) – Carta 2:</h3>
                    <p>O Hierofante representa tradição e sabedoria ancestral, oferecendo orientação através de estruturas estabelecidas.</p>
                    <h3>Interpretação:</h3>
                    <p>Este par sugere crescimento espiritual equilibrado, integrando tradição com flexibilidade para evoluir entre estrutura e liberdade.</p>
                `;
            } else if (c1.nome === "O Diabo" && c2.nome === "Os Enamorados") {
                descricaoPar.innerHTML = `
                    <h3>O Diabo (XV) - Carta 1:</h3>
                    <p>O Diabo representa amarras e desejos que limitam, revelando a necessidade de confrontar apegos para encontrar liberdade.</p>
                    <h3>Os Enamorados (VI) – Carta 2:</h3>
                    <p>Os Enamorados simbolizam escolhas e vínculos emocionais, destacando decisões feitas com o coração.</p>
                    <h3>Interpretação:</h3>
                    <p>Este par alerta para examinar desejos intensos em relações, encontrando amor verdadeiro ao se libertar de ilusões.</p>
                `;
            } else if (c1.nome === "A Torre" && c2.nome === "O Carro") {
                descricaoPar.innerHTML = `
                    <h3>A Torre (XVI) - Carta 1:</h3>
                    <p>A Torre simboliza rupturas necessárias que liberam, destruindo ilusões para um novo começo autêntico.</p>
                    <h3>O Carro (VII) – Carta 2:</h3>
                    <p>O Carro representa conquista e determinação, superando obstáculos com foco e coragem.</p>
                    <h3>Interpretação:</h3>
                    <p>Esse par mostra que quedas impulsionam recomeços. A destruição da Torre dá força ao Carro para seguir com convicção.</p>
                `;
            } else if (c1.nome === "A Estrela" && c2.nome === "A Força") {
                descricaoPar.innerHTML = `
                    <h3>A Estrela (XVII) - Carta 1:</h3>
                    <p>A Estrela simboliza esperança e cura, oferecendo luz e paz após desafios, restaurando a fé.</p>
                    <h3>A Força (VIII) – Carta 2:</h3>
                    <p>A Força representa coragem interior e compaixão, dominando desafios com gentileza e autocontrole.</p>
                    <h3>Interpretação:</h3>
                    <p>Este par encoraja resiliência luminosa, enfrentando desafios com serenidade e confiança na luz interior.</p>
                `;
            } else if (c1.nome === "A Lua" && c2.nome === "O Eremita") {
                descricaoPar.innerHTML = `
                    <h3>A Lua (XVIII) - Carta 1:</h3>
                    <p>A Lua representa mistério e ilusões, desafiando a confiar na intuição para navegar o inconsciente.</p>
                    <h3>O Eremita (IX) – Carta 2:</h3>
                    <p>O Eremita simboliza introspecção e sabedoria, buscando verdades profundas em silêncio.</p>
                    <h3>Interpretação:</h3>
                    <p>Esses arcanos indicam autoconhecimento profundo, encontrando lições valiosas na reflexão cautelosa.</p>
                `;
            } else if (c1.nome === "O Sol" && c2.nome === "A Roda da Fortuna" && c3 && c3.nome === "O Mago") {
                descricaoPar.innerHTML = `
                    <h3>O Sol (XIX) - Carta 1:</h3>
                    <p>O Sol irradia clareza e alegria, celebrando autenticidade e otimismo renovado.</p>
                    <h3>A Roda da Fortuna (X) – Carta 2:</h3>
                    <p>A Roda da Fortuna traz mudanças imprevisíveis, oferecendo novas possibilidades no fluxo da vida.</p>
                    <h3>O Mago (I) – Carta 3:</h3>
                    <p>O Mago manifesta oportunidades com foco, transformando potencial em ação consciente.</p>
                    <h3>Interpretação:</h3>
                    <p>Esse trio combina luz, transformação e ação, impulsionando a criação de uma nova fase com coragem e consciência.</p>
                `;
            } else if (c1.nome === "O Julgamento" && c2.nome === "A Sacerdotisa") {
                descricaoPar.innerHTML = `
                    <h3>O Julgamento (XX) - Carta 1:</h3>
                    <p>O Julgamento marca um despertar espiritual, chamando à responsabilidade e renascimento com propósito elevado.</p>
                    <h3>A Sacerdotisa (II) – Carta 2:</h3>
                    <p>A Sacerdotisa representa introspecção e sabedoria oculta, confiando na intuição e no sagrado.</p>
                    <h3>Interpretação:</h3>
                    <p>Este par une o chamado à verdade com a escuta interna, alinhando a alma a um propósito maior através do silêncio.</p>
                `;
            } else if (c1.nome === "O Mundo" && c2.nome === "A Imperatriz") {
                descricaoPar.innerHTML = `
                    <h3>O Mundo (XXI) - Carta 1:</h3>
                    <p>O Mundo simboliza realização e completude, celebrando o êxito de um ciclo concluído.</p>
                    <h3>A Imperatriz (III) – Carta 2:</h3>
                    <p>A Imperatriz representa criatividade e fertilidade, nutrindo novas ideias e relações.</p>
                    <h3>Interpretação:</h3>
                    <p>Essas cartas falam de plenitude criativa, prontas para criar algo novo a partir de um lugar de abundância e propósito.</p>
                `;
            } else {
                descricaoPar.innerHTML = `
                    <h3>${c1.nome} - Carta 1:</h3>
                    <p>Esta carta reflete um aspecto fundamental da sua jornada espiritual e pessoal. Explore seu simbolismo para entender suas lições.</p>
                    <h3>${c2.nome} – Carta 2:</h3>
                    <p>Esta carta complementa a primeira, oferecendo uma perspectiva adicional sobre sua essência e desafios.</p>
                    ${c3 ? `<h3>${c3.nome} – Carta 3:</h3><p>Uma terceira carta indica uma conexão especial com seu caminho, trazendo mais profundidade à sua jornada.</p>` : ''}
                    <h3>Interpretação:</h3>
                    <p>A combinação dessas cartas sugere uma interação única entre seus arquétipos. Reflita sobre como elas se manifestam em sua vida para encontrar orientação.</p>
                `;
            }
        } else {
            descricaoPar.innerHTML = "<p style='color:red;'>Erro: Dados das cartas não encontrados.</p>";
        }
    });
});