<?php
session_start();

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "astroteste");
if ($conn->connect_error) {
    die("Erro de conexão: " . $conn->connect_error);
}

// Se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['cartas']) && count($_POST['cartas']) == 10) {
        $_SESSION['etapa1'] = $_POST['cartas'];
        header("Location: etapa2.php");
        exit();
    } else {
        $erro = "Você deve escolher exatamente 10 cartas.";
    }
}

// Buscar as 22 Arcanas Maiores
$sql = "SELECT * FROM cartas_tarot WHERE tipo = 'Arcano Maior'";
$result = $conn->query($sql);
$cartas = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $cartas[] = $row;
    }
} else {
    $erro = "Nenhuma carta encontrada no banco de dados.";
}

// Criar uma cópia do array $cartas para embaralhar
$cartas_embaralhadas = $cartas;
shuffle($cartas_embaralhadas); // Embaralha as cartas apenas para .cartas-container

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AstroRealm: Tarot</title>
    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/footer.css">

    <link rel="stylesheet" href="../css/etapa1.css">
    <link rel="stylesheet" href="../css/etapaBody.css">
    <link rel="icon" type="image/x-icon" href="../imagens/ico/argentina1.png">

    <script src="../js/calculoCartaAlma.js" defer></script>
    <script src="../js/cssGeral.js" defer></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            let limite = 10;
            let cartasViradas = 0;

            document.querySelectorAll('.carta').forEach(carta => {
                const checkbox = carta.querySelector('input[type="checkbox"]');

                carta.addEventListener('click', function(e) {
                    if (e.target.tagName === "INPUT" || e.target.tagName === "LABEL" || e.target.closest('label')) {
                        return;
                    }

                    if (!carta.classList.contains('virada')) {
                        if (cartasViradas >= limite) return;

                        carta.classList.add('virada');
                        checkbox.checked = true;
                        cartasViradas++;
                    }
                });

                checkbox.addEventListener('change', function() {
                    if (!this.checked) {
                        this.checked = true; // Impede desmarcar
                    }
                });
            });

            // Redirecionamento das cartas no final da página (divCartas)
            document.querySelectorAll('#divCartas a').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const id = this.href.split('id=')[1];
                    window.location.href = `asCartas.php?id=${id}`;
                });
            });
        });
    </script>

</head>

<body>
    <div id="content">
        <header>
            <!-- <div id="contato"></div> -->
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <button class="hamburger">☰</button>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <!-- Menu Dropdown para Signos do Zodíaco -->
                    <li class="menuItem dropdown">
                        <a href="../horoscopo.php">Horóscopo</a>
                        <span class="dropdown-toggle">▼</span>
                        <ul class="dropdown-content">
                            <li><a href="../horoscoposGerais.php?signo=aries">Áries</a></li>
                            <li><a href="../horoscoposGerais.php?signo=taurus">Touro</a></li>
                            <li><a href="../horoscoposGerais.php?signo=gemini">Gêmeos</a></li>
                            <li><a href="../horoscoposGerais.php?signo=cancer">Câncer</a></li>
                            <li><a href="../horoscoposGerais.php?signo=leo">Leão</a></li>
                            <li><a href="../horoscoposGerais.php?signo=virgo">Virgem</a></li>
                            <li><a href="../horoscoposGerais.php?signo=libra">Libra</a></li>
                            <li><a href="../horoscoposGerais.php?signo=scorpio">Escorpião</a></li>
                            <li><a href="../horoscoposGerais.php?signo=sagittarius">Sagitário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=capricorn">Capricórnio</a></li>
                            <li><a href="../horoscoposGerais.php?signo=aquarius">Aquário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=pisces">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="../signos.php">Os Signos</a></li>
                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../etapas/etapa1.php" class="underline">Tarot</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                    <li class="menuItem"><a href="../admin_gerenciar_usuarios.php">Gerenciar Usuários</a></li>
                </ul>

                <div id="divPerfil">
                    <?php if (isset($_SESSION['usuario_nome'])): ?>
                        <a href="../perfil.php" class="usuario-logado">
                            <div id="divWrapPerfil">
                                <?php
                                $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                                ?>
                                <img src="../imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                                <div id="divInfoLogado">
                                    <h3>Meu Perfil</h3>
                                    <div>
                                        <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php else: ?>
                        <a href="../login.php">Login</a>
                    <?php endif; ?>
                </div>

            </nav>
            <div id="banner">
                <p>ASTROREALM</p>
            </div>
        </header>

    </div>

    <div id="etapasContainer">
        <P id="chamada" style="color: #fff;"></P>
        <h1>Escolha 10 Cartas do Baralho</h1>
        <p>Escolha exatamente 10 cartas entre os Arcanos Maiores.</p>

        <?php if (!empty($erro)): ?>
            <p style="color:red;"><?= $erro ?></p>
        <?php endif; ?>

        <form method="POST">
            <div class="cartas-container">
                <?php foreach ($cartas_embaralhadas as $carta): ?>
                    <div class="carta">
                        <div class="carta-flip">
                            <!-- Frente da carta: costas -->
                            <div class="carta-frente">
                                <img src="../imagens/backgrounds/backDiario.jpg" style="background-size: contain;">
                            </div>

                            <!-- Verso da carta: imagem da carta verdadeira -->
                            <div class="carta-verso">
                                <!-- Checkbox + Label -->
                                <input type="checkbox" name="cartas[]" value="<?= $carta['id'] ?>" id="carta<?= $carta['id'] ?>">
                                <label for="carta<?= $carta['id'] ?>">
                                    <img src="../imagens/cartas/<?= basename($carta['imagem']) ?>" alt="<?= $carta['nome'] ?>">
                                </label>
                                <p><?= $carta['nome'] ?></p>
                                <p><?= $carta['descricao'] ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <button type="submit">Avançar para a Etapa 2</button>
        </form>

    </div>
    <ul class="menuMobile">
        <li title="Horóscopo de Áries"><a href="../horoscoposGerais.php?signo=aries">♈︎</a></li>
        <li title="Horóscopo de Touro"><a href="../horoscoposGerais.php?signo=taurus">♉︎</a></li>
        <li title="Horóscopo de Gêmeos"><a href="../horoscoposGerais.php?signo=gemini">♊︎</a></li>
        <li title="Horóscopo de Câncer"><a href="../horoscoposGerais.php?signo=cancer">♋︎</a></li>
        <li title="Horóscopo de Leão"><a href="../horoscoposGerais.php?signo=leo">♌︎</a></li>
        <li title="Horóscopo de Virgem"><a href="../horoscoposGerais.php?signo=virgo">♍︎</a></li>
        <li title="Horóscopo de Libra"><a href="../horoscoposGerais.php?signo=libra">♎︎</a></li>
        <li title="Horóscopo de Escorpião"><a href="../horoscoposGerais.php?signo=scorpio">♏︎</a></li>
        <li title="Horóscopo de Sagitário"><a href="../horoscoposGerais.php?signo=sagittarius">♐︎</a></li>
        <li title="Horóscopo de Capricórnio"><a href="../horoscoposGerais.php?signo=capricorn">♑︎</a></li>
        <li title="Horóscopo de Aquário"><a href="../horoscoposGerais.php?signo=aquarius">♒︎</a></li>
        <li title="Horóscopo de Peixes"><a href="../horoscoposGerais.php?signo=pisces">♓︎</a></li>
    </ul>

    <div id="asCartas">
        <h2>Conheça as Cartas (I - XXII)</h2>
        <div>
            <p>O Tarot é um baralho composto por 78 cartas, cada uma com seu significado e simbolismo. Ele é dividido em dois grupos: os Arcanos Maiores (22 cartas), que representam grandes arquétipos e lições de vida, e os Arcanos Menores (56 cartas), que refletem situações do dia a dia.</p>

            <p> Durante uma tiragem, as cartas são escolhidas de forma intuitiva e formam uma narrativa que revela aspectos do passado, presente e possíveis caminhos futuros. Cada carta traz um significado único e pode oferecer orientações valiosas para quem busca entender melhor suas emoções, decisões ou desafios.</p>

            <p>O Tarot não determina o futuro, mas ajuda a enxergar com mais clareza as possibilidades e escolhas que temos diante de nós.</p>


        </div>
        <span style="font-weight: bold; color: #FFD700;">Arcana Maior - Clique em uma das cartas para saber mais.</span>
        <div id="divCartas">
            <?php foreach ($cartas as $carta): ?>
                <a href="asCartas.php?id=<?= $carta['id'] ?>">
                    <div class="cartas">
                        <img src="../imagens/cartas/<?= basename($carta['imagem']) ?>" alt="<?= $carta['nome'] ?>">
                    </div>
                </a>
            <?php endforeach; ?>
        </div>

    </div>

    <div id="cartaDaAlma">
        <h2>A Carta Da Alma</h2>
        <h3 style="color: #fff;">Carta da Alma pela Numerologia (baseada nos Arcanos Maiores). </h3>
        <div id="cartaAlmaIntro">
            <p>As Cartas da Alma são como um mapa que revela o caminho da alma, mostrando os desafios e as lições que precisamos aprender nesta vida. Elas nos ajudam a entender melhor quem somos e qual é o nosso propósito.</p>
            <p>As Cartas da Alma representam forças fundamentais que moldam nossa essência ao longo da vida. A partir da data de nascimento, revelam-se dois arquétipos que permanecem constantes, não importa o que aconteça.</p>
            <p>Existem apenas doze pares, partilhados por bilhões de pessoas, cada uma com sua individualidade.</p>
        </div>

        <div id="displayCartasAlma">
            <div id="cartasDescobertas">
                <div id="cartaA" class="cartaRevelada">
                    <img src="../imagens/backgrounds/backDiario.jpg" style="object-fit: cover;">

                </div>

                <div id="cartaB" class="cartaRevelada">
                    <img src="../imagens/backgrounds/backDiario.jpg" style="object-fit: cover;">
                </div>
            </div>

            <div id="descricaoPar">

            </div>
            <h4>Insira sua data de nascimento:</h4>
            <div class="form-nascimento">
                <select name="mes" id="mes">
                    <option value="1">Janeiro</option>
                    <option value="2">Fevereiro</option>
                    <option value="3">Março</option>
                    <option value="4">Abril</option>
                    <option value="5">Maio</option>
                    <option value="6">Junho</option>
                    <option value="7">Julho</option>
                    <option value="8">Agosto</option>
                    <option value="9">Setembro</option>
                    <option value="10">Outubro</option>
                    <option value="11">Novembro</option>
                    <option value="12">Dezembro</option>
                </select>
                <input type="number" name="dia" id="dia" placeholder="Dia">
                <input type="number" name="ano" id="ano" placeholder="Ano">
                <button id="btnCalcular">Calcular</button>
            </div>

        </div>
    </div>

    <footer>
        <div id="footerContent">

            <div id="footerDivs">

                <div id="logoWrapper">
                    <div id="logoFooter">Astro<span id="spanFooter">Realm</span></div>
                    <p>
                        Descubra seu destino e conecte-se com o universo através da astrologia. <br>Explore os
                        mistérios
                        dos
                        signos e muito mais!
                    </p>
                </div>

                <div class="colunaFooter">
                    <h3>Contato</h3>
                    <ul>
                        <li>Email: contato@astrorealm.com</li>
                        <li>Telefone: (11) 1234-5678</li>
                        <li>
                            <ul id="redesSociaisLinks">
                                <li><a href="https://github.com/alvGitRep"><img
                                            src="../imagens/icones footer/github_1051275.png" title="GitHub"
                                            alt="github">
                                        <div>Github</div>
                                    </a></li>
                                <li><a href=""><img src="../imagens/icones footer/linkedin_1051282.png" title="Linkedin"
                                            alt="linkedin">LinkedIn</a></li>
                                <li><a href=""><img src="../imagens/icones footer/whatsapp_1051272.png"
                                            alt="">WhatsApp</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="colunaFooter">
                    <h3>Recursos</h3>
                    <ul class="reucursosLinks">
                        <li><a href="https://freepik.com/">Freepik</a></li>
                        <li><a href="https://rapidapi.com/">Rapid Api</a></li>
                        <li><a href="https://rapidapi.com/gbattaglia/api/astrologer">Astrologer</a></li>
                        <li><a href="https://rapidapi.com/ashutosh.devil7/api/horoscope19">Horoscope</a></li>
                        <li><a href="https://rapidapi.com/gatzuma/api/deep-translate1">Deep Translate</a></li>
                    </ul>
                </div>

            </div>

            <p class="footerCredits">© 2024 AstroRealm. Todos os direitos reservados. Imagens por Freepik.</p>
    </footer>
    <!-- Botão de voltar ao topo -->
    <button id="scrollToTopBtn" title="Voltar ao topo"></button>
</body>

</html>