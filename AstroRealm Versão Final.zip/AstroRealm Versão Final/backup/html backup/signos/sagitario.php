<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/layoutSignos.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="icon" type="image/x-icon" href="../imagens/ico/argentina1.png">
    <script src="../js/cssGeral.js" defer></script>

    <title>Sagitário</title>
</head>

<body>
    <div id="content">
        <header>
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <!-- Menu Dropdown para Signos do Zodíaco -->
                    <li class="menuItem dropdown">
                        <a href="../horoscopo.php">Horóscopo</a>
                        <ul class="dropdown-content">
                            <li><a href="../horoscoposGerais.php?signo=aries">Áries</a></li>
                            <li><a href="../horoscoposGerais.php?signo=taurus">Touro</a></li>
                            <li><a href="../horoscoposGerais.php?signo=gemini">Gêmeos</a></li>
                            <li><a href="../horoscoposGerais.php?signo=cancer">Câncer</a></li>
                            <li><a href="../horoscoposGerais.php?signo=leo">Leão</a></li>
                            <li><a href="../horoscoposGerais.php?signo=virgo">Virgem</a></li>
                            <li><a href="../horoscoposGerais.php?signo=libra">Libra</a></li>
                            <li><a href="../horoscoposGerais.php?signo=scorpio">Escorpião</a></li>
                            <li><a href="../horoscoposGerais.php?signo=sagittarius">Sagitário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=capricorn">Capricórnio</a></li>
                            <li><a href="../horoscoposGerais.php?signo=aquarius">Aquário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=pisces">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="../signos.php" class="underline">Os Signos</a></li>
                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../etapas/etapa1.php">Tarot</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                </ul>

                <div id="divPerfil">
                <?php if (isset($_SESSION['usuario_nome'])): ?>
                    <a href="../perfil.php" class="usuario-logado">
                        <div id="divWrapPerfil">
                            <?php
                            $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                            ?>
                            <img src="../imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                            <div id="divInfoLogado">
                                <h3>Meu Perfil</h3>
                                <div>
                                    <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php else: ?>
                    <a href="../login.php">Login</a>
                <?php endif; ?>
            </div>
                
            </nav>
        </header>

        <div id="conteudoSignos">
            <table id="cabecalho">
                <tr>
                    <td id="divImageSign">
                        <span class="fogo">♐︎</span>
                    </td>
                    <td id="tituloSign">
                        Signo do Zodíaco: Sagitário
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <ul id="listCharSigns">
                            <li><strong>Elemento:</strong> Fogo</li>
                            <li><strong>Cor:</strong> Roxo, azul</li>
                            <li><strong>Planeta Regente:</strong> Júpiter</li>
                            <li><strong>Melhor Compatibilidade:</strong> Áries, Leão</li>
                            <li><strong>Período Correspondente:</strong> 22 de Novembro à 21 de Dezembro</li>
                        </ul>
                    </td>
                </tr>
            </table>

            <a href="../horoscoposGerais.php?signo=sagittarius"><button id="btnPrevisoes">Previsões Para
                    Sagitário</button></a>

            <div id="infoSigno">

                <h2 id="chamadaSigno">Sagitário: O Aventureiro do Zodíaco</h2>

                <p style="margin-bottom: -20px;">
                    Sagitário é o nono signo do zodíaco, regido por <strong>Júpiter</strong>, o planeta da expansão e da
                    sorte. Os sagitarianos, nascidos entre <strong>22 de novembro e 21 de dezembro</strong>, são
                    conhecidos por sua natureza otimista, aventureira e exploradora.
                </p>

                <h3 class="blockTitle">✨Características Positivas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Otimismo:</strong> Sagitarianos têm uma visão positiva da vida, sempre buscando o lado
                        bom, mesmo nas situações difíceis.</li>
                    <li><strong>Aventura:</strong> Adoram explorar o mundo e aprender coisas novas. Sua curiosidade os
                        leva a buscar experiências e viagens excitantes.</li>
                    <li><strong>Generosidade:</strong> São conhecidos por sua natureza generosa e amorosa, estando
                        sempre dispostos a ajudar os outros.</li>
                    <li><strong>Independência:</strong> Sagitário valoriza sua liberdade e precisa de espaço para
                        crescer e se desenvolver, tanto fisicamente quanto emocionalmente.</li>
                </ul>

                <h3 class="blockTitle">👿Características Negativas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Impulsividade:</strong> A busca por novas aventuras pode levar Sagitário a tomar
                        decisões precipitadas sem pensar nas consequências.</li>
                    <li><strong>Desatenção:</strong> Por estarem sempre em busca do próximo grande objetivo, eles podem
                        ser distraídos e negligentes com detalhes importantes.</li>
                    <li><strong>Inquietação:</strong> Quando não conseguem encontrar um desafio estimulante, Sagitário
                        pode ficar entediado e impaciente, buscando sempre algo novo.</li>
                </ul>

                <h3 class="blockTitle">🤝Relacionamentos e Carreira</h3>
                <p>
                    <strong>Relacionamentos:</strong><br>
                    Sagitário busca parceiros que compartilhem sua paixão pela vida e pelo conhecimento. Eles apreciam a
                    honestidade e a liberdade, e, portanto, um relacionamento que ofereça espaço e aventura é ideal para
                    eles.
                </p>
                <p>
                    <strong>Carreira:</strong><br>
                    Sagitário se destaca em profissões que envolvem viagens, educação, filosofia ou comunicação. Com sua
                    visão ampla e otimismo, eles podem ser excelentes professores, jornalistas, empresários ou guias
                    turísticos.
                </p>

                <h3 class="blockTitle">♥️Compatibilidade com Outros Signos</h3>
                <p>
                    Sagitário é mais compatível com outros signos de <strong>Fogo</strong> (Áries, Leão), que
                    compartilham sua energia e entusiasmo. Também pode se dar bem com signos de <strong>Ar</strong>
                    (Gêmeos, Libra, Aquário), que estimulam seu intelecto e desejo de explorar.
                </p>

                <h3 class="blockTitle">😎Sagitarianos Famosos</h3>
                <ul class="listaInfoSign">
                    <li><strong>Brad Pitt:</strong> Ator</li>
                    <li><strong>Taylor Swift:</strong> Cantora</li>
                    <li><strong>Winston Churchill:</strong> Político</li>
                    <li><strong>Scarlett Johansson:</strong> Atriz</li>
                    <li><strong>Christina Aguilera:</strong> Cantora</li>
                </ul>

                <p>
                    Sagitário é um signo de aventura e liberdade, com uma busca constante por conhecimento e
                    experiências. Seu espírito otimista e sua visão expansiva fazem deles os exploradores do zodíaco!
                </p>
                <a href="../mapaGratis.html">
                    <div class="btnPrevisoesBot">Criar Mapa Gratuito</div>
                </a>
            </div>
        </div>
    </div>

    <footer>
        <div id="footerContent">

            <div id="footerDivs">

                <div id="logoWrapper">
                    <div id="logoFooter">Astro<span id="spanFooter">Realm</span></div>
                    <p>
                        Descubra seu destino e conecte-se com o universo através da astrologia. <br>Explore os
                        mistérios
                        dos
                        signos e muito mais!
                    </p>
                </div>

                <div class="colunaFooter">
                    <h3>Contato</h3>
                    <ul>
                        <li>Email: contato@astrorealm.com</li>
                        <li>Telefone: (11) 1234-5678</li>
                        <li>
                            <ul id="redesSociaisLinks">
                                <li><a href="https://github.com/alvGitCodes"><img
                                            src="../imagens/icones footer/github_1051275.png" title="GitHub"
                                            alt="github">
                                        <div>Github</div>
                                    </a></li>
                                <li><a href=""><img src="../imagens/icones footer/linkedin_1051282.png" title="Linkedin"
                                            alt="linkedin">LinkedIn</a></li>
                                <li><a href=""><img src="../imagens/icones footer/whatsapp_1051272.png"
                                            alt="">WhatsApp</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="colunaFooter">
                    <h3>Recursos</h3>
                    <ul class="reucursosLinks">
                        <li><a href="https://freepik.com/">Freepik</a></li>
                        <li><a href="https://rapidapi.com/">Rapid Api</a></li>
                        <li><a href="https://rapidapi.com/gbattaglia/api/astrologer">Astrologer</a></li>
                        <li><a href="https://rapidapi.com/ashutosh.devil7/api/horoscope19">Horoscope</a></li>
                        <li><a href="https://rapidapi.com/gatzuma/api/deep-translate1">Deep Translate</a></li>
                    </ul>
                </div>

            </div>

            <p class="footerCredits">© 2024 AstroRealm. Todos os direitos reservados. Imagens por Freepik.</p>
    </footer>

    <button id="scrollToTopBtn" title="Voltar ao topo">&#11205;</button>
</body>

</html>