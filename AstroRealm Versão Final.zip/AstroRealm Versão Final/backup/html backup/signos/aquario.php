<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/layoutSignos.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="icon" type="image/x-icon" href="../imagens/ico/argentina1.png">
    <script src="../js/cssGeral.js" defer></script>

    <title>Aquário</title>
</head>

<body>
    <div id="content">
        <header>
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <!-- Menu Dropdown para Signos do Zodíaco -->
                    <li class="menuItem dropdown">
                        <a href="../horoscopo.php">Horóscopo</a>
                        <ul class="dropdown-content">
                            <li><a href="../horoscoposGerais.php?signo=aries">Áries</a></li>
                            <li><a href="../horoscoposGerais.php?signo=taurus">Touro</a></li>
                            <li><a href="../horoscoposGerais.php?signo=gemini">Gêmeos</a></li>
                            <li><a href="../horoscoposGerais.php?signo=cancer">Câncer</a></li>
                            <li><a href="../horoscoposGerais.php?signo=leo">Leão</a></li>
                            <li><a href="../horoscoposGerais.php?signo=virgo">Virgem</a></li>
                            <li><a href="../horoscoposGerais.php?signo=libra">Libra</a></li>
                            <li><a href="../horoscoposGerais.php?signo=scorpio">Escorpião</a></li>
                            <li><a href="../horoscoposGerais.php?signo=sagittarius">Sagitário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=capricorn">Capricórnio</a></li>
                            <li><a href="../horoscoposGerais.php?signo=aquarius">Aquário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=pisces">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="../signos.php" class="underline">Os Signos</a></li>
                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../etapas/etapa1.php">Tarot</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                </ul>


                <div id="divPerfil">
                <?php if (isset($_SESSION['usuario_nome'])): ?>
                    <a href="../perfil.php" class="usuario-logado">
                        <div id="divWrapPerfil">
                            <?php
                            $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                            ?>
                            <img src="../imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                            <div id="divInfoLogado">
                                <h3>Meu Perfil</h3>
                                <div>
                                    <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php else: ?>
                    <a href="../login.php">Login</a>
                <?php endif; ?>
            </div>


            </nav>
        </header>

        <div id="conteudoSignos">
            <table id="cabecalho">
                <tr>
                    <td id="divImageSign">
                        <span class="ar">♒︎</span>
                    </td>
                    <td id="tituloSign">
                        Signo do Zodíaco: Aquário
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <ul id="listCharSigns">
                            <li><strong>Elemento:</strong> Ar</li>
                            <li><strong>Cor:</strong> Azul, prata</li>
                            <li><strong>Planeta Regente:</strong> Urano</li>
                            <li><strong>Melhor Compatibilidade:</strong> Gêmeos, Libra</li>
                            <li><strong>Período Correspondente:</strong> 20 de Janeiro à 18 de Fevereiro</li>
                        </ul>
                    </td>
                </tr>
            </table>

            <a href="../horoscoposGerais.php?signo=aquarius"><button id="btnPrevisoes">Previsões Para
                    Aquário</button></a>

            <div id="infoSigno">

                <h2 id="chamadaSigno">Aquário: O Visionário do Futuro</h2>

                <p style="margin-bottom: -20px;">
                    Aquário é o signo que representa a inovação, o futuro e a liberdade. Regido por
                    <strong>Urano</strong>, o planeta das mudanças e da originalidade, Aquário é um signo de mentalidade
                    aberta, independente e sempre à frente de seu tempo. Os aquarianos nascem entre <strong>20 de
                        janeiro e 18 de fevereiro</strong> e são conhecidos por sua natureza visionária.
                </p>

                <h3 class="blockTitle">✨Características Positivas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Inovação e criatividade:</strong> Aquário tem uma mente inventiva e está sempre em busca
                        de novas ideias e soluções para problemas.</li>
                    <li><strong>Independência:</strong> Os aquarianos prezam muito pela sua liberdade pessoal e não
                        gostam de ser controlados.</li>
                    <li><strong>Humanitarismo:</strong> Aquário é um signo de grande empatia e sempre busca maneiras de
                        melhorar a sociedade, apoiando causas sociais e o bem-estar coletivo.</li>
                    <li><strong>Abertura mental:</strong> Aquário é tolerante e aberto a novas perspectivas, sendo
                        bastante flexível quanto a ideias e estilos de vida.</li>
                </ul>

                <h3 class="blockTitle">👿Características Negativas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Frieza emocional:</strong> Aquário pode parecer distante ou desapegado em seus
                        relacionamentos, o que pode ser interpretado como insensibilidade.</li>
                    <li><strong>Impulsividade:</strong> A busca constante por novidades pode fazer com que os aquarianos
                        tomem decisões rápidas sem pensar nas consequências.</li>
                    <li><strong>Rebeldia:</strong> Aquário tende a desafiar convenções e normas, o que pode resultar em
                        atitudes de desobediência ou até mesmo desprezo pelas regras estabelecidas.</li>
                </ul>

                <h3 class="blockTitle">🤝Relacionamentos e Carreira</h3>
                <p>
                    <strong>Relacionamentos:</strong><br>
                    Nos relacionamentos, Aquário valoriza a amizade, a igualdade e a liberdade. Aquarianos buscam
                    parceiros que compreendam sua necessidade de espaço pessoal e que compartilhem de suas ideias
                    inovadoras.
                </p>
                <p>
                    <strong>Carreira:</strong><br>
                    Aquário se destaca em profissões que envolvem inovação, ciência e tecnologia, além de áreas
                    relacionadas a causas sociais e humanitárias. São bons em profissões como cientistas, ativistas,
                    engenheiros e educadores.
                </p>

                <h3 class="blockTitle">♥️Compatibilidade com Outros Signos</h3>
                <p>
                    Aquário se dá bem com outros signos de <strong>Ar</strong> (Gêmeos, Libra), com os quais compartilha
                    uma comunicação fluida e uma mentalidade aberta. Além disso, Aquário também pode se entender bem com
                    signos de <strong>Fogo</strong> (Áries, Leão, Sagitário), que podem manter seu entusiasmo e
                    independência.
                </p>

                <h3 class="blockTitle">😎Aquarianos Famosos</h3>
                <ul class="listaInfoSign">
                    <li><strong>Oprah Winfrey:</strong> Apresentadora e empresária</li>
                    <li><strong>Abraham Lincoln:</strong> Ex-presidente dos EUA</li>
                    <li><strong>Thomas Edison:</strong> Inventor</li>
                    <li><strong>Shakira:</strong> Cantora</li>
                    <li><strong>Harry Styles:</strong> Cantor</li>
                </ul>

                <p>
                    Aquário é um signo de pensamento progressista, sempre buscando novos caminhos e soluções. São
                    visionários, apaixonados por inovação e por transformar o mundo para melhor!
                </p>
                <a href="../mapaGratis.html">
                    <div class="btnPrevisoesBot">Criar Mapa Gratuito</div>
                </a>
            </div>
        </div>
    </div>

    <footer>
        <div id="footerContent">

            <div id="footerDivs">

                <div id="logoWrapper">
                    <div id="logoFooter">Astro<span id="spanFooter">Realm</span></div>
                    <p>
                        Descubra seu destino e conecte-se com o universo através da astrologia. <br>Explore os
                        mistérios
                        dos
                        signos e muito mais!
                    </p>
                </div>

                <div class="colunaFooter">
                    <h3>Contato</h3>
                    <ul>
                        <li>Email: contato@astrorealm.com</li>
                        <li>Telefone: (11) 1234-5678</li>
                        <li>
                            <ul id="redesSociaisLinks">
                                <li><a href="https://github.com/alvGitCodes"><img
                                            src="../imagens/icones footer/github_1051275.png" title="GitHub"
                                            alt="github">
                                        <div>Github</div>
                                    </a></li>
                                <li><a href=""><img src="../imagens/icones footer/linkedin_1051282.png" title="Linkedin"
                                            alt="linkedin">LinkedIn</a></li>
                                <li><a href=""><img src="../imagens/icones footer/whatsapp_1051272.png"
                                            alt="">WhatsApp</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="colunaFooter">
                    <h3>Recursos</h3>
                    <ul class="reucursosLinks">
                        <li><a href="https://freepik.com/">Freepik</a></li>
                        <li><a href="https://rapidapi.com/">Rapid Api</a></li>
                        <li><a href="https://rapidapi.com/gbattaglia/api/astrologer">Astrologer</a></li>
                        <li><a href="https://rapidapi.com/ashutosh.devil7/api/horoscope19">Horoscope</a></li>
                        <li><a href="https://rapidapi.com/gatzuma/api/deep-translate1">Deep Translate</a></li>
                    </ul>
                </div>

            </div>

            <p class="footerCredits">© 2024 AstroRealm. Todos os direitos reservados. Imagens por Freepik.</p>
    </footer>

    <button id="scrollToTopBtn" title="Voltar ao topo">&#11205;</button>
</body>

</html>