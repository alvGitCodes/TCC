<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/layoutSignos.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="icon" type="image/x-icon" href="../imagens/ico/argentina1.png">
    <script src="../js/cssGeral.js" defer></script>

    <title>Virgem</title>
</head>

<body>
    <div id="content">
        <header>
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
               <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <!-- Menu Dropdown para Signos do Zodíaco -->
                    <li class="menuItem dropdown">
                        <a href="../horoscopo.php">Horóscopo</a>
                        <ul class="dropdown-content">
                            <li><a href="../horoscoposGerais.php?signo=aries">Áries</a></li>
                            <li><a href="../horoscoposGerais.php?signo=taurus">Touro</a></li>
                            <li><a href="../horoscoposGerais.php?signo=gemini">Gêmeos</a></li>
                            <li><a href="../horoscoposGerais.php?signo=cancer">Câncer</a></li>
                            <li><a href="../horoscoposGerais.php?signo=leo">Leão</a></li>
                            <li><a href="../horoscoposGerais.php?signo=virgo">Virgem</a></li>
                            <li><a href="../horoscoposGerais.php?signo=libra">Libra</a></li>
                            <li><a href="../horoscoposGerais.php?signo=scorpio">Escorpião</a></li>
                            <li><a href="../horoscoposGerais.php?signo=sagittarius">Sagitário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=capricorn">Capricórnio</a></li>
                            <li><a href="../horoscoposGerais.php?signo=aquarius">Aquário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=pisces">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="../signos.php" class="underline">Os Signos</a></li>
                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../etapas/etapa1.php">Tarot</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                </ul>


                <div id="divPerfil">
                    <?php if (isset($_SESSION['usuario_nome'])): ?>
                        <a href="../perfil.php" class="usuario-logado">
                            <div id="divWrapPerfil">
                                <?php
                                $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                                ?>
                                <img src="../imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                                <div id="divInfoLogado">
                                    <h3>Meu Perfil</h3>
                                    <div>
                                        <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php else: ?>
                        <a href="../login.php">Login</a>
                    <?php endif; ?>
                </div>


            </nav>
        </header>

        <div id="conteudoSignos">
            <table id="cabecalho">
                <tr>
                    <td id="divImageSign">
                        <span class="terra">♍︎</span>
                    </td>
                    <td id="tituloSign">
                        Signo do Zodíaco: Virgem
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <ul id="listCharSigns">
                            <li><strong>Elemento:</strong> Terra</li>
                            <li><strong>Cor:</strong> Bege, marrom</li>
                            <li><strong>Planeta Regente:</strong> Mercúrio</li>
                            <li><strong>Melhor Compatibilidade:</strong> Touro, Capricórnio</li>
                            <li><strong>Período Correspondente:</strong> 23 de Agosto à 22 de Setembro</li>
                        </ul>
                    </td>
                </tr>
            </table>

            <ul class="menuMobile">
                <li title="Horóscopo de Áries"><a href="../horoscoposGerais.php?signo=aries">♈︎</a></li>
                <li title="Horóscopo de Touro"><a href="../horoscoposGerais.php?signo=taurus">♉︎</a></li>
                <li title="Horóscopo de Gêmeos"><a href="../horoscoposGerais.php?signo=gemini">♊︎</a></li>
                <li title="Horóscopo de Câncer"><a href="../horoscoposGerais.php?signo=cancer">♋︎</a></li>
                <li title="Horóscopo de Leão"><a href="../horoscoposGerais.php?signo=leo">♌︎</a></li>
                <li title="Horóscopo de Virgem"><a href="../horoscoposGerais.php?signo=virgo">♍︎</a></li>
                <li title="Horóscopo de Libra"><a href="../horoscoposGerais.php?signo=libra">♎︎</a></li>
                <li title="Horóscopo de Escorpião"><a href="../horoscoposGerais.php?signo=scorpio">♏︎</a></li>
                <li title="Horóscopo de Sagitário"><a href="../horoscoposGerais.php?signo=sagittarius">♐︎</a></li>
                <li title="Horóscopo de Capricórnio"><a href="../horoscoposGerais.php?signo=capricorn">♑︎</a></li>
                <li title="Horóscopo de Aquário"><a href="../horoscoposGerais.php?signo=aquarius">♒︎</a></li>
                <li title="Horóscopo de Peixes"><a href="../horoscoposGerais.php?signo=pisces">♓︎</a></li>
            </ul>

            <a href="../horoscoposGerais.php?signo=virgo"><button id="btnPrevisoes">Previsões Para Virgem</button></a>

            <div id="infoSigno">
                <h2 id="chamadaSigno">Virgem: O Perfeccionista da Ordem</h2>
                <p style="margin-bottom: -20px;">
                    Virgem é o sexto signo do zodíaco, associado ao elemento <strong>Terra</strong> e regido por
                    <strong>Mercúrio</strong>, o planeta da comunicação.
                    As pessoas nascidas entre <strong>23 de agosto e 22 de setembro</strong> são conhecidas por sua
                    atenção aos detalhes, organização e praticidade.
                </p>

                <h3 class="blockTitle">✨Características Positivas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Organização:</strong> Virginianos são mestres da organização e sabem como manter tudo no
                        lugar certo.</li>
                    <li><strong>Praticidade:</strong> Sempre pensam de forma prática, procurando soluções eficientes
                        para os problemas.</li>
                    <li><strong>Atitude de serviço:</strong> Gostam de ajudar os outros e muitas vezes dedicam-se ao
                        bem-estar alheio.</li>
                    <li><strong>Capacidade analítica:</strong> Sua habilidade em analisar detalhes faz deles excelentes
                        em tarefas que exigem foco e precisão.</li>
                </ul>

                <h3 class="blockTitle">👿Características Negativas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Excesso de crítica:</strong> Virginianos podem ser excessivamente críticos, tanto
                        consigo mesmos quanto com os outros.</li>
                    <li><strong>Preocupação excessiva:</strong> A preocupação com a perfeição pode fazer com que se
                        sobrecarreguem.</li>
                    <li><strong>Reservado:</strong> Sua natureza prática pode fazê-los parecer distantes ou frios em
                        algumas situações.</li>
                </ul>

                <h3 class="blockTitle">🤝Relacionamentos e Carreira</h3>
                <p class="listaInfoSign">
                    <strong>Relacionamentos:</strong><br>
                    Virginianos são discretos e, embora possam não ser tão expressivos quanto outros signos, são
                    extremamente leais e confiáveis. Eles apreciam a estabilidade e a praticidade nos relacionamentos.
                </p>
                <p>
                    <strong>Carreira:</strong><br>
                    São perfeccionistas e se destacam em áreas que exigem atenção aos detalhes, como contabilidade,
                    medicina e organização. Profissões que envolvem análise ou serviço também são bem-sucedidas para
                    eles.
                </p>

                <h3 class="blockTitle">♥️Compatibilidade com Outros Signos</h3>
                <p>
                    Virgem se dá bem com outros signos de <strong>Terra</strong> (Touro, Capricórnio) devido à
                    estabilidade e pragmatismo. Também pode se dar bem com signos de <strong>Água</strong> (Câncer,
                    Escorpião, Peixes), que oferecem apoio emocional e equilíbrio.
                </p>

                <h3 class="blockTitle">😎Virginianos Famosos</h3>
                <ul class="listaInfoSign">
                    <li><strong>Keanu Reeves:</strong> Ator</li>
                    <li><strong>Kate Beckinsale:</strong> Atriz</li>
                    <li><strong>Zendaya:</strong> Atriz e cantora</li>
                    <li><strong>Salma Hayek:</strong> Atriz</li>
                    <li><strong>Michael Jackson:</strong> Cantor</li>
                </ul>

                <p>
                    Virgem é um signo de trabalho árduo, atenção aos detalhes e desejo de ser útil para os outros. Sua
                    praticidade e dedicação tornam o mundo mais organizado e eficiente.
                </p>
                <a href="../mapaGratis.html">
                    <div class="btnPrevisoesBot">Criar Mapa Gratuito</div>
                </a>
            </div>
        </div>
    </div>

    <footer>
        <div id="footerContent">

            <div id="footerDivs">

                <div id="logoWrapper">
                    <div id="logoFooter">Astro<span id="spanFooter">Realm</span></div>
                    <p>
                        Descubra seu destino e conecte-se com o universo através da astrologia. <br>Explore os
                        mistérios
                        dos
                        signos e muito mais!
                    </p>
                </div>

                <div class="colunaFooter">
                    <h3>Contato</h3>
                    <ul>
                        <li>Email: contato@astrorealm.com</li>
                        <li>Telefone: (11) 1234-5678</li>
                        <li>
                            <ul id="redesSociaisLinks">
                                <li><a href="https://github.com/alvGitCodes"><img
                                            src="../imagens/icones footer/github_1051275.png" title="GitHub"
                                            alt="github">
                                        <div>Github</div>
                                    </a></li>
                                <li><a href=""><img src="../imagens/icones footer/linkedin_1051282.png" title="Linkedin"
                                            alt="linkedin">LinkedIn</a></li>
                                <li><a href=""><img src="../imagens/icones footer/whatsapp_1051272.png"
                                            alt="">WhatsApp</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="colunaFooter">
                    <h3>Recursos</h3>
                    <ul class="reucursosLinks">
                        <li><a href="https://freepik.com/">Freepik</a></li>
                        <li><a href="https://rapidapi.com/">Rapid Api</a></li>
                        <li><a href="https://rapidapi.com/gbattaglia/api/astrologer">Astrologer</a></li>
                        <li><a href="https://rapidapi.com/ashutosh.devil7/api/horoscope19">Horoscope</a></li>
                        <li><a href="https://rapidapi.com/gatzuma/api/deep-translate1">Deep Translate</a></li>
                    </ul>
                </div>

            </div>

            <p class="footerCredits">© 2024 AstroRealm. Todos os direitos reservados. Imagens por Freepik.</p>
    </footer>

    <button id="scrollToTopBtn" title="Voltar ao topo">&#11205;</button>
</body>

</html>