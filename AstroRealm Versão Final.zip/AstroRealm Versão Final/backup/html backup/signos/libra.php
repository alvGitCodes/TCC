<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../css/layout.css">
    <link rel="stylesheet" href="../css/layoutSignos.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="icon" type="image/x-icon" href="../imagens/ico/argentina1.png">
    <script src="../js/cssGeral.js" defer></script>

    <title>Libra</title>
</head>

<body>
    <div id="content">
        <header>
            <nav class="menu">
                <div id="logo"><a href="../index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="../index.php">Home</a></li>
                    <!-- Menu Dropdown para Signos do Zodíaco -->
                    <li class="menuItem dropdown">
                        <a href="../horoscopo.php">Horóscopo</a>
                        <ul class="dropdown-content">
                            <li><a href="../horoscoposGerais.php?signo=aries">Áries</a></li>
                            <li><a href="../horoscoposGerais.php?signo=taurus">Touro</a></li>
                            <li><a href="../horoscoposGerais.php?signo=gemini">Gêmeos</a></li>
                            <li><a href="../horoscoposGerais.php?signo=cancer">Câncer</a></li>
                            <li><a href="../horoscoposGerais.php?signo=leo">Leão</a></li>
                            <li><a href="../horoscoposGerais.php?signo=virgo">Virgem</a></li>
                            <li><a href="../horoscoposGerais.php?signo=libra">Libra</a></li>
                            <li><a href="../horoscoposGerais.php?signo=scorpio">Escorpião</a></li>
                            <li><a href="../horoscoposGerais.php?signo=sagittarius">Sagitário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=capricorn">Capricórnio</a></li>
                            <li><a href="../horoscoposGerais.php?signo=aquarius">Aquário</a></li>
                            <li><a href="../horoscoposGerais.php?signo=pisces">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="../signos.php" class="underline">Os Signos</a></li>
                    <li class="menuItem"><a href="../astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="../etapas/etapa1.php">Tarot</a></li>
                    <li class="menuItem"><a href="../venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="../colecao.php">Coleção</a></li>
                </ul>

                <div id="divPerfil">
                <?php if (isset($_SESSION['usuario_nome'])): ?>
                    <a href="../perfil.php" class="usuario-logado">
                        <div id="divWrapPerfil">
                            <?php
                            $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                            ?>
                            <img src="../imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                            <div id="divInfoLogado">
                                <h3>Meu Perfil</h3>
                                <div>
                                    <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                </div>
                            </div>
                        </div>
                    </a>
                <?php else: ?>
                    <a href="../login.php">Login</a>
                <?php endif; ?>
            </div>

            </nav>
        </header>

        <div id="conteudoSignos">
            <table id="cabecalho">
                <tr>
                    <td id="divImageSign">
                        <span class="ar">♎︎</span>
                    </td>
                    <td id="tituloSign">
                        Signo do Zodíaco: Libra
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <ul id="listCharSigns">
                            <li><strong>Elemento:</strong> Ar</li>
                            <li><strong>Cor:</strong> Azul, verde</li>
                            <li><strong>Planeta Regente:</strong> Vênus</li>
                            <li><strong>Melhor Compatibilidade:</strong> Gêmeos, Aquário</li>
                            <li><strong>Período Correspondente:</strong> 23 de Setembro à 22 de Outubro</li>
                        </ul>
                    </td>
                </tr>
            </table>

            <a href="../horoscoposGerais.php?signo=libra"><button id="btnPrevisoes">Previsões Para Libra</button></a>
            <div id="infoSigno">

                <h2 id="chamadaSigno">Libra: O Diplomata do Zodíaco</h2>

                <p style="margin-bottom: -20px;">
                    Libra é o sétimo signo do zodíaco, associado ao elemento <strong>Ar</strong> e regido por
                    <strong>Vênus</strong>, o planeta do amor e da beleza.
                    Os nativos deste signo, nascidos entre <strong>23 de setembro e 22 de outubro</strong>, são
                    conhecidos por sua busca por harmonia, equilíbrio e justiça.
                </p>

                <h3 class="blockTitle">✨Características Positivas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Diplomacia:</strong> Librianos têm uma habilidade única de mediar conflitos e trazer
                        equilíbrio aos ambientes.</li>
                    <li><strong>Charmosos e sociáveis:</strong> São pessoas encantadoras, com uma natureza amigável e
                        uma grande habilidade para se relacionar com os outros.</li>
                    <li><strong>Sentido de justiça:</strong> Librianos têm um forte senso de justiça e buscam sempre a
                        equidade, seja em questões pessoais ou sociais.</li>
                    <li><strong>Estilo refinado:</strong> Eles têm uma apreciação natural pela arte, beleza e estética,
                        o que os torna pessoas sofisticadas.</li>
                </ul>

                <h3 class="blockTitle">👿Características Negativas</h3>
                <ul class="listaInfoSign">
                    <li><strong>Indecisão:</strong> A busca pelo equilíbrio pode torná-los indecisos, tendo dificuldade
                        em tomar decisões importantes.</li>
                    <li><strong>Evitar confrontos:</strong> Librianos muitas vezes evitam discussões ou confrontos, o
                        que pode levar a uma falta de clareza em algumas situações.</li>
                    <li><strong>Excesso de busca por aprovação:</strong> Eles podem se preocupar demais com a opinião
                        dos outros, o que pode resultar em insegurança.</li>
                </ul>

                <h3 class="blockTitle">🤝Relacionamentos e Carreira</h3>
                <p>
                    <strong>Relacionamentos:</strong><br>
                    Libra é o signo da parceria e do equilíbrio. Os librianos buscam companheiros que compartilhem seus
                    valores e apreciem sua natureza afetuosa. No entanto, podem ser excessivamente dependentes da
                    aprovação do parceiro.
                </p>
                <p>
                    <strong>Carreira:</strong><br>
                    Em sua vida profissional, Libra se destaca em áreas que envolvem criatividade, justiça ou mediação.
                    São excelentes em carreiras como direito, diplomacia, arte e design, onde sua busca por harmonia e
                    estética é valorizada.
                </p>

                <h3 class="blockTitle">♥️Compatibilidade com Outros Signos</h3>
                <p>
                    Libra tende a se dar bem com outros signos de <strong>Ar</strong> (Gêmeos, Aquário), que
                    compartilham seu amor pela comunicação e pela troca de ideias. Eles também podem encontrar harmonia
                    com signos de <strong>Fogo</strong> (Leão, Sagitário), que os motivam a agir.
                </p>

                <h3 class="blockTitle">😎Librianos Famosos</h3>
                <ul class="listaInfoSign">
                    <li><strong>Will Smith:</strong> Ator</li>
                    <li><strong>Beyoncé:</strong> Cantora</li>
                    <li><strong>Kim Kardashian:</strong> Personalidade da mídia</li>
                    <li><strong>Gwyneth Paltrow:</strong> Atriz</li>
                    <li><strong>Hugh Jackman:</strong> Ator</li>
                </ul>

                <p>
                    Libra é o signo da harmonia e do relacionamento, sempre em busca do equilíbrio perfeito na vida. Sua
                    habilidade de mediar, junto com seu charme natural, faz deles pessoas apreciadas e indispensáveis em
                    qualquer grupo.
                </p>
                <a href="../mapaGratis.html">
                    <div class="btnPrevisoesBot">Criar Mapa Gratuito</div>
                </a>
            </div>
        </div>
    </div>

    <footer>
        <div id="footerContent">

            <div id="footerDivs">

                <div id="logoWrapper">
                    <div id="logoFooter">Astro<span id="spanFooter">Realm</span></div>
                    <p>
                        Descubra seu destino e conecte-se com o universo através da astrologia. <br>Explore os
                        mistérios
                        dos
                        signos e muito mais!
                    </p>
                </div>

                <div class="colunaFooter">
                    <h3>Contato</h3>
                    <ul>
                        <li>Email: contato@astrorealm.com</li>
                        <li>Telefone: (11) 1234-5678</li>
                        <li>
                            <ul id="redesSociaisLinks">
                                <li><a href="https://github.com/alvGitCodes"><img
                                            src="../imagens/icones footer/github_1051275.png" title="GitHub"
                                            alt="github">
                                        <div>Github</div>
                                    </a></li>
                                <li><a href=""><img src="../imagens/icones footer/linkedin_1051282.png" title="Linkedin"
                                            alt="linkedin">LinkedIn</a></li>
                                <li><a href=""><img src="../imagens/icones footer/whatsapp_1051272.png"
                                            alt="">WhatsApp</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="colunaFooter">
                    <h3>Recursos</h3>
                    <ul class="reucursosLinks">
                        <li><a href="https://freepik.com/">Freepik</a></li>
                        <li><a href="https://rapidapi.com/">Rapid Api</a></li>
                        <li><a href="https://rapidapi.com/gbattaglia/api/astrologer">Astrologer</a></li>
                        <li><a href="https://rapidapi.com/ashutosh.devil7/api/horoscope19">Horoscope</a></li>
                        <li><a href="https://rapidapi.com/gatzuma/api/deep-translate1">Deep Translate</a></li>
                    </ul>
                </div>

            </div>

            <p class="footerCredits">© 2024 AstroRealm. Todos os direitos reservados. Imagens por Freepik.</p>
    </footer>

    <button id="scrollToTopBtn" title="Voltar ao topo">&#11205;</button>
</body>

</html>