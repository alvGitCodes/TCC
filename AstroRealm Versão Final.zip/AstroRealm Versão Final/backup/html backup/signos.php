<?php
session_start();
?>


<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/signos.css">
    <link rel="stylesheet" href="css/footer.css">


    <script src="js/signos.js" defer></script>
     <script src="js/cssGeral.js" defer></script>
    <link rel="icon" type="image/x-icon" href="imagens/ico/argentina1.png">
    <title>AstroRealm: Roda dos Signos</title>
</head>

<body>

    <div id="content">
        <header>
            <nav class="menu">
                <div id="logo"><a href="index.php">Astro<span id="logoSpan">Realm</span></a></div>
                <button class="hamburger">☰</button>
                <ul id="listaMenu">
                    <li class="menuItem"><a href="index.php">Home</a></li>
                    <li class="menuItem dropdown">
                        <a href="horoscopo.php">Horóscopo</a>
                        <ul class="dropdown-content">
                            <li><a href="horoscoposGerais.php?signo=aries">Áries</a></li>
                            <li><a href="horoscoposGerais.php?signo=taurus">Touro</a></li>
                            <li><a href="horoscoposGerais.php?signo=gemini">Gêmeos</a></li>
                            <li><a href="horoscoposGerais.php?signo=cancer">Câncer</a></li>
                            <li><a href="horoscoposGerais.php?signo=leo">Leão</a></li>
                            <li><a href="horoscoposGerais.php?signo=virgo">Virgem</a></li>
                            <li><a href="horoscoposGerais.php?signo=libra">Libra</a></li>
                            <li><a href="horoscoposGerais.php?signo=scorpio">Escorpião</a></li>
                            <li><a href="horoscoposGerais.php?signo=sagittarius">Sagitário</a></li>
                            <li><a href="horoscoposGerais.php?signo=capricorn">Capricórnio</a></li>
                            <li><a href="horoscoposGerais.php?signo=aquarius">Aquário</a></li>
                            <li><a href="horoscoposGerais.php?signo=pisces">Peixes</a></li>
                        </ul>
                    </li>
                    <li class="menuItem"><a href="signos.php" class="underline">Os Signos</a></li>
                    <li class="menuItem"><a href="astrologia.php">Astrologia</a></li>
                    <li class="menuItem"><a href="etapas/etapa1.php">Tarot</a></li>
                    <li class="menuItem"><a href="venda.html">Meu Mapa</a></li>
                    <li class="menuItem"><a href="colecao.php">Coleção</a></li>
                </ul>

                <div id="divPerfil">
                    <?php if (isset($_SESSION['usuario_nome'])): ?>
                        <a href="perfil.php" class="usuario-logado">
                            <div id="divWrapPerfil">
                                <?php
                                $foto_perfil = $_SESSION['usuario_foto'] ?? 'terra.png';
                                ?>
                                <img src="imagens/perfis/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto do Usuário">
                                <div id="divInfoLogado">
                                    <h3>Meu Perfil</h3>
                                    <div>
                                        <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php else: ?>
                        <a href="login.php">Login</a>
                    <?php endif; ?>
                </div>

            </nav>

            <div id="banner">
                <p>ZODÍACO</p>
            </div>
        </header>

        <div id="divConteudo">
            <h2 style="margin: auto; width: fit-content; margin-bottom: 5px;">Previsões de Hoje</h2>

            <ul class="menuMobile" style="margin-bottom: 10px;">
                <li title="Horóscopo de Áries"><a href="horoscoposGerais.php?signo=aries">♈︎</a></li>
                <li title="Horóscopo de Touro"><a href="horoscoposGerais.php?signo=taurus">♉︎</a></li>
                <li title="Horóscopo de Gêmeos"><a href="horoscoposGerais.php?signo=gemini">♊︎</a></li>
                <li title="Horóscopo de Câncer"><a href="horoscoposGerais.php?signo=cancer">♋︎</a></li>
                <li title="Horóscopo de Leão"><a href="horoscoposGerais.php?signo=leo">♌︎</a></li>
                <li title="Horóscopo de Virgem"><a href="horoscoposGerais.php?signo=virgo">♍︎</a></li>
                <li title="Horóscopo de Libra"><a href="horoscoposGerais.php?signo=libra">♎︎</a></li>
                <li title="Horóscopo de Escorpião"><a href="horoscoposGerais.php?signo=scorpio">♏︎</a></li>
                <li title="Horóscopo de Sagitário"><a href="horoscoposGerais.php?signo=sagittarius">♐︎</a></li>
                <li title="Horóscopo de Capricórnio"><a href="horoscoposGerais.php?signo=capricorn">♑︎</a></li>
                <li title="Horóscopo de Aquário"><a href="horoscoposGerais.php?signo=aquarius">♒︎</a></li>
                <li title="Horóscopo de Peixes"><a href="horoscoposGerais.php?signo=pisces">♓︎</a></li>
            </ul>

            <div id="titleSigns">
                ESCOLHA SEU <strong>SIGNO</strong>
            </div>

            <div class="zodiacWheel">
                <div id="exibirSigno">

                </div>
                <div class="sign" style="--angle: 0deg;">
                    <a href="signos/cancer.php">
                        <img src="imagens/icones zodiaco c/cancer_pb.png" alt="Câncer" title="Câncer">
                    </a>
                </div>
                <!-- Câncer -->
                <div class="sign" style="--angle: 30deg;">
                    <a href="signos/leao.php">
                        <img src="imagens/icones zodiaco c/leo_pb.png" alt="Leão" title="Leão">
                    </a>
                </div> <!-- Leão -->
                <div class="sign" style="--angle: 60deg;">
                    <a href="signos/virgem.php">
                        <img src="imagens/icones zodiaco c//virgo_pb.png" alt="Virgem" title="Virgem">
                    </a>
                </div>
                <!-- Virgem -->
                <div class="sign" style="--angle: 90deg;">
                    <a href="signos/libra.php">
                        <img src="imagens/icones zodiaco c/libra_pb.png" alt="Libra" title="Libra">
                    </a>
                </div>
                <!-- Libra -->
                <div class="sign" style="--angle: 120deg;">
                    <a href="signos/escorpiao.php">
                        <img src="imagens/icones zodiaco c/scorpio_pb.png" alt="Escorpião" title="Escorpião">
                    </a>
                </div>
                <!-- Escorpião -->
                <div class="sign" style="--angle: 150deg;">
                    <a href="signos/sagitario.php">
                        <img src="imagens/icones zodiaco c/sagittarius_pb.png" alt="Sagitário" title="Sagitário">
                    </a>
                </div> <!-- Sagitário -->
                <div class="sign" style="--angle: 180deg;">
                    <a href="signos/capricornio.php">
                        <img src="imagens/icones zodiaco c/capricorn_pb.png" alt="Capricórnio" title="Capricórnio">
                    </a>
                </div> <!-- Capricórnio -->
                <div class="sign" style="--angle: 210deg;">
                    <a href="signos/aquario.php">
                        <img src="imagens/icones zodiaco c/aquarius_pb.png" alt="Aquário" title="Aquário">
                    </a>
                </div>
                <!-- Aquário -->
                <div class="sign" style="--angle: 240deg;">
                    <a href="signos/peixes.php">
                        <img src="imagens/icones zodiaco c/pisces_pb.png" alt="Peixes" title="Peixes">
                    </a>
                </div>
                <!-- Peixes -->
                <div class="sign" style="--angle: 270deg;">
                    <a href="signos/aries.php">
                        <img src="imagens/icones zodiaco c/aries_pb.png" alt="Áries" title="Áries">
                    </a>
                </div>
                <!-- Áries -->
                <div class="sign" style="--angle: 300deg;">
                    <a href="signos/aries.php">
                        <img src="imagens/icones zodiaco c/taurus_pb.png" alt="Touro" title="Touro">
                    </a>
                </div>
                <!-- Touro -->
                <div class="sign" style="--angle: 330deg;">
                    <a href="signos/gemeos.php">
                        <img src="imagens/icones zodiaco c/gemini_pb.png" alt="Gêmeos" title="Gêmeos">
                    </a>
                </div>
                <!-- Gêmeos -->
            </div>

        </div><!-- fim divConteud -->

    </div>

    <footer>
        <div id="footerContent">

            <div id="footerDivs">

                <div id="logoWrapper">
                    <div id="logoFooter">Astro<span id="spanFooter">Realm</span></div>
                    <p>
                        Descubra seu destino e conecte-se com o universo através da astrologia. <br>Explore os
                        mistérios
                        dos
                        signos e muito mais!
                    </p>
                </div>

                <div class="colunaFooter">
                    <h3>Contato</h3>
                    <ul>
                        <li>Email: contato@astrorealm.com</li>
                        <li>Telefone: (11) 1234-5678</li>
                        <li>
                            <ul id="redesSociaisLinks">
                                <li><a href="https://github.com/alvGitCodes"><img
                                            src="imagens/icones footer/github_1051275.png" title="GitHub" alt="github">
                                        <div>Github</div>
                                    </a></li>
                                <li><a href=""><img src="imagens/icones footer/linkedin_1051282.png" title="Linkedin"
                                            alt="linkedin">LinkedIn</a></li>
                                <li><a href=""><img src="imagens/icones footer/whatsapp_1051272.png" alt="">WhatsApp</a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>

                <div class="colunaFooter">
                    <h3>Recursos</h3>
                    <ul class="reucursosLinks">
                        <li><a href="https://freepik.com/">Freepik</a></li>
                        <li><a href="https://rapidapi.com/">Rapid Api</a></li>
                        <li><a href="https://rapidapi.com/gbattaglia/api/astrologer">Astrologer</a></li>
                        <li><a href="https://rapidapi.com/ashutosh.devil7/api/horoscope19">Horoscope</a></li>
                        <li><a href="https://rapidapi.com/gatzuma/api/deep-translate1">Deep Translate</a></li>
                    </ul>
                </div>

            </div>

            <p class="footerCredits">© 2024 AstroRealm. Todos os direitos reservados. Imagens por Freepik.</p>
    </footer>

    <!-- Botão de voltar ao topo -->
    <button id="scrollToTopBtn" title="Voltar ao topo">&#11205;</button>
</body>

</html>