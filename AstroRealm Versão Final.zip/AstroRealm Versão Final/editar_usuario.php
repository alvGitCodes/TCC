<?php
session_start();

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo_usuario'] !== 'admin') {
    header("Location: login.php");
    exit();
}

$host = 'localhost';
$usuario = 'root';
$senha = '';
$banco = 'astroteste';

$conn = new mysqli($host, $usuario, $senha, $banco);
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

$id = $_GET['id'] ?? 0;
$sql = "SELECT id, nome, email, tipo_usuario, foto FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();

if (!$usuario) {
    header("Location: admin_gerenciar_usuarios.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $tipo_usuario = $_POST['tipo_usuario'];
    $foto = $_POST['foto'] ?? $usuario['foto']; // Use hidden input value

    $sql = "UPDATE usuarios SET nome = ?, email = ?, tipo_usuario = ?, foto = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $nome, $email, $tipo_usuario, $foto, $id);

    try {
        $stmt->execute();
        if ($id == $_SESSION['usuario_id']) {
            $_SESSION['usuario_nome'] = $nome;
            $_SESSION['usuario_foto'] = $foto;
        }
        header("Location: admin_gerenciar_usuarios.php?sucesso=1");
        exit();
    } catch (mysqli_sql_exception $e) {
        if ($e->getCode() == 1062) {
            $erro = "Este e-mail já está em uso.";
        } else {
            $erro = "Erro inesperado: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AstroRealm - Editar Usuário</title>
    <link rel="stylesheet" href="css/layout.css">
    <link rel="stylesheet" href="css/index.css">
    <link rel="stylesheet" href="css/editar.css">
    <link rel="icon" type="image/x-icon" href="imagens/ico/argentina1.png">
    
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            // Image gallery selection
            const imagens = document.querySelectorAll('.galeria img');
            const inputFoto = document.getElementById('fotoSelecionada');
            const preview = document.getElementById('fotoPreview');

            imagens.forEach(img => {
                img.addEventListener('click', () => {
                    imagens.forEach(i => i.classList.remove('selecionada'));
                    img.classList.add('selecionada');
                    inputFoto.value = img.dataset.nome;
                    preview.src = "imagens/perfis/" + img.dataset.nome;
                });
            });

            // Client-side validation
            const form = document.querySelector('form');
            form.addEventListener('submit', function (e) {
                const nome = document.querySelector('input[name="nome"]').value;
                const email = document.querySelector('input[name="email"]').value;
                let valid = true;

                if (nome.length < 3) {
                    document.querySelector('#nomeError').style.display = 'block';
                    valid = false;
                } else {
                    document.querySelector('#nomeError').style.display = 'none';
                }

                const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                if (!emailRegex.test(email)) {
                    document.querySelector('#emailError').style.display = 'block';
                    valid = false;
                } else {
                    document.querySelector('#emailError').style.display = 'none';
                }

                if (!valid) {
                    e.preventDefault();
                }
            });

            // Dismiss alert
            const closeButtons = document.querySelectorAll('.alert .close');
            closeButtons.forEach(button => {
                button.addEventListener('click', function () {
                    this.parentElement.style.display = 'none';
                });
            });
        });
    </script>
</head>
<body>
    <div id="topo">
        <nav class="menu menuIndex">
            <div id="logo"><a href="index.php">Astro<span id="logoSpan">Realm</span></a></div>
            <ul id="listaMenu">
                <li class="menuItem"><a href="index.php" class="underline">Home</a></li>
                <li class="menuItem"><a href="horoscopo.php">Horóscopo</a></li>
                <li class="menuItem"><a href="signos.php">Os Signos</a></li>
                <li class="menuItem"><a href="astrologia.php">Astrologia</a></li>
                <li class="menuItem"><a href="etapas/etapa1.php">Tarot</a></li>
                <li class="menuItem"><a href="venda.html">Meu Mapa</a></li>
                <li class="menuItem"><a href="colecao.php">Coleção</a></li>
                <li class="menuItem"><a href="admin_gerenciar_usuarios.php">Gerenciar Usuários</a></li>
            </ul>
            <div id="divPerfil">
                <a href="perfil.php" class="usuario-logado">
                    <div id="divWrapPerfil">
                        <img src="imagens/perfis/<?php echo htmlspecialchars($_SESSION['usuario_foto'] ?? 'terra.png'); ?>" alt="Foto do Usuário" aria-label="Foto de perfil do usuário">
                        <div id="divInfoLogado">
                            <h3>Meu Perfil</h3>
                            <span id="nomePerfil"><?php echo htmlspecialchars($_SESSION['usuario_nome']); ?></span>
                        </div>
                    </div>
                </a>
            </div>
        </nav>
        <div id="content">
            <div id="formContainer">
                <h2 id="formTitle">Editar Usuário</h2>
                <?php if (isset($erro)): ?>
                    <div class="alert alert-error" role="alert">
                        <?php echo htmlspecialchars($erro); ?>
                        <span class="close" aria-label="Fechar alerta">×</span>
                    </div>
                <?php endif; ?>
                <?php if (isset($_GET['sucesso'])): ?>
                    <div class="alert alert-success" role="alert">
                        Usuário atualizado com sucesso!
                        <span class="close" aria-label="Fechar alerta">×</span>
                    </div>
                <?php endif; ?>
                <form method="POST" aria-labelledby="formTitle">
                    <div class="editInputs">
                        <label for="nome">Nome:</label>
                        <input type="text" name="nome" id="nome" value="<?php echo htmlspecialchars($usuario['nome']); ?>" class="inputs" required minlength="3" aria-describedby="nomeError">
                        <div id="nomeError" class="error-message">O nome deve ter pelo menos 3 caracteres.</div>
                    </div>
                    <div class="editInputs">
                        <label for="email">E-mail:</label>
                        <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($usuario['email']); ?>" class="inputs" required pattern="[^\s@]+@[^\s@]+\.[^\s@]+" aria-describedby="emailError">
                        <div id="emailError" class="error-message">Por favor, insira um e-mail válido.</div>
                    </div>
                    <div class="editInputs">
                        <label for="tipo_usuario">Tipo de Usuário:</label>
                        <select name="tipo_usuario" id="tipo_usuario" class="inputs" required>
                            <option value="comum" <?php echo $usuario['tipo_usuario'] === 'comum' ? 'selected' : ''; ?>>Comum</option>
                            <option value="admin" <?php echo $usuario['tipo_usuario'] === 'admin' ? 'selected' : ''; ?>>Administrador</option>
                        </select>
                    </div>
                    <div class="editInputs">
                        <label for="fotoSelecionada">Foto de Perfil:</label>
                        <input type="hidden" name="foto" id="fotoSelecionada" value="<?php echo htmlspecialchars($usuario['foto']); ?>">
                        <img src="imagens/perfis/<?php echo htmlspecialchars($usuario['foto']); ?>" id="fotoPreview" class="foto-perfil" alt="Foto atual de <?php echo htmlspecialchars($usuario['nome']); ?>">
                        <p>Escolha sua nova foto de perfil:</p>
                        <div class="galeria">
                            <?php
                            $imagens = ['terra.png', 'marte.png', 'jupiter.png', 'venus.png', 'saturno.png'];
                            foreach ($imagens as $img): ?>
                                <img src="imagens/perfis/<?php echo $img; ?>" data-nome="<?php echo $img; ?>" class="<?php echo $usuario['foto'] === $img ? 'selecionada' : ''; ?>" alt="Opção de foto de perfil <?php echo $img; ?>">
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <button type="submit" class="btnEdit">Salvar</button>
                    <a href="admin_gerenciar_usuarios.php" class="btnEdit secondary">Voltar</a>
                </form>
            </div>
        </div>
    </body>
</html>
<?php
$stmt->close();
$conn->close();
?>